<map version="freeplane 1.8.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="tmap 20201030 hack2020.innoagency.ru" FOLDED="false" ID="ID_937580609" CREATED="1602584519898" MODIFIED="1604096170948"><hook NAME="MapStyle" zoom="0.825">
    <properties edgeColorConfiguration="#808080ff,#000000ff,#ff0033ff,#009933ff,#3333ffff,#ff6600ff,#cc00ccff,#ffbf00ff,#00ff99ff,#0099ffff,#996600ff,#000000ff,#cc0066ff,#33ff00ff,#ff9999ff,#0000ccff,#cccc00ff,#0099ccff,#006600ff,#ff00ccff,#00cc00ff,#0066ccff,#00ffffff" show_icon_for_attributes="true" show_note_icons="true" fit_to_viewport="false"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt" TEXT_SHORTENED="true">
<font SIZE="24"/>
<richcontent TYPE="DETAILS" LOCALIZED_HTML="styles_background_html"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="default" ICON_SIZE="12.0 pt" COLOR="#000000" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0.0 pt" TEXT_ALIGN="CENTER" MAX_WIDTH="120.0 pt" MIN_WIDTH="120.0 pt">
<font NAME="Arial" SIZE="9" BOLD="true" ITALIC="false"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details">
<font SIZE="11" BOLD="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#000000" BACKGROUND_COLOR="#ffffff">
<font SIZE="9" BOLD="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#000000" BACKGROUND_COLOR="#ffffff" TEXT_ALIGN="LEFT">
<font BOLD="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
<edge COLOR="#0000cc"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000" STYLE="oval" UNIFORM_SHAPE="true" MAX_WIDTH="120.0 pt" MIN_WIDTH="120.0 pt">
<font SIZE="24" ITALIC="true"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<font SIZE="24"/>
<hook NAME="AutomaticEdgeColor" COUNTER="0" RULE="FOR_COLUMNS"/>
<node TEXT="Название документа: ТЗ по навигации в метро" POSITION="right" ID="ID_925190708" CREATED="1602709813549" MODIFIED="1602709831775"/>
<node TEXT="Автор: Соколов Николай Васильевич&#xa;Дата: 20201030" POSITION="right" ID="ID_1375598473" CREATED="1602709749388" MODIFIED="1604096405542"/>
<node TEXT="20201030 1930 колл заказчики" POSITION="right" ID="ID_1895465724" CREATED="1604080073748" MODIFIED="1604178939741">
<node TEXT="вопросы трекерам" ID="ID_1308952800" CREATED="1603824331730" MODIFIED="1604178939741">
<node TEXT="Вопросы: критерии оценки проектов" ID="ID_990419317" CREATED="1603740428398" MODIFIED="1603740428398"/>
<node TEXT="что предпочтительнее: код, дизайн или экономика" ID="ID_785545028" CREATED="1603740428399" MODIFIED="1603740428399"/>
<node TEXT="в чат" ID="ID_1321768322" CREATED="1603824891369" MODIFIED="1603824900891">
<node TEXT="Вопросы трекерам:" ID="ID_1905354472" CREATED="1603824914138" MODIFIED="1603824914138">
<node TEXT="1. Критерии оценки проектов" ID="ID_504687982" CREATED="1603824914138" MODIFIED="1603824914138"/>
<node TEXT="2. Что предпочтительнее:" ID="ID_309052806" CREATED="1603824914140" MODIFIED="1603824914140"/>
<node TEXT="а)код," ID="ID_108794132" CREATED="1603824914142" MODIFIED="1603824914142"/>
<node TEXT="б)дизайн" ID="ID_926561301" CREATED="1603824914145" MODIFIED="1603824914145"/>
<node TEXT="в)экономика" ID="ID_1353876366" CREATED="1603824914146" MODIFIED="1603824914146"/>
<node TEXT="г)cjm customer jouney map" ID="ID_285441747" CREATED="1603824914147" MODIFIED="1603824914147"/>
<node TEXT="д) анимация процесса навигации, как драфт перед экспортом в движок и подключение алгоритма" ID="ID_618681055" CREATED="1603824914148" MODIFIED="1603824914148"/>
<node TEXT="е)демо ролик процесса работы приложения, юз кейс на видео с персонажем" ID="ID_635148499" CREATED="1603824914149" MODIFIED="1603824914149"/>
<node TEXT="ж)детализация плана графика разработки" ID="ID_838844967" CREATED="1603824914151" MODIFIED="1604076035374"/>
<node TEXT="и)демонстрация эпизодов крутых фич юз кейсов как оно должно выглядеть со стороны, и по возможности рабочий код, но без бантиков" ID="ID_1405089302" CREATED="1603824914152" MODIFIED="1603824914152"/>
</node>
</node>
</node>
</node>
<node TEXT="20201030 2018 датасет" POSITION="right" ID="ID_1999495148" CREATED="1604083721133" MODIFIED="1604083755565">
<node TEXT="Исходник" ID="ID_1001895696" CREATED="1604095462764" MODIFIED="1604095472140">
<node TEXT="Описание задачи ЦОДД" ID="ID_525764421" CREATED="1604083698495" MODIFIED="1604095472140">
<node ID="ID_234161637" CREATED="1604083774950" MODIFIED="1604083774950"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Короткое описание
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_1715216813" CREATED="1604083774953" MODIFIED="1604083774953"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Создание модуля интерактивной карты метро города Москвы с возможностью построения маршрута для мобильного приложения iOS и Android.</font>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1836439166" CREATED="1604083774965" MODIFIED="1604083774965"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <a name="_o5h299itwzyi">
</a>Исходные данные
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_1585692587" CREATED="1604083774987" MODIFIED="1604083774987"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3 class="western">
      <a name="_h4gox7rfr9zc">
</a>SVG файл с картой
    </h3>
  </body>
</html>
</richcontent>
<node ID="ID_614555960" CREATED="1604083774988" MODIFIED="1604083774988"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Файл содержит данные о линиях метро, остановках метро.<br/>Ссылка для скачивания SVG файла (пример):</font>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1302501049" CREATED="1604083774989" MODIFIED="1604083774989" LINK="https://drive.google.com/file/d/1m0Frh5iBJF5VIiAszXzL05YgoDi_elcJ/view?usp=sharing"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <a href="https://drive.google.com/file/d/1m0Frh5iBJF5VIiAszXzL05YgoDi_elcJ/view?usp=sharing"><font size="3" color="#1155cc" face="Roboto, serif" style="font-size: 12pt"><u>https://drive.google.com/file/d/1m0Frh5iBJF5VIiAszXzL05YgoDi_elcJ/view?usp=sharing</u></font></a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_729627565" CREATED="1604083774990" MODIFIED="1604083774990"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3 class="western">
      <a name="_pkdi5k1xz47i">
</a>Таблица с данными
    </h3>
  </body>
</html>
</richcontent>
<node ID="ID_1515912557" CREATED="1604083774990" MODIFIED="1604083774990"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Файл содержит данные о станциях, линиях и пересадках.</font>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1139333333" CREATED="1604083774991" MODIFIED="1604083774991"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Ссылка на набор данных: </font>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1149692280" CREATED="1604083774996" MODIFIED="1604083774996" LINK="https://docs.google.com/spreadsheets/d/10zPtLt10wDzBD4qHC9xQpZDhuOuMgac_uYDetDaiZi4/edit?usp=sharing"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <a href="https://docs.google.com/spreadsheets/d/10zPtLt10wDzBD4qHC9xQpZDhuOuMgac_uYDetDaiZi4/edit?usp=sharing"><font size="3" color="#1155cc" face="Roboto, serif" style="font-size: 12pt"><u>https://docs.google.com/spreadsheets/d/10zPtLt10wDzBD4qHC9xQpZDhuOuMgac_uYDetDaiZi4/edit?usp=sharing</u></font></a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_254584946" CREATED="1604083774998" MODIFIED="1604083774998"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <a name="_ei6ouxce1maj">
</a>Описание задачи
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_678454478" CREATED="1604083775001" MODIFIED="1604083775001"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Участникам предлагается разработать интерактивную карту метро, которая будет доступна пользователю в мобильном приложении на платформах iOS и Android. </font>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1929081302" CREATED="1604083775002" MODIFIED="1604083775002"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt"><b>Возможности карты:</b></font>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_673133449" CREATED="1604083775003" MODIFIED="1604083775003"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3 class="western">
      <a name="_ixvgozwhpwpj">
</a>Зумирование
    </h3>
  </body>
</html>
</richcontent>
<node ID="ID_1620136847" CREATED="1604083775004" MODIFIED="1604083775004"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Возможность приблизить или отдалить карту метро. </font>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1643301682" CREATED="1604083775004" MODIFIED="1604083775004"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3 class="western">
      <a name="_461hv5gozwu1">
</a>Просмотр информации об остановке
    </h3>
  </body>
</html>
</richcontent>
<node ID="ID_220959838" CREATED="1604083775005" MODIFIED="1604083775005"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Возможность нажать на любую остановку метро и просмотреть основную информацию о ней: название, название и цвет линии, а также любую другую информацию, которую придумают участники задания в открытых источниках.</font>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_269202778" CREATED="1604083775006" MODIFIED="1604083775006"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3 class="western">
      <a name="_vqc7db255o51">
</a>Построение маршрутов по карте метров в режиме offline
    </h3>
  </body>
</html>
</richcontent>
<node ID="ID_52430252" CREATED="1604083775007" MODIFIED="1604083775007"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Реализовать возможность поиска оптимального маршрута по карте метро для пользователя. Возможность построить маршрут должна быть доступна без использования интернета. Выбор алгоритма для построения маршрута определяется участниками. </font>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_383657828" CREATED="1604083775008" MODIFIED="1604083775008"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <a name="_mvr7jp5t98k4">
</a>Требования к UI/UX
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_1543372796" CREATED="1604083775015" MODIFIED="1604083775015"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" style="font-size: 12pt">Внешний вид модуля и механика его взаимодействия с пользователем определяется командой самостоятельно. Необходимо уделить внимание скорости и плавности работы интерфейса.</font>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_613575945" CREATED="1604083775016" MODIFIED="1604083775016"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <a name="_3idwlbx5b1ty">
</a>Требования к технической реализации
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_1519465841" CREATED="1604083775025" MODIFIED="1604083775025"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Разработанное решение должно иметь возможность интеграции в существующее приложение, написанное на «нативных» языках (Swift/Kotlin). </font>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1127938895" CREATED="1604083775027" MODIFIED="1604083775027"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Часть модуля может содержать кроссплатформенную реализацию (например, модуль построения маршрута может быть написан на C++ и использован для обеих платформ), или полностью реализован на нативных языках платформ iOS/Android (Swift, Kotlin).</font>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_857476893" CREATED="1604083775031" MODIFIED="1604083775031"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <a name="_sb22083bsvpb">
</a>Контактные данные тех специалистов
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_475054485" CREATED="1604083775037" MODIFIED="1604083775037" LINK="https://t.me/issdev"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      Кирилл Шатров +7 (965) 328-95-36, <a href="https://t.me/issdev"><font color="#1155cc"><u>Telegram</u></font></a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_260823644" CREATED="1604083775038" MODIFIED="1604083775038" LINK="https://t.me/joinchat/GQLCKFTjyi-MTS5aDmuiJg"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      Чат в Telegram (для участников задачи): <a href="https://t.me/joinchat/GQLCKFTjyi-MTS5aDmuiJg"><font color="#1155cc"><u>https://t.me/joinchat/GQLCKFTjyi-MTS5aDmuiJg</u></font></a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1859304431" CREATED="1604083775038" MODIFIED="1604083775038"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      QR код для вступления в группу:
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_866731068" CREATED="1604083775040" MODIFIED="1604083775040"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <a name="_naevsb9kdseg">
</a>Контактные данные PR специалистов
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_1716379351" CREATED="1604083775046" MODIFIED="1604083775046" LINK="https://t.me/AnnRogozhina"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      Анна Рогожина <font size="2" style="font-size: 10pt">+7 (964) 789-08-51, </font><a href="https://t.me/AnnRogozhina"><font size="2" color="#1155cc" style="font-size: 10pt"><u>Telegram</u></font></a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Описание задачи ЦОДД анализ проверка соответствия" ID="ID_965621563" CREATED="1604083698495" MODIFIED="1604173653901">
<node ID="ID_873480914" CREATED="1604083774998" MODIFIED="1604083774998"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <a name="_ei6ouxce1maj">
</a>Описание задачи
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_1649801774" CREATED="1604083775001" MODIFIED="1604083775001"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Участникам предлагается разработать интерактивную карту метро, которая будет доступна пользователю в мобильном приложении на платформах iOS и Android. </font>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_151754115" CREATED="1604083775002" MODIFIED="1604083775002"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt"><b>Возможности карты:</b></font>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_718217762" CREATED="1604083775003" MODIFIED="1604083775003"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3 class="western">
      <a name="_ixvgozwhpwpj">
</a>Зумирование
    </h3>
  </body>
</html>
</richcontent>
<node ID="ID_173154572" CREATED="1604083775004" MODIFIED="1604083775004"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Возможность приблизить или отдалить карту метро. </font>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="есть" ID="ID_665939760" CREATED="1604172961957" MODIFIED="1604172968758"/>
</node>
</node>
<node ID="ID_698765807" CREATED="1604083775004" MODIFIED="1604083775004"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3 class="western">
      <a name="_461hv5gozwu1">
</a>Просмотр информации об остановке
    </h3>
  </body>
</html>
</richcontent>
<node ID="ID_246626418" CREATED="1604083775005" MODIFIED="1604083775005"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Возможность нажать на любую остановку метро и просмотреть основную информацию о ней: название, название и цвет линии, а также любую другую информацию, которую придумают участники задания в открытых источниках.</font>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="линк на сайт станции taganskaia.ru" ID="ID_187541661" CREATED="1604172983710" MODIFIED="1604173125995"/>
</node>
</node>
<node ID="ID_956726188" CREATED="1604083775006" MODIFIED="1604083775006"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3 class="western">
      <a name="_vqc7db255o51">
</a>Построение маршрутов по карте метров в режиме offline
    </h3>
  </body>
</html>
</richcontent>
<node ID="ID_782035957" CREATED="1604083775007" MODIFIED="1604083775007"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Реализовать возможность поиска оптимального маршрута по карте метро для пользователя. Возможность построить маршрут должна быть доступна без использования интернета. Выбор алгоритма для построения маршрута определяется участниками. </font>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="есть макет на технологии юнити" ID="ID_1754000852" CREATED="1604172961957" MODIFIED="1604173319888"/>
</node>
</node>
</node>
<node ID="ID_1809407487" CREATED="1604083775008" MODIFIED="1604083775008"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <a name="_mvr7jp5t98k4">
</a>Требования к UI/UX
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_561641950" CREATED="1604083775015" MODIFIED="1604083775015"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" style="font-size: 12pt">Внешний вид модуля и механика его взаимодействия с пользователем определяется командой самостоятельно. Необходимо уделить внимание скорости и плавности работы интерфейса.</font>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="есть" ID="ID_1417255443" CREATED="1604172961957" MODIFIED="1604172968758"/>
<node TEXT="есть максимальная плавность работы с аудио гидом на основе нашей базы" ID="ID_775429848" CREATED="1604173338540" MODIFIED="1604173437911"/>
<node TEXT="также это обеспечивает комфорт для слепых" ID="ID_1519026400" CREATED="1604173593698" MODIFIED="1604173611667"/>
</node>
</node>
<node ID="ID_1775940675" CREATED="1604083775016" MODIFIED="1604083775016"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <a name="_3idwlbx5b1ty">
</a>Требования к технической реализации
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_1614638434" CREATED="1604083775025" MODIFIED="1604083775025"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Разработанное решение должно иметь возможность интеграции в существующее приложение, написанное на «нативных» языках (Swift/Kotlin). </font>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="есть" ID="ID_1479929560" CREATED="1604172961957" MODIFIED="1604172968758">
<node TEXT="экспорт на iOS, Android" ID="ID_477642171" CREATED="1604173376589" MODIFIED="1604173390067"/>
</node>
</node>
<node ID="ID_147835534" CREATED="1604083775027" MODIFIED="1604083775027"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      <font size="3" face="Roboto, serif" style="font-size: 12pt">Часть модуля может содержать кроссплатформенную реализацию (например, модуль построения маршрута может быть написан на C++ и использован для обеих платформ), или полностью реализован на нативных языках платформ iOS/Android (Swift, Kotlin).</font>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="есть" ID="ID_147526202" CREATED="1604172961957" MODIFIED="1604172968758">
<node TEXT="экспорт на iOS, Android" ID="ID_522354687" CREATED="1604173376589" MODIFIED="1604173390067"/>
</node>
<node TEXT="есть еще план развития критериев оптимального маршрута в краткой форме, возможно требуются разъяснения из-за сверх краткости, либо надо вдумчиво карту читать, либо требуются комметарии, либо есть экранки с комментариями при составлении и обсуждении с командой" ID="ID_396492643" CREATED="1604173457639" MODIFIED="1604173551862"/>
</node>
</node>
<node ID="ID_241820734" CREATED="1604083775031" MODIFIED="1604083775031"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <a name="_sb22083bsvpb">
</a>Контактные данные тех специалистов
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_898709382" CREATED="1604083775037" MODIFIED="1604174000858" LINK="https://t.me/issdev"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      Кирилл Шатров +7 (965) 328-95-36, <a href="https://t.me/issdev"><font color="#1155cc"><u>Telegram</u></font></a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_235094371" CREATED="1604083775038" MODIFIED="1604083775038" LINK="https://t.me/joinchat/GQLCKFTjyi-MTS5aDmuiJg"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      Чат в Telegram (для участников задачи): <a href="https://t.me/joinchat/GQLCKFTjyi-MTS5aDmuiJg"><font color="#1155cc"><u>https://t.me/joinchat/GQLCKFTjyi-MTS5aDmuiJg</u></font></a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_598779359" CREATED="1604083775038" MODIFIED="1604083775038"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      QR код для вступления в группу:
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_857304339" CREATED="1604083775040" MODIFIED="1604083775040"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <a name="_naevsb9kdseg">
</a>Контактные данные PR специалистов
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_1496135382" CREATED="1604083775046" MODIFIED="1604175162113" LINK="https://t.me/AnnRogozhina"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p align="left" style="margin-bottom: 0cm">
      Анна Рогожина <font size="2" style="font-size: 10pt">+7 (964) 789-08-51, </font><a href="https://t.me/AnnRogozhina"><font size="2" color="#1155cc" style="font-size: 10pt"><u>Telegram</u></font></a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Автор: Соколов Николай Васильевич Cosmoteq Delta" ID="ID_592061320" CREATED="1604173664501" MODIFIED="1604173692956">
<node TEXT="Надеюсь на замечания и предложения" ID="ID_1771678432" CREATED="1604173692974" MODIFIED="1604173708478"/>
</node>
</node>
</node>
<node TEXT="20201030 2057 способы подачи решения" POSITION="right" ID="ID_1137263469" CREATED="1604080167380" MODIFIED="1604083880981">
<node TEXT="Что?" ID="ID_157375039" CREATED="1604080955947" MODIFIED="1604080975977">
<node TEXT="Зачем?" ID="ID_950994456" CREATED="1604080975985" MODIFIED="1604080990692">
<node TEXT="Кому?" ID="ID_110283496" CREATED="1604080990698" MODIFIED="1604081018793">
<node TEXT="Как?" ID="ID_1774133886" CREATED="1604081021503" MODIFIED="1604081027679"/>
</node>
</node>
</node>
<node TEXT="Что?" ID="ID_1777824999" CREATED="1604080955947" MODIFIED="1604080975977">
<node TEXT="Как?" ID="ID_594623683" CREATED="1604081021503" MODIFIED="1604081027679">
<node TEXT="Зачем?" ID="ID_1117614111" CREATED="1604080975985" MODIFIED="1604080990692">
<node TEXT="Кому?" ID="ID_1127087068" CREATED="1604080990698" MODIFIED="1604081018793"/>
</node>
</node>
</node>
<node TEXT="первая итерация использовать это с интеллект картой" ID="ID_140097506" CREATED="1604080670797" MODIFIED="1604080953261">
<node TEXT="Сделать 3д пролёт над картой с расставленными фрагментами, фото, роликами, тесктом" ID="ID_1279565626" CREATED="1604081071916" MODIFIED="1604081116573"/>
<node TEXT="В блендер" ID="ID_1804020638" CREATED="1604081128166" MODIFIED="1604081133849"/>
</node>
<node TEXT="использоваеть датасет с картой" ID="ID_1370391170" CREATED="1604081135764" MODIFIED="1604083661573">
<node TEXT="пролёт камеры по маршруту, опорные точки на маршруте с привязанными картинками и 3д объектами" ID="ID_1989170314" CREATED="1604083890741" MODIFIED="1604083958356"/>
</node>
<node TEXT="Решение" ID="ID_445549360" CREATED="1604083824322" MODIFIED="1604083829045">
<node TEXT="" ID="ID_128096939" CREATED="1604083829051" MODIFIED="1604083829051">
<node TEXT="сначала общая тема киллер фичи" ID="ID_5274134" CREATED="1604089056469" MODIFIED="1604089056469"/>
<node TEXT="рассказывать про фичи и наработки" ID="ID_823050161" CREATED="1604089056469" MODIFIED="1604089056469"/>
<node TEXT="на первый чек поинт не слишком много" ID="ID_1538203121" CREATED="1604089056470" MODIFIED="1604089056470"/>
<node TEXT="5 минут на обсуждение" ID="ID_567845174" CREATED="1604089056472" MODIFIED="1604089056472"/>
<node TEXT="побольше с менторами поговорить" ID="ID_440238186" CREATED="1604089056473" MODIFIED="1604089056473"/>
<node TEXT="что нужно а что не нужно" ID="ID_1660865054" CREATED="1604089056473" MODIFIED="1604089056473"/>
<node TEXT="в какую сторону надо" ID="ID_336099120" CREATED="1604089056475" MODIFIED="1604089056475"/>
<node TEXT="галвное получить фидбек" ID="ID_1492975819" CREATED="1604089056475" MODIFIED="1604089056475"/>
</node>
<node TEXT="Класс киллер фич" ID="ID_319015135" CREATED="1604089258557" MODIFIED="1604089276907">
<node TEXT="фича" ID="ID_890149395" CREATED="1604089276918" MODIFIED="1604089282934">
<node TEXT="наработки" ID="ID_1073191257" CREATED="1604089282937" MODIFIED="1604089285423"/>
</node>
</node>
</node>
</node>
<node TEXT="20201031 1115 чекпоинт" POSITION="right" ID="ID_138462402" CREATED="1604092821638" MODIFIED="1604177339290">
<node TEXT="ИСХОДНЫЕ ДАННЫЕ" ID="ID_1729793459" CREATED="1604130126756" MODIFIED="1604130132808">
<node TEXT="доп инфо с сайта хака" ID="ID_1255064772" CREATED="1602584748064" MODIFIED="1604096298229">
<node ID="ID_1622129753" CREATED="1602584828571" MODIFIED="1602584828571"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="62" align="left">
          <font face="Times New Roman">период проведения хакатона коллектив должен самостоятельно разработать прототип и презентацию проекта с целью решения выбранной задачи конкурса. </font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1229978017" CREATED="1602584828572" MODIFIED="1602584828572"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="47" align="left">
          <font face="Times New Roman">Оператор публикует полное описание задач конкурса на официальном сайте конкурса в день начала хакатона. </font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1145766041" CREATED="1602584828576" MODIFIED="1602584828576"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          догадки по датасету
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_599432088" CREATED="1602584828579" MODIFIED="1602584828579"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="62" align="left">
          <font face="Times New Roman">Разработка модуля интерактивной карты метро города Москвы с возможностью построения маршрута для мобильного приложения iOS и Android </font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1240907050" CREATED="1602584828581" MODIFIED="1602584828581"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">Интерактивная карта метро, которая будет доступна в мобильном приложении на платформах iOS и Android. Модуль включает в себя взаимодействие пользователя с картой, просмотр информации о станциях и построение оптимальных маршрутов не только в режиме online, но и без использования интернета.</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1389111400" CREATED="1602584828584" MODIFIED="1602586493317"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">Кроме того, для комфортной работы с картой, участникам необходимо уделить внимание скорости и плавности работы интерфейса</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Этапы" LOCALIZED_STYLE_REF="default" ID="ID_311900552" CREATED="1602584903733" MODIFIED="1602585860700">
<node LOCALIZED_STYLE_REF="default" ID="ID_1361599817" CREATED="1602584917749" MODIFIED="1602587055738"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="00" align="left">
          <font face="Times New Roman">−Сессии вопросов и ответов с экспертами по каждой задаче Конкурса (Q&amp;A сессии);</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_952208255" CREATED="1602584937267" MODIFIED="1602587048638"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="00" align="left">
          <font face="Times New Roman">−Разработка прототипов и презентаций проектов коллективами с целью решения выбранной коллективом задачи Конкурса;</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node LOCALIZED_STYLE_REF="default" ID="ID_1193098517" CREATED="1602584944079" MODIFIED="1602587062705" HGAP_QUANTITY="22.999999731779106 pt" VSHIFT_QUANTITY="-7.499999776482589 pt"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="00" align="left">
          <font face="Times New Roman">−Чекпоинты (Проверка экспертами прогресса коллективов);</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_570033935" CREATED="1602584951304" MODIFIED="1602587070234"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="00" align="left">
          <font face="Times New Roman">−Передача оператору прототипов и презентаций проектов;</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1738002891" CREATED="1602585905046" MODIFIED="1602587075452"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="00" align="left">
          <font face="Times New Roman">−Предварительная экспертиза прототипов и презентаций проектов;</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1317653736" CREATED="1602585917199" MODIFIED="1602587080246"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="00" align="left">
          <font face="Times New Roman">−Публикация списка коллективов, допущенных до участия в питч-сессиях;</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1970770221" CREATED="1602585923021" MODIFIED="1602587085895"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="00" align="left">
          <font face="Times New Roman">−Питч-сессии по каждой из 10 задач конкурса.</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_87106602" CREATED="1602584828590" MODIFIED="1602584828590"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="92" align="left">
          <font face="Times New Roman">Прогресс работы коллективов над созданиемв течение хакатона проверяется экспертами в течение чекпоинтов. Порядок прохождения и подробное расписание чекпоинтов будет опубликовано оператором в личном кабинете участника не позднее начала хакатона. </font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_1943322386" CREATED="1602584838076" MODIFIED="1602584838076"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="17" align="left">
          онлайн
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1407694247" CREATED="1602584838078" MODIFIED="1602584838078"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="32" align="left">
          офлайн навигация
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1304158147" CREATED="1602584838086" MODIFIED="1602584838086"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="32" align="left">
          сбор данных со среды
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_347330797" CREATED="1602584838092" MODIFIED="1602584838092"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="62" align="left">
          мнемо схемы для пользователя
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_207583007" CREATED="1602584828594" MODIFIED="1602584828594"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="62" align="left">
          <font face="Times New Roman">Требования к содержанию и оформлению презентаций проектов будут опубликованы оператором в личном кабинете участника в разделе «Важная информация» в первый день хакатона. </font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1721199688" CREATED="1602584828619" MODIFIED="1602715300032"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="92" align="left">
          <font face="Times New Roman">Предварительная экспертиза прототипов и презентаций проектов проводится по шкале от 0 до 2 баллов в соответствии со следующим критериям: </font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_47127872" CREATED="1602715301162" MODIFIED="1602715301162"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="92" align="left">
          <font face="Times New Roman">−Работоспособность программного кода прототипа;−Решение прототипом выбранной коллективом задачи конкурса </font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="apk приложение" ID="ID_292287155" CREATED="1604172845007" MODIFIED="1604172862982"/>
<node TEXT="исходники" ID="ID_1308357184" CREATED="1604172863273" MODIFIED="1604172872794"/>
<node TEXT="" ID="ID_1743016660" CREATED="1604172882678" MODIFIED="1604172882678"/>
</node>
</node>
<node ID="ID_1182848164" CREATED="1602584828624" MODIFIED="1602715292706"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="136" align="left">
          <font face="Times New Roman">Члены комиссии по присуждению премий Мэра Москвы «Лидеры цифровой трансформации» голосуют по 0 до 4 с шагом 1 согласно следующим критериям:</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_1139425874" CREATED="1602715293971" MODIFIED="1602715293971"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="136" align="left">
          <font face="Times New Roman">−Технологическая реализация прототипа; −Оригинальность решений и подходов, использованных коллективом при разработке прототипа; −Проработка продуктовой части прототипа; −Оценка выступления коллектива на питч-сессии </font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="анализ формулировки исходного ТЗ" ID="ID_1836180575" CREATED="1603740657482" MODIFIED="1604130123778">
<node ID="ID_669728894" CREATED="1602584537749" MODIFIED="1602584537749"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="62" align="left">
          <font face="Times New Roman">Разработка модуля интерактивной карты метро города Москвы с возможностью построения маршрута для мобильного приложения iOS и Android </font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_1737359210" CREATED="1602584537755" MODIFIED="1602584537755"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">Разработка модуля</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_253224673" CREATED="1602584537783" MODIFIED="1602584537783"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          Какие есть существующие приложения города москвы?
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="ЦОДД" ID="ID_145771935" CREATED="1602589604385" MODIFIED="1602589608016"/>
<node TEXT="Департамент транспорта" ID="ID_1989777631" CREATED="1602589609112" MODIFIED="1602589615297"/>
<node TEXT="Яндекс карты" ID="ID_386134783" CREATED="1602589618332" MODIFIED="1602589622579"/>
<node TEXT="2ГИС" ID="ID_471310438" CREATED="1602589623088" MODIFIED="1602589631967"/>
<node TEXT="Парковки" ID="ID_1407696634" CREATED="1602699834050" MODIFIED="1602699842707"/>
</node>
<node ID="ID_221416458" CREATED="1602584537788" MODIFIED="1602584537788"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          Какие там есть дизайн решения?
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="не знаю" ID="ID_90288875" CREATED="1602699858802" MODIFIED="1602699861715"/>
<node TEXT="скачать приложения и посмотреть" ID="ID_1607011469" CREATED="1602699862692" MODIFIED="1602699873805">
<node TEXT="папка снимков приложений" ID="ID_1819036702" CREATED="1602699883188" MODIFIED="1602699891392"/>
</node>
</node>
<node ID="ID_826342644" CREATED="1602584537801" MODIFIED="1602584537801"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          Возможно ли выцепить и подстроиться под дизайн
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_665036071" CREATED="1602584537807" MODIFIED="1602584537807"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          Есть ли свои наработки и предложения по дизайну?
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="Способ ранжирования материалов в процессе чтения" ID="ID_920132895" CREATED="1602712623264" MODIFIED="1602712642678">
<node TEXT="дизайн ёлка, вертикальный скролл дополнен горизонтальными треугольными блоками, которые можно смотреть свайпом вправо и влево" ID="ID_1450510799" CREATED="1602699897684" MODIFIED="1602699970947"/>
<node TEXT="каждый треуголинк начинается с пикрограммы и заканчивается боковой гранью с перечнем релевантных опций" ID="ID_926896826" CREATED="1602707180747" MODIFIED="1602707238955"/>
</node>
<node TEXT="AR подход для навигации в метро" ID="ID_231681418" CREATED="1602712602285" MODIFIED="1602712832992">
<node TEXT="Сделать внедрение АР механик для упрощения верификации, обоснования внимания на экран, обеспечения возможности внедрения рекламы за период внимания, потребности включения камеры, применения в связке с мелокальными визуальными метками, потребностью подзарядки, верофикации локации, демонтрации игровых техник" ID="ID_140862881" CREATED="1602712665042" MODIFIED="1602712856190">
<node TEXT="оверлей при распознавании визуальных меток" ID="ID_1253958256" CREATED="1602712856227" MODIFIED="1602712882351"/>
<node TEXT="оверлей при наведении на потолок может показывать камеру с погодой на улице онлайн" ID="ID_1617797923" CREATED="1602712868285" MODIFIED="1602712913847"/>
<node TEXT="оверлей на эскалаторе, когда человек поднимается то может навести телефон на стены через наше приложение и тогда увидит рекламу или купон на кофе" ID="ID_126382973" CREATED="1602712923970" MODIFIED="1602713264792"/>
<node TEXT="действует только когда вниз едешь( а то вверх небезопасно)" ID="ID_1938655831" CREATED="1602713279446" MODIFIED="1602713310418"/>
</node>
</node>
</node>
<node TEXT="Где получить консультацию по применяемым платформам и решениям?" ID="ID_383753768" CREATED="1602699989401" MODIFIED="1602707253608">
<node TEXT="Участники команды" ID="ID_1176366962" CREATED="1602707264316" MODIFIED="1602707272010">
<node TEXT="игорь плазматэк" ID="ID_1479392696" CREATED="1602713335653" MODIFIED="1602713340215"/>
<node TEXT="Дмитрий Аркидс" ID="ID_729273934" CREATED="1602713340855" MODIFIED="1602713349100"/>
<node TEXT="Наташа Cerevrum" ID="ID_380522799" CREATED="1602713358690" MODIFIED="1602713380166"/>
</node>
<node TEXT="Данные заказчика" ID="ID_117275942" CREATED="1602707272172" MODIFIED="1602707278505"/>
</node>
</node>
<node ID="ID_1589962100" CREATED="1602584537813" MODIFIED="1602584537813"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">интерактивной карты метро </font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="Эскизный подход в1" ID="ID_714866564" CREATED="1602700316134" MODIFIED="1602700332641">
<node TEXT="непонятно что думать" ID="ID_1397957144" CREATED="1602700297500" MODIFIED="1602700303190"/>
<node TEXT="первое что приходит в голову это отрисовка 3д моделей подземных тоннелей, но считаю это небезопасным... и накладным с плане работ по созданию" ID="ID_1934676806" CREATED="1602700016978" MODIFIED="1602700478767"/>
<node TEXT="второе это тунелли из наблюдения за логами акселерометров в пространстве как 3д мышки, Решение представляет из себя  генерацию визуализаций тоннелей из наблюдаемых данных с акселерометров, вот взять таких 50 аппаратов и видно потоки движения в объеме" ID="ID_1739101095" CREATED="1602700257565" MODIFIED="1602713412102"/>
<node TEXT="в друой ветке рассмотреть все множества источников данных и их комбинации" ID="ID_1677847508" CREATED="1602700493271" MODIFIED="1602700518633"/>
</node>
<node TEXT="должна быть карта" ID="ID_1015251654" CREATED="1602700343876" MODIFIED="1602700351481"/>
<node TEXT="как представить карту?" ID="ID_1546097362" CREATED="1602700352712" MODIFIED="1602700357826"/>
<node TEXT="всем известны карты города на примере гугл, яндекс, 2гис, старых москоу мэп" ID="ID_1503898956" CREATED="1602700359721" MODIFIED="1602700403651"/>
<node TEXT="Как проанализировать опыт до текущего момента по картам?" ID="ID_1453670659" CREATED="1602700410859" MODIFIED="1602700424957"/>
<node TEXT="ответ сразу" ID="ID_1566062254" CREATED="1602700425885" MODIFIED="1602700533740">
<node TEXT="подобно графическому редактору представить 1) слои кааждого элемента станции 2)карта на слое 3)функции быстрого совмещения 4)размер общего слоя как сумма всех слоёв станции" ID="ID_659932759" CREATED="1602700533747" MODIFIED="1602700653395"/>
<node TEXT="Как представить? человек открывает станцию видит слой вестибюля, (возможно в шапке хайтэк в виде общей модели станции - это несколько цветных слоев спозиционированных друг относительно друга. между стоями есть трубы- обозначающие переходы и они соответствуют реальному плану в зависимости от режима просмотра. Режим просмотра может быть схематический, а может быть реальный в плане отображения расстояний на слоях и в трубах тоннелях) модель способна к детализации: 1)отображение количества эскалаторов в трубах 2)типовые потоки людей на карте платформы станции, как статистически основные, так и путь пассажира по маршруту" ID="ID_1385386058" CREATED="1602700654954" MODIFIED="1602701041615">
<node TEXT="слой станции" ID="ID_1230464653" CREATED="1602701055620" MODIFIED="1602701071122">
<node TEXT="колонны" ID="ID_1330903133" CREATED="1602701071138" MODIFIED="1602701077102"/>
<node TEXT="символика где первый вагон" ID="ID_637341255" CREATED="1602701078079" MODIFIED="1602701107173"/>
<node TEXT="символика где последний вагон" ID="ID_1754311555" CREATED="1602701107703" MODIFIED="1602701117869"/>
<node TEXT="карта QR для вериыикации своего положения" ID="ID_931618058" CREATED="1602701121297" MODIFIED="1602701143377"/>
<node TEXT="Карта динамических QR кодов" ID="ID_794182116" CREATED="1602701144334" MODIFIED="1602701157921"/>
<node TEXT="Карта статических QR" ID="ID_979134421" CREATED="1602701158823" MODIFIED="1602701170278"/>
<node TEXT="Сделать каждый QR сопровожденными символьночисловым кодом, человеко понятным" ID="ID_156431568" CREATED="1602701172911" MODIFIED="1602701468337"/>
<node TEXT="Сделать сервер QR  для сбора статистики и применения динамических ссылок" ID="ID_1314849072" CREATED="1602701477884" MODIFIED="1602701522298"/>
</node>
</node>
</node>
<node TEXT="способы навигации, точнее способы определения и верификации координат" ID="ID_1709920026" CREATED="1602701548081" MODIFIED="1602709904198">
<node TEXT="от внутренних к внешним" ID="ID_328844940" CREATED="1602701559865" MODIFIED="1602701581766"/>
<node TEXT="акселерометры" ID="ID_1781140835" CREATED="1602701582275" MODIFIED="1602701589772"/>
<node TEXT="магнитометры" ID="ID_195783244" CREATED="1602701591801" MODIFIED="1602701605346"/>
<node TEXT="режим датчика шагомера" ID="ID_164377897" CREATED="1602701596557" MODIFIED="1602701619481"/>
<node TEXT="оптические" ID="ID_1183141622" CREATED="1602706126771" MODIFIED="1602706136952">
<node TEXT="камера" ID="ID_1946383342" CREATED="1602701626407" MODIFIED="1602701645125">
<node TEXT="легко машиночитаемый QR" ID="ID_804327342" CREATED="1602712456561" MODIFIED="1602712502079"/>
<node TEXT="локальная верификация" ID="ID_1462607494" CREATED="1602712503176" MODIFIED="1602712512933"/>
<node TEXT="надёжнее динамический QR на дисплее" ID="ID_368768239" CREATED="1602712515373" MODIFIED="1602712543744"/>
<node TEXT="Сделать связку с QR на дисплеях в метро" ID="ID_952332116" CREATED="1602712544456" MODIFIED="1602712559328"/>
</node>
<node TEXT="ик датчик" ID="ID_1953698041" CREATED="1602701645636" MODIFIED="1602701648156"/>
<node TEXT="LIFI" ID="ID_985217002" CREATED="1602706454766" MODIFIED="1602706466908">
<node TEXT="код локации в мигании светодиодами" ID="ID_900153011" CREATED="1602713460598" MODIFIED="1602713480831"/>
</node>
<node TEXT="AI camera" ID="ID_365952893" CREATED="1602706467632" MODIFIED="1602706481609">
<node TEXT="распознавание скульптур" ID="ID_1496594782" CREATED="1602712476543" MODIFIED="1602713452471"/>
</node>
</node>
<node TEXT="радио" ID="ID_653037278" CREATED="1602701648531" MODIFIED="1602706107892">
<node TEXT="WiFi" ID="ID_809795777" CREATED="1602706110995" MODIFIED="1602706119400"/>
<node TEXT="Wifi 6" ID="ID_1105159616" CREATED="1602706187539" MODIFIED="1602706191970"/>
<node TEXT="Bluetooth" ID="ID_1789478068" CREATED="1602706120286" MODIFIED="1602706186149"/>
<node TEXT="GPS GLONASS BeiDou или BDS" ID="ID_1453629491" CREATED="1602706212608" MODIFIED="1602706426152"/>
</node>
<node TEXT="акустические" ID="ID_234926249" CREATED="1602706163550" MODIFIED="1602706171171">
<node TEXT="mic" ID="ID_441940766" CREATED="1602706445704" MODIFIED="1602706453853"/>
</node>
<node TEXT="биометрические" ID="ID_1663606830" CREATED="1602709908006" MODIFIED="1602709917794">
<node TEXT="эта персона" ID="ID_656576833" CREATED="1602709917814" MODIFIED="1602709921204">
<node TEXT="тут и нигде в другом месте" ID="ID_1199579005" CREATED="1602709922131" MODIFIED="1602709932565"/>
</node>
<node TEXT="голос пользователя" ID="ID_937498502" CREATED="1602709964962" MODIFIED="1602709971231">
<node TEXT="устный ввод локации с разпознаванием голоса" ID="ID_1446991698" CREATED="1602710082109" MODIFIED="1602710098626"/>
<node TEXT="парсинг локации по внутреннй базе примет" ID="ID_1910493460" CREATED="1602710099318" MODIFIED="1602710119553"/>
<node TEXT="AI навигатор по приметам локации" ID="ID_1825946460" CREATED="1602710120329" MODIFIED="1602710137459"/>
</node>
<node TEXT="отпечаток пальцев пользователя" ID="ID_1123441314" CREATED="1602709972864" MODIFIED="1602709986106">
<node TEXT="по лицу передаём локацию на телефон" ID="ID_422855204" CREATED="1602713534391" MODIFIED="1602713548752"/>
</node>
<node TEXT="биометрия пользователя, те доп датчики, например браслет" ID="ID_1408029462" CREATED="1602709988877" MODIFIED="1602710016057">
<node TEXT="меряем пульс, считаем нагрузку на организм" ID="ID_54248834" CREATED="1602710017464" MODIFIED="1602710030950"/>
<node TEXT="известно что пульс пропорционале шагам" ID="ID_1317650477" CREATED="1602710031131" MODIFIED="1602710050709"/>
</node>
</node>
</node>
</node>
<node ID="ID_1350061014" CREATED="1602584537820" MODIFIED="1602584537820"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">Интерактивная карта метро</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="интерактивная - означает возможность взаимодействия" ID="ID_965013485" CREATED="1602706596572" MODIFIED="1602710202135">
<node TEXT="Какой интерактив возможен?" ID="ID_1718684594" CREATED="1602706677857" MODIFIED="1602706774866"/>
<node TEXT="Как функции интерактива сортировать по степени важности?" ID="ID_1925559578" CREATED="1602706730865" MODIFIED="1602706791137"/>
<node TEXT="Какие функции являются уже привычными?" ID="ID_1515530755" CREATED="1602706743283" MODIFIED="1602706768588"/>
<node TEXT="Для кого сортировать?" ID="ID_1070091351" CREATED="1602706792980" MODIFIED="1602706800825"/>
</node>
<node TEXT="метро - значит элементы метро" ID="ID_162320293" CREATED="1602706660616" MODIFIED="1602706674039">
<node TEXT="какие элементы метро мы знаем?" ID="ID_235900120" CREATED="1602706695879" MODIFIED="1602706706354"/>
<node TEXT="Как ранжировать элементы метро?" ID="ID_1656650901" CREATED="1602706711613" MODIFIED="1602706729083"/>
</node>
</node>
<node ID="ID_885261802" CREATED="1602584537826" MODIFIED="1602584537826"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">метро города Москвы</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="Чем метро Москвы отличается от других метро?" ID="ID_933710383" CREATED="1602706833169" MODIFIED="1602706858978">
<node TEXT="большой город -возникают перегрузка пассажирова потока, возникает потребность регулировки в режиме рекомендательного сервиса" ID="ID_94704037" CREATED="1602710215933" MODIFIED="1602710265424"/>
<node TEXT="множество альтернатив пути и задач пассажира" ID="ID_1308759725" CREATED="1602710271297" MODIFIED="1602710292106"/>
</node>
<node TEXT="Почему только метро?" ID="ID_1651226354" CREATED="1602706871531" MODIFIED="1602706877539">
<node TEXT="самый предсказуемы по времени на передвижение, для штатного режима" ID="ID_536836893" CREATED="1602710296267" MODIFIED="1602710330491"/>
</node>
<node TEXT="Как продолжить связь маршрута не с метро?" ID="ID_1402631915" CREATED="1602706878605" MODIFIED="1602706899205">
<node TEXT="С чем связь?" ID="ID_514596627" CREATED="1602710350815" MODIFIED="1602710364515">
<node TEXT="другой транспорт" ID="ID_159714122" CREATED="1602710437028" MODIFIED="1602710443751">
<node TEXT="автобусы" ID="ID_201706615" CREATED="1602710336738" MODIFIED="1602710342497"/>
<node TEXT="трамваи" ID="ID_303103868" CREATED="1602710342871" MODIFIED="1602710345188"/>
<node TEXT="легкое метро" ID="ID_1525673811" CREATED="1602710345354" MODIFIED="1602710350680"/>
<node TEXT="перехватывающие парковки" ID="ID_1703473557" CREATED="1602710371707" MODIFIED="1602710388789"/>
<node TEXT="парковки" ID="ID_1141368972" CREATED="1602710389995" MODIFIED="1602710393515"/>
<node TEXT="поезда" ID="ID_779188848" CREATED="1602710395103" MODIFIED="1602710400924"/>
<node TEXT="самолёт" ID="ID_1910912668" CREATED="1602710401325" MODIFIED="1602710404821"/>
<node TEXT="такси" ID="ID_1011182872" CREATED="1602710405174" MODIFIED="1602710408126"/>
</node>
<node TEXT="гео локация" ID="ID_1880555208" CREATED="1602710459178" MODIFIED="1602710466456">
<node TEXT="дом" ID="ID_444059641" CREATED="1602710408329" MODIFIED="1602710414419"/>
<node TEXT="магазин" ID="ID_1748370371" CREATED="1602710414716" MODIFIED="1602710429959"/>
<node TEXT="ресторан" ID="ID_476612887" CREATED="1602710419175" MODIFIED="1602710422646"/>
<node TEXT="услуги" ID="ID_310190586" CREATED="1602710422792" MODIFIED="1602710424789"/>
</node>
<node TEXT="другой движущийся человек" ID="ID_1249819065" CREATED="1602710473445" MODIFIED="1602710483512"/>
</node>
<node TEXT="статические" ID="ID_1337263908" CREATED="1602710505799" MODIFIED="1602710512563">
<node TEXT="дом" ID="ID_1154128994" CREATED="1602710519463" MODIFIED="1602710522205"/>
<node TEXT="дом с расписанием" ID="ID_814463222" CREATED="1602710552681" MODIFIED="1602710560818">
<node TEXT="Сделать функцию проверки попадания в рабочий график учреждения с учётом проезди требуемого рабочего времени" ID="ID_947554984" CREATED="1602710678210" MODIFIED="1602710721425"/>
<node TEXT="Сервис проверки доступности усреждения для того лили иного случая" ID="ID_1288604572" CREATED="1602710729321" MODIFIED="1602710750304"/>
<node TEXT="Производная сервисы в пути - проведение подготовительной работы за счёт связи с оператором в дороге" ID="ID_47814376" CREATED="1602710751765" MODIFIED="1602710784792"/>
</node>
</node>
<node TEXT="динамические" ID="ID_207898918" CREATED="1602710512994" MODIFIED="1602710517286">
<node TEXT="другой транспорт с расписанием" ID="ID_1323543186" CREATED="1602710526273" MODIFIED="1602710536145"/>
<node TEXT="другой человек с другим маршрутом" ID="ID_1052626754" CREATED="1602710536386" MODIFIED="1602710551318"/>
<node TEXT="по доступности данных" ID="ID_1831376311" CREATED="1602710620078" MODIFIED="1602710629687">
<node TEXT="режим онлайн" ID="ID_943961958" CREATED="1602710629692" MODIFIED="1602710635743"/>
<node TEXT="расписание" ID="ID_211263531" CREATED="1602710636115" MODIFIED="1602710639995"/>
<node TEXT="возможность интерполяции и прогнозирования" ID="ID_891903757" CREATED="1602710640198" MODIFIED="1602710662817"/>
</node>
</node>
</node>
</node>
<node ID="ID_10274079" CREATED="1602584537832" MODIFIED="1602584537832"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">с возможностью построения маршрута</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="Маршрут в рамках метро?" ID="ID_1238994412" CREATED="1602706913929" MODIFIED="1602706933774">
<node TEXT="Сделать выбор начальной и конечной станции" ID="ID_551757136" CREATED="1602710816113" MODIFIED="1602710835229"/>
</node>
<node TEXT="Маршрут сводяцийся к рамкам метро?" ID="ID_58534887" CREATED="1602706913929" MODIFIED="1602710868270">
<node TEXT="Сделать выбор начальной и конечной локации на карте с переключением контекста на станции, те от какой до какой станции ехать" ID="ID_1326401762" CREATED="1602710816113" MODIFIED="1602710907901"/>
<node TEXT="Сделать переключение на участки карты от локации до станции и от станции до локации" ID="ID_709444195" CREATED="1602710908360" MODIFIED="1602710951248"/>
</node>
<node TEXT="Маршрут в рамках станций метро?" ID="ID_195793618" CREATED="1602706934267" MODIFIED="1602706940729">
<node TEXT="Сделать демонстрацию возможных маршрутов по линиям метро и выбор желаемого варинта" ID="ID_987371720" CREATED="1602710974895" MODIFIED="1602711178976"/>
<node TEXT="Сделать отображение рейтинга сложности переходов и навигации по ним" ID="ID_1387771779" CREATED="1602711228064" MODIFIED="1602711287313"/>
</node>
<node TEXT="Маршрут в рамках метро и города?" ID="ID_169145747" CREATED="1602706944085" MODIFIED="1602706950384">
<node TEXT="Сделать рекомендации по детуру, если это может быть выгодно пассажиру с учётом свободного времени на проезд" ID="ID_1755766446" CREATED="1602711302017" MODIFIED="1602711342632"/>
<node TEXT="Сделать поле ввод свободного времени для предложения неоптимального с точки зрения длины маршрута" ID="ID_79549918" CREATED="1602711342809" MODIFIED="1602711383171"/>
<node TEXT="Сделать предложения оптимизирующие загрузку линий и сервисов города, а не времени на перемещение" ID="ID_308363373" CREATED="1602711385185" MODIFIED="1602711427446"/>
<node TEXT="Сделать QR или номер для отображения быстрой навигации относительно контрольной точки введенной пользователем" ID="ID_1156276690" CREATED="1602711580371" MODIFIED="1602711653888"/>
</node>
<node TEXT="Маршрут в рамках метро и наземного транспорта?" ID="ID_1274548999" CREATED="1602706952508" MODIFIED="1602706975901">
<node TEXT="Сделать оценку альтернативных способо перемещения и предложения по ним." ID="ID_1812479346" CREATED="1602711487689" MODIFIED="1602711518753"/>
<node TEXT="Сделать предложение с визуализацией модели станций, но от выхода на поерхности до остановки автобуса и тп по каждому из выходов" ID="ID_1542830828" CREATED="1602711520247" MODIFIED="1602711573240"/>
</node>
<node TEXT="Маршрут в рамках метро и всех прилегающих транспортных систем или видов транспорта?" ID="ID_1584066984" CREATED="1602706961980" MODIFIED="1602707023193">
<node TEXT="Сделать апи для запроса прибытия" ID="ID_1225893614" CREATED="1602711670688" MODIFIED="1602711703245">
<node TEXT="автобуса" ID="ID_393326852" CREATED="1602711703263" MODIFIED="1602711707538"/>
<node TEXT="такси" ID="ID_307549152" CREATED="1602711707905" MODIFIED="1602711712306"/>
<node TEXT="свободного велика" ID="ID_831548545" CREATED="1602711712458" MODIFIED="1602711753187"/>
</node>
<node TEXT="Сделать апи для запроса прибытия другого транспорта из статистичекой базы данных а не фактического расположения, либо из усреднение из базы аналогичных запросов" ID="ID_585908700" CREATED="1602711756566" MODIFIED="1602711807858"/>
</node>
<node TEXT="Маршрут с учетом чего?" ID="ID_816556756" CREATED="1602707075102" MODIFIED="1602707094477">
<node TEXT="Рассмотреть применение алгоримов искусственного интеллекта для поиска по реляционным данным маршрута" ID="ID_1582102108" CREATED="1602711836836" MODIFIED="1602711865273"/>
</node>
<node TEXT="Маршрут требует ли учёта доп параметров?" ID="ID_537817785" CREATED="1602707096880" MODIFIED="1602707119229">
<node TEXT="Создать дасет пользовательских данных и их сигнальных элементов в интерфецсе для детектирования дополнительных потребностей пользователя в коллеляции с наземными сервисами" ID="ID_1450331408" CREATED="1602711871102" MODIFIED="1602711938672"/>
<node TEXT="Создать перечень доп серивсов и сопоставить их для дополнения сигнальными жлементами в интерфейсе" ID="ID_1127919978" CREATED="1602711940132" MODIFIED="1602711995423"/>
<node TEXT="Сделать поле попутка или вдорожку, где можно печатать ключевые слова что может дороге пригодиться, и сделать при наборе подрузку галерей, где можно лайкать - опционально" ID="ID_86552703" CREATED="1602712005894" MODIFIED="1602712104016"/>
<node TEXT="Сделать страницу монитор - &quot;лови момент для кофе, сувенирки, ивентов&quot;, где отображается цена\время\время-на-детур\скидка-на-момент\наличие-купонов" ID="ID_1555803791" CREATED="1602712105120" MODIFIED="1602712225236"/>
</node>
</node>
<node ID="ID_1053967112" CREATED="1602584537837" MODIFIED="1602584537837"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">для мобильного приложения iOS и Android </font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_1805357826" CREATED="1602584537842" MODIFIED="1602584537842"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          какие есть варианты универсальной реализации кода под разные платформы для упрощения интеграции?
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1676070662" CREATED="1602584537847" MODIFIED="1602584537847"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          решение типа PWA c оффлайн джаваскриптами
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Есть ли требования к языку написания решения?" ID="ID_956494120" CREATED="1602707147913" MODIFIED="1602707161469"/>
</node>
</node>
<node ID="ID_1186582326" CREATED="1602584537853" MODIFIED="1604130123776"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="121" align="left">
          <font face="Times New Roman">Интерактивная карта метро, которая будет доступна в мобильном приложении на платформах iOS и Android. Модуль включает в себя взаимодействие пользователя с картой, просмотр информации о станциях и построение оптимальных маршрутов не только в режиме online, но и без использования интернета.</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_830819659" CREATED="1602584537861" MODIFIED="1602584537861"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">которая будет доступна в мобильном приложении на платформах iOS и Android</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="Если это часть, модуль другого ПО, то какие там библиотеки?" ID="ID_1772579977" CREATED="1602707371730" MODIFIED="1602707397974">
<node TEXT="Найти примеры приложений от заказчика" ID="ID_1986335381" CREATED="1602712252882" MODIFIED="1602712281296"/>
</node>
<node TEXT="Есть ли стандартные графические элементы?" ID="ID_843839636" CREATED="1602707416612" MODIFIED="1602707438193">
<node TEXT="Найти примеры приложений от заказчика" ID="ID_965376947" CREATED="1602712252882" MODIFIED="1602712281296"/>
</node>
<node TEXT="Какие свои элементы необходимо сделать?" ID="ID_671465703" CREATED="1602707454187" MODIFIED="1602707482534">
<node TEXT="векторный слой над слоем, соединение точек, переключение режимов расстояний карикатура и реальный вид - и всё это в 3д" ID="ID_1833583471" CREATED="1602712291242" MODIFIED="1602712346009"/>
<node TEXT="ARKIT?" ID="ID_1877118338" CREATED="1602712346784" MODIFIED="1602712355692"/>
</node>
</node>
<node ID="ID_1270738374" CREATED="1602707494000" MODIFIED="1602707497224"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">Модуль включает в себя</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="Модуль это вероятно подраздел меню с функционалом не пересекающимся с другими разделами меню?" ID="ID_750914832" CREATED="1602707501706" MODIFIED="1602707535617">
<node TEXT="да" ID="ID_647788094" CREATED="1602707901865" MODIFIED="1602707905789">
<node TEXT="ограничить функционал" ID="ID_302341252" CREATED="1602707905793" MODIFIED="1602707913461"/>
</node>
</node>
<node TEXT="А если пересекается с другими модулями, то с какими элементами?" ID="ID_1408425264" CREATED="1602707576399" MODIFIED="1602707802815">
<node TEXT="Сделать персонализацию маршрута пользователя" ID="ID_1673085474" CREATED="1602707813061" MODIFIED="1602707833047"/>
<node TEXT="Добавить типовые маршруты пользователя" ID="ID_1157013678" CREATED="1602707833553" MODIFIED="1602707854943"/>
<node TEXT="Сделать апи для связи с другими модулями" ID="ID_204906240" CREATED="1602707855165" MODIFIED="1602707885240"/>
<node TEXT="Данные пользователя" ID="ID_1984515594" CREATED="1602707922377" MODIFIED="1602707929379"/>
<node TEXT="Сделать на основании планирвоания проезда предупреждения о нехватке билета" ID="ID_1832673006" CREATED="1602707929767" MODIFIED="1602707979005"/>
<node TEXT="Сделать функцию скидок на билеты при покупке других билетов" ID="ID_1907011672" CREATED="1602707979385" MODIFIED="1602708004299"/>
<node TEXT="Сделать рекомендации по врепмени проезда" ID="ID_105463949" CREATED="1602708013596" MODIFIED="1602712403965"/>
<node TEXT="Сделать рекомендации по дате проезда всвязи с проводимыми мероприями различной природы, как позитивный прогноз так и негативный" ID="ID_1228288272" CREATED="1602708022754" MODIFIED="1602708067550"/>
<node TEXT="Привязка к телефону пользователя" ID="ID_1159485856" CREATED="1602708085286" MODIFIED="1602708517192">
<node TEXT="Сделать постинг локальных групп и чатов" ID="ID_1458408322" CREATED="1602708101808" MODIFIED="1602708121887"/>
<node TEXT="Телеграм" ID="ID_1691381160" CREATED="1602708123297" MODIFIED="1602708125800"/>
<node TEXT="Вотсап" ID="ID_1583683709" CREATED="1602708126940" MODIFIED="1602708129166"/>
<node TEXT="Вк" ID="ID_1566254196" CREATED="1602708129324" MODIFIED="1602708140983"/>
<node TEXT="Мос" ID="ID_24826460" CREATED="1602708141792" MODIFIED="1602708143540"/>
<node TEXT="Фб" ID="ID_1605089568" CREATED="1602708143921" MODIFIED="1602708147081"/>
<node TEXT="Инстаграмм" ID="ID_426704840" CREATED="1602708147555" MODIFIED="1602708151981"/>
<node TEXT="Салон связи" ID="ID_698094269" CREATED="1602708152335" MODIFIED="1602708165872"/>
<node TEXT="" ID="ID_74912736" CREATED="1602708166471" MODIFIED="1602708166471"/>
</node>
<node TEXT="Есть ли у пользователя есть доп транпорт?" ID="ID_528707218" CREATED="1602708094904" MODIFIED="1602708379375">
<node TEXT="каршеринг" ID="ID_383096311" CREATED="1602708215876" MODIFIED="1602708219302">
<node TEXT="Сделать поиск подбор свободного авто или линк рестапи для перехода в приложение партнёра" ID="ID_1497327852" CREATED="1602708261203" MODIFIED="1602708316610"/>
</node>
<node TEXT="своя машина" ID="ID_1841611063" CREATED="1602708219468" MODIFIED="1602708248113">
<node TEXT="Сделать поиск свободной парковки" ID="ID_1460622984" CREATED="1602708270228" MODIFIED="1602708334699"/>
</node>
<node TEXT="свой самокат" ID="ID_321118835" CREATED="1602708222536" MODIFIED="1602708251412">
<node TEXT="Сделать поиск парковки или хранилища для самокатов" ID="ID_1966867269" CREATED="1602708338937" MODIFIED="1602708359256"/>
</node>
<node TEXT="свой велосипед" ID="ID_1875444604" CREATED="1602708224401" MODIFIED="1602708253945">
<node TEXT="Сделать поиск велопаркинга" ID="ID_1456643201" CREATED="1602708413568" MODIFIED="1602708423489"/>
</node>
<node TEXT="аренда велосипеда" ID="ID_139692423" CREATED="1602708228068" MODIFIED="1602708231769">
<node TEXT="Сделать поиск аренды велосипеда" ID="ID_736735242" CREATED="1602708429919" MODIFIED="1602708443126"/>
</node>
<node TEXT="скейт" ID="ID_1044562745" CREATED="1602708231979" MODIFIED="1602708237003">
<node TEXT="Сделать пользователю линк на удобные рюкзаки и ролик на этикет проезда с рюкзаком" ID="ID_900568914" CREATED="1602708464647" MODIFIED="1602708500219"/>
</node>
<node TEXT="" ID="ID_1116699651" CREATED="1602708237167" MODIFIED="1602708237167"/>
</node>
<node TEXT="Сделать поиск зарядной станции" ID="ID_1874730927" CREATED="1602708363244" MODIFIED="1602708410543">
<node TEXT="Сделать список гаджетов" ID="ID_106073150" CREATED="1602708541028" MODIFIED="1602708549453"/>
</node>
</node>
</node>
<node ID="ID_1034408232" CREATED="1602584537880" MODIFIED="1602707566018"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">&nbsp;взаимодействие пользователя с картой,</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="Какие бывают взаимодействия пользователя?" ID="ID_1275310006" CREATED="1602707603371" MODIFIED="1602707637385">
<node TEXT="браузер" ID="ID_1710184074" CREATED="1602708590440" MODIFIED="1602708595453">
<node TEXT="ввод адреса" ID="ID_1542540632" CREATED="1602708645279" MODIFIED="1602708650733"/>
<node TEXT="переход по ссылке" ID="ID_1384272166" CREATED="1602708651061" MODIFIED="1602708655279"/>
<node TEXT="заполнение формы" ID="ID_1427670489" CREATED="1602708655431" MODIFIED="1602708662168"/>
<node TEXT="нажатие кнопки" ID="ID_24883217" CREATED="1602708662313" MODIFIED="1602708668173"/>
<node TEXT="открытие новой вкладки" ID="ID_986865498" CREATED="1602708668380" MODIFIED="1602708681651"/>
<node TEXT="сохранение историии просмотра" ID="ID_1317205575" CREATED="1602708681796" MODIFIED="1602708689658"/>
<node TEXT="добавление в корзину" ID="ID_1983824084" CREATED="1602708689761" MODIFIED="1602708698038"/>
<node TEXT="снимок экрана" ID="ID_2412481" CREATED="1602708699583" MODIFIED="1602708710161"/>
<node TEXT="добавление в закладки" ID="ID_90989550" CREATED="1602708710342" MODIFIED="1602708722657"/>
<node TEXT="переход в интерфейс сервиса" ID="ID_816470193" CREATED="1602708725486" MODIFIED="1602708737353"/>
<node TEXT="если без новых вкладок, то навигация вперёд назад по просмотренным страницам" ID="ID_865590880" CREATED="1602708741140" MODIFIED="1602708777569"/>
</node>
<node TEXT="фото" ID="ID_1702064450" CREATED="1602708595834" MODIFIED="1602708597019">
<node TEXT="сделать фото" ID="ID_906014816" CREATED="1602708782136" MODIFIED="1602708784598"/>
<node TEXT="применить фильтр" ID="ID_1281525365" CREATED="1602708784935" MODIFIED="1602708797330"/>
<node TEXT="отредактировать" ID="ID_1301731449" CREATED="1602708789074" MODIFIED="1602708794585"/>
<node TEXT="подписать" ID="ID_1349593495" CREATED="1602708802536" MODIFIED="1602708804610"/>
<node TEXT="отправить" ID="ID_581779109" CREATED="1602708804752" MODIFIED="1602708807518"/>
<node TEXT="запостить" ID="ID_1518626557" CREATED="1602708809233" MODIFIED="1602708812597"/>
<node TEXT="комментировать" ID="ID_1054563074" CREATED="1602708813831" MODIFIED="1602708829480"/>
</node>
<node TEXT="билет" ID="ID_109082840" CREATED="1602708597624" MODIFIED="1602708599059">
<node TEXT="распечатать" ID="ID_219062442" CREATED="1602708833365" MODIFIED="1602708839279"/>
<node TEXT="предъявить" ID="ID_1241791380" CREATED="1602708839927" MODIFIED="1602708850804"/>
<node TEXT="отправить приглашение кого с собой хочешь пригласить" ID="ID_752607768" CREATED="1602708857800" MODIFIED="1602708880941"/>
<node TEXT="запостить, что я был" ID="ID_872156012" CREATED="1602708894026" MODIFIED="1602708900852"/>
</node>
<node TEXT="ссылка" ID="ID_459827691" CREATED="1602708599200" MODIFIED="1602708605688">
<node TEXT="отредактировать" ID="ID_81796606" CREATED="1602708904661" MODIFIED="1602708909527"/>
<node TEXT="скопировать" ID="ID_1993766811" CREATED="1602708909672" MODIFIED="1602708913026"/>
<node TEXT="посмотреть урл" ID="ID_170176880" CREATED="1602708913146" MODIFIED="1602708918070"/>
<node TEXT="открыть в браузере" ID="ID_461718945" CREATED="1602708918246" MODIFIED="1602708922651"/>
<node TEXT="поделить ся в мессенджерах" ID="ID_578844566" CREATED="1602708924949" MODIFIED="1602708934018"/>
</node>
<node TEXT="номер телефона" ID="ID_1267052267" CREATED="1602708605825" MODIFIED="1602708615496">
<node TEXT="записать контакт" ID="ID_1597705145" CREATED="1602708938498" MODIFIED="1602708944923"/>
<node TEXT="набрать" ID="ID_1242297293" CREATED="1602708945073" MODIFIED="1602708946934"/>
<node TEXT="отправить кому-то" ID="ID_1400170433" CREATED="1602708947469" MODIFIED="1602708959226"/>
<node TEXT="отправить сообщение" ID="ID_199216965" CREATED="1602708960121" MODIFIED="1602708967187"/>
<node TEXT="переключиться на мессенджер" ID="ID_1604976109" CREATED="1602708967339" MODIFIED="1602708976725"/>
</node>
<node TEXT="документ" ID="ID_621245599" CREATED="1602708615642" MODIFIED="1602708619426">
<node TEXT="сохранить" ID="ID_1091251670" CREATED="1602708986094" MODIFIED="1602708991057"/>
<node TEXT="переименовать" ID="ID_420666772" CREATED="1602708991545" MODIFIED="1602708994038"/>
<node TEXT="открыть" ID="ID_838763129" CREATED="1602708994187" MODIFIED="1602708997092"/>
<node TEXT="редактировать" ID="ID_962211614" CREATED="1602708997271" MODIFIED="1602708999910"/>
<node TEXT="комментировать в оверлее" ID="ID_84038864" CREATED="1602709000028" MODIFIED="1602709011532"/>
</node>
<node TEXT="просмотреть надо" ID="ID_1860020358" CREATED="1602708619557" MODIFIED="1602708627273">
<node TEXT="открывать разные типы файлов" ID="ID_513647446" CREATED="1602709020010" MODIFIED="1602709031888"/>
</node>
<node TEXT="записать" ID="ID_980852930" CREATED="1602708627420" MODIFIED="1602708629584">
<node TEXT="разные виды файлов" ID="ID_699025949" CREATED="1602709036107" MODIFIED="1602709044070"/>
</node>
<node TEXT="отправить" ID="ID_1142086245" CREATED="1602708629718" MODIFIED="1602708634821">
<node TEXT="любой файл" ID="ID_1063391262" CREATED="1602709047180" MODIFIED="1602709051360"/>
</node>
<node TEXT="нарисовать" ID="ID_1104727316" CREATED="1602708634971" MODIFIED="1602709062934"/>
<node TEXT="напечатать" ID="ID_453268553" CREATED="1602709069725" MODIFIED="1602709076183"/>
</node>
<node TEXT="Какие бывают взаимодействия пользователя с картой?" ID="ID_32508299" CREATED="1602708575575" MODIFIED="1602708587449">
<node TEXT="перемещение по картинке карты" ID="ID_1197836044" CREATED="1602709125950" MODIFIED="1602709138378"/>
<node TEXT="масштабирование" ID="ID_337184096" CREATED="1602709138894" MODIFIED="1602709147949"/>
<node TEXT="сохранить ссылку на текущий кадр и настройки" ID="ID_1303956169" CREATED="1602709148167" MODIFIED="1602709166018"/>
<node TEXT="сохранить код для вставки на сайт" ID="ID_499056013" CREATED="1602709166598" MODIFIED="1602709174742"/>
<node TEXT="переключить варианты представления" ID="ID_1166286061" CREATED="1602709175565" MODIFIED="1602709217560">
<node TEXT="векторный" ID="ID_89425663" CREATED="1602709217566" MODIFIED="1602709223197"/>
<node TEXT="текстурный" ID="ID_1805123131" CREATED="1602709223567" MODIFIED="1602709226493"/>
<node TEXT="гибридный вектор и текстуры" ID="ID_1387636158" CREATED="1602709226662" MODIFIED="1602709235105"/>
<node TEXT="но нет схематического, когда искажены реальные расстояния, а подчеркнуты реальные значащие решения и ориентиры к ним" ID="ID_708062164" CREATED="1602709235227" MODIFIED="1602709281908"/>
<node TEXT="еще режим подписей" ID="ID_1001703129" CREATED="1602709297017" MODIFIED="1602709313362">
<node TEXT="переключение языка" ID="ID_1759482317" CREATED="1602709318535" MODIFIED="1602709324917"/>
<node TEXT="подключение интересующих слоёв по каегориям" ID="ID_532331570" CREATED="1602709325394" MODIFIED="1602709344573"/>
</node>
</node>
<node TEXT="измерить расстояния" ID="ID_1302245587" CREATED="1602709375197" MODIFIED="1602709389222">
<node TEXT="поделиться ссылкой на замеры" ID="ID_1500520715" CREATED="1602709391432" MODIFIED="1602709398967"/>
</node>
<node TEXT="построить путь" ID="ID_72145078" CREATED="1602709405535" MODIFIED="1602709412058">
<node TEXT="поделиться сслыкой на путь" ID="ID_287828288" CREATED="1602709412076" MODIFIED="1602709419003"/>
<node TEXT="поделиться сслыкой на путь отображением статуса прохождения" ID="ID_1588438385" CREATED="1602709419377" MODIFIED="1602709440622"/>
</node>
<node TEXT="в мессенджерах есть возможность поделиться текущими координатами или локацией" ID="ID_1159733609" CREATED="1602709444586" MODIFIED="1602709542137">
<node TEXT="Сделать опцию делиться с конкретным пользователем( по сервису или почте)" ID="ID_419983257" CREATED="1602709470384" MODIFIED="1602709503422"/>
<node TEXT="Сделать опции периода наблюдения" ID="ID_313472349" CREATED="1602709504206" MODIFIED="1602709513601"/>
<node TEXT="Сделать опцию демонстрацию лога прохождения пути прогноз-факт" ID="ID_673235397" CREATED="1602709514013" MODIFIED="1602709536901"/>
</node>
</node>
<node TEXT="Что пользователю нужно от карты?" ID="ID_976088116" CREATED="1602707641766" MODIFIED="1602707655913">
<node TEXT="Получить представление о пути" ID="ID_842623912" CREATED="1602709564411" MODIFIED="1602709607912">
<node TEXT="Откуда и куда ехать" ID="ID_1746643443" CREATED="1602709612025" MODIFIED="1602709628680"/>
<node TEXT="Как ехать" ID="ID_580593936" CREATED="1602709633025" MODIFIED="1602709639102"/>
</node>
<node TEXT="Пользователь может делать выводы" ID="ID_449691267" CREATED="1602709579083" MODIFIED="1602709600456"/>
<node TEXT="Какие есть выводы внутри маршрута?" ID="ID_1381229426" CREATED="1602709640325" MODIFIED="1602709665585"/>
<node TEXT="Какие есть выводы вокруг маршрута?" ID="ID_80821050" CREATED="1602709718534" MODIFIED="1602709736282"/>
<node TEXT="Почему пользователь предпочитает карту нежели перечисление контрольныз точек?" ID="ID_1777554205" CREATED="1602709679257" MODIFIED="1602709702606"/>
</node>
</node>
<node ID="ID_1392705943" CREATED="1602584537886" MODIFIED="1602584537886"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">просмотр информации о станциях и</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="Какая информация нужна пользователю о станции?" ID="ID_575078064" CREATED="1602707670702" MODIFIED="1602707704407">
<node TEXT="подземная станция" ID="ID_458610856" CREATED="1602714526400" MODIFIED="1602714537287">
<node TEXT="параметры" ID="ID_1960273125" CREATED="1602714601676" MODIFIED="1602714605576">
<node TEXT="глубина" ID="ID_537175823" CREATED="1602714613615" MODIFIED="1602714617137"/>
<node TEXT="год" ID="ID_1519583916" CREATED="1602714618967" MODIFIED="1602714636710"/>
</node>
</node>
<node TEXT="надземная станция" ID="ID_1079514327" CREATED="1602714537677" MODIFIED="1602714543665">
<node TEXT="прилегающий транспорт" ID="ID_96610572" CREATED="1602714705243" MODIFIED="1602714712269"/>
<node TEXT="выходы" ID="ID_529488946" CREATED="1602714713852" MODIFIED="1602714723763"/>
<node TEXT="цели у выходов" ID="ID_1627062918" CREATED="1602714781726" MODIFIED="1602714789525"/>
</node>
<node TEXT="движение к станции" ID="ID_567802146" CREATED="1602714544072" MODIFIED="1602714561210">
<node TEXT="где вход" ID="ID_605897597" CREATED="1602714739379" MODIFIED="1602714741983"/>
<node TEXT="как выглядит вход" ID="ID_1122228069" CREATED="1602714743544" MODIFIED="1602714747627"/>
<node TEXT="ближайшая станция" ID="ID_825594135" CREATED="1602714749786" MODIFIED="1602714776363"/>
</node>
<node TEXT="от станции" ID="ID_867901432" CREATED="1602714565594" MODIFIED="1602714573792">
<node TEXT="что там интересного было" ID="ID_1050895750" CREATED="1602714794687" MODIFIED="1602714804429"/>
<node TEXT="останется ли лишний билет и можно ли вернуть деньги за него или кому-то отдать" ID="ID_1203623342" CREATED="1602714805351" MODIFIED="1602714858260"/>
</node>
<node TEXT="над станцией" ID="ID_1925115586" CREATED="1602714574230" MODIFIED="1602714582970">
<node TEXT="погода" ID="ID_992489454" CREATED="1602714863082" MODIFIED="1602714867078"/>
</node>
<node TEXT="из станции" ID="ID_1997218457" CREATED="1602714585103" MODIFIED="1602714591765">
<node TEXT="какие есть выходы" ID="ID_897218766" CREATED="1602714870591" MODIFIED="1602715063574"/>
<node TEXT="куда ведут выходы" ID="ID_517472732" CREATED="1602714875916" MODIFIED="1602714880001"/>
<node TEXT="какой выход мой" ID="ID_1659002770" CREATED="1602715067112" MODIFIED="1602715071411"/>
<node TEXT="куда заглянуть выходя из станции" ID="ID_1357390479" CREATED="1602715077354" MODIFIED="1602715086003"/>
<node TEXT="на каком выходе меня будут встречать" ID="ID_1654058151" CREATED="1602715086298" MODIFIED="1602715098265"/>
</node>
<node TEXT="в станцию" ID="ID_640597157" CREATED="1602714591926" MODIFIED="1602714598262">
<node TEXT="загрузка кассы и когда билет продлить" ID="ID_383185697" CREATED="1602714884440" MODIFIED="1602714915464"/>
</node>
<node TEXT="вокруг станции" ID="ID_113477779" CREATED="1602714928268" MODIFIED="1602714932933">
<node TEXT="кофе" ID="ID_489274895" CREATED="1602714932980" MODIFIED="1602714935444"/>
<node TEXT="еда" ID="ID_635548682" CREATED="1602715006445" MODIFIED="1602715009018"/>
<node TEXT="бизнес" ID="ID_46595437" CREATED="1602714936076" MODIFIED="1602714938573"/>
<node TEXT="аптеки" ID="ID_1052267755" CREATED="1602714938918" MODIFIED="1602714942834"/>
<node TEXT="магазины" ID="ID_1884889791" CREATED="1602714942984" MODIFIED="1602714947893"/>
<node TEXT="ТЦ" ID="ID_574952321" CREATED="1602714948059" MODIFIED="1602714949470"/>
<node TEXT="Музеи" ID="ID_1084265756" CREATED="1602714949892" MODIFIED="1602714956055"/>
<node TEXT="Театры" ID="ID_1161460052" CREATED="1602714956499" MODIFIED="1602714958446"/>
<node TEXT="Учреждения" ID="ID_1661420377" CREATED="1602714958641" MODIFIED="1602714961730"/>
<node TEXT="Памятники" ID="ID_1145869570" CREATED="1602714962029" MODIFIED="1602714965149"/>
<node TEXT="Архитектура" ID="ID_493300773" CREATED="1602714965306" MODIFIED="1602714971950"/>
<node TEXT="История" ID="ID_389014213" CREATED="1602714972321" MODIFIED="1602714994885"/>
<node TEXT="Популярные запросы по станции" ID="ID_1291456365" CREATED="1602714979464" MODIFIED="1602715003792"/>
<node TEXT="Где укрыться от дождя" ID="ID_1937054623" CREATED="1602715020306" MODIFIED="1602715026749"/>
<node TEXT="ЖК комплексы" ID="ID_854362269" CREATED="1602715028602" MODIFIED="1602715035332"/>
<node TEXT="Соседний транспорт и продолжение маршрута" ID="ID_137735943" CREATED="1602715038141" MODIFIED="1602715050340"/>
</node>
<node TEXT="культурные факты" ID="ID_945581673" CREATED="1602714642787" MODIFIED="1602714670265">
<node TEXT="дата построения" ID="ID_1970101548" CREATED="1602714922347" MODIFIED="1602715109867"/>
<node TEXT="архитектор" ID="ID_281707869" CREATED="1602715110013" MODIFIED="1602715116236"/>
</node>
<node TEXT="контекстные факты" ID="ID_36067921" CREATED="1602714646543" MODIFIED="1602714676270">
<node TEXT="туалет" ID="ID_1248556687" CREATED="1602715125651" MODIFIED="1602715127682"/>
<node TEXT="банк" ID="ID_838713314" CREATED="1602715128033" MODIFIED="1602715131295"/>
<node TEXT="куда я еду" ID="ID_1432474400" CREATED="1602715131698" MODIFIED="1602715142582"/>
<node TEXT="не проспать выход" ID="ID_1928956172" CREATED="1602715146109" MODIFIED="1602715158286"/>
</node>
<node TEXT="справочные факты" ID="ID_432596942" CREATED="1602714652479" MODIFIED="1602714680698">
<node TEXT="поисковик" ID="ID_74819596" CREATED="1602715169915" MODIFIED="1602715263718"/>
</node>
<node TEXT="решения на месте" ID="ID_175170560" CREATED="1602714681288" MODIFIED="1602714688518">
<node TEXT="кофе" ID="ID_439220598" CREATED="1602715188718" MODIFIED="1602715195548"/>
<node TEXT="магазины" ID="ID_1907793531" CREATED="1602715196021" MODIFIED="1602715197774"/>
<node TEXT="доставка" ID="ID_1658976994" CREATED="1602715197914" MODIFIED="1602715201423"/>
</node>
</node>
</node>
<node ID="ID_1791313656" CREATED="1602584537891" MODIFIED="1602584537891"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">построение оптимальных маршрутов</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="Какие бывают оптимальные маршруты?" ID="ID_380041318" CREATED="1602707710097" MODIFIED="1602707720755">
<node TEXT="минимальное время на передвижение" ID="ID_687485483" CREATED="1602714399085" MODIFIED="1602714412937"/>
<node TEXT="отсутствие аварий на выбранном пути" ID="ID_1330334136" CREATED="1602714413632" MODIFIED="1602714437365"/>
<node TEXT="Решение более одной задачи за установленный период" ID="ID_978030022" CREATED="1602714438923" MODIFIED="1602714456148"/>
<node TEXT="Решение по организации встреч на пути двух человек при наличии вторичных задач" ID="ID_435884549" CREATED="1602714466137" MODIFIED="1602714501267"/>
</node>
<node TEXT="Как возможно оптимизировать маршрут пользователя?" ID="ID_518976663" CREATED="1602707721266" MODIFIED="1602707738073">
<node TEXT="организация" ID="ID_284834133" CREATED="1602707741153" MODIFIED="1602707745272"/>
<node TEXT="решение задач по пути" ID="ID_497247327" CREATED="1602707745670" MODIFIED="1602707750159"/>
<node TEXT="организация встречи нескольких пользователей" ID="ID_157364311" CREATED="1602707750281" MODIFIED="1602714387224"/>
<node TEXT="совместные решения пользователей" ID="ID_297680124" CREATED="1602707773418" MODIFIED="1602707779620"/>
</node>
</node>
<node ID="ID_1343430833" CREATED="1602584537896" MODIFIED="1602584537896"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">не только в режиме online</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="Навигация по акселерометру" ID="ID_1655421051" CREATED="1602713758618" MODIFIED="1602713767774"/>
<node TEXT="Навигация по QR кодам" ID="ID_1688811204" CREATED="1602713770207" MODIFIED="1602713792980">
<node TEXT="зашел в поезд и на полу или на стене или потолке софткал код QR - получил место на карте, или ввел просто номер из подписи" ID="ID_1765666473" CREATED="1602713796394" MODIFIED="1602713862696"/>
</node>
<node TEXT="Навигация за счёт пользователя" ID="ID_1125057929" CREATED="1602713875202" MODIFIED="1602713885789">
<node TEXT="пользователь тыкает где он думает он находится на карте и выводится 1-5 кадров с локации потолок-пол конец начало вестибюля или колонна напротив которой он находится" ID="ID_716643063" CREATED="1602713885812" MODIFIED="1602714003632"/>
<node TEXT="Возможно примерение AI" ID="ID_701912364" CREATED="1602714007109" MODIFIED="1602714015648"/>
<node TEXT="ввод номера контрольной точки" ID="ID_1739672557" CREATED="1602714034458" MODIFIED="1602714043962"/>
<node TEXT="Запуск навигации по акселерометру" ID="ID_747728184" CREATED="1602714048951" MODIFIED="1602714060801"/>
</node>
<node TEXT="Навигация по звуку" ID="ID_1640043844" CREATED="1602714087743" MODIFIED="1602714095155">
<node TEXT="Навигация по звуку" ID="ID_571341298" CREATED="1602714069265" MODIFIED="1602714074885"/>
</node>
<node TEXT="Автономная навигация" ID="ID_757077151" CREATED="1602714111797" MODIFIED="1602714269216">
<node TEXT="акселеромктр + подсчёт шагов" ID="ID_1870955425" CREATED="1602714128359" MODIFIED="1602714141928"/>
<node TEXT="интерполяция с выводом контрольных тестов" ID="ID_18232295" CREATED="1602714143070" MODIFIED="1602714171734"/>
<node TEXT="аудио гид" ID="ID_367148249" CREATED="1602714183705" MODIFIED="1602714188690"/>
<node TEXT="аудио гид с разпознаванием Да и НЕТ" ID="ID_178999817" CREATED="1602714203616" MODIFIED="1602714215441"/>
<node TEXT="аудио гид называет вероятно правильности маршрута" ID="ID_902900317" CREATED="1602714226410" MODIFIED="1602714250949"/>
</node>
<node TEXT="Аудио навигация" ID="ID_907501229" CREATED="1602714275479" MODIFIED="1602714283632"/>
<node TEXT="Аудио гид с верификацией правильности передвижений" ID="ID_249656298" CREATED="1602714286627" MODIFIED="1602714329824"/>
<node TEXT="Навигация при помощи камер наблюдения в метро" ID="ID_120543080" CREATED="1602714339110" MODIFIED="1602714354286"/>
</node>
<node ID="ID_1610864672" CREATED="1602584537901" MODIFIED="1602584537901"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">но и без использования интернета.</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT="Сделать кэширование выбранного маршрута или всей базы маршрутов на телефон" ID="ID_869722723" CREATED="1602713721414" MODIFIED="1602713747695"/>
</node>
</node>
<node ID="ID_283349240" CREATED="1602584537874" MODIFIED="1602584537874"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="62" align="left">
          <font face="Times New Roman">Кроме того, для комфортной работы с картой, участникам необходимо уделить внимание скорости и плавности работы интерфейса</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_733652600" CREATED="1602584537906" MODIFIED="1602584537906"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">для комфортной работы с картой,</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1395768227" CREATED="1602584537910" MODIFIED="1602584537910"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">участникам необходимо уделить внимание скорости</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1024953460" CREATED="1602584537915" MODIFIED="1602584537915"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td align="left">
          <font face="Times New Roman">и плавности работы интерфейса</font>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="инфо с видео заказчиков" ID="ID_988903008" CREATED="1602845655293" MODIFIED="1602845668705">
<node ID="ID_110395374" CREATED="1602845971344" MODIFIED="1602845971344" LINK="https://www.facebook.com/upgreatone/videos/812167396260297/?extid=XUUl8VmnY4J5uEEb"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.facebook.com/upgreatone/videos/812167396260297/?extid=XUUl8VmnY4J5uEEb">https://www.facebook.com/upgreatone/videos/812167396260297/?extid=XUUl8VmnY4J5uEEb</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Максим Власов" ID="ID_1167488366" CREATED="1602847287166" MODIFIED="1602847292923">
<node TEXT="Задача разработки интерактивной карты" ID="ID_715444727" CREATED="1602847334440" MODIFIED="1602847352192"/>
<node TEXT="Учитывать темпы развития всей транспортной инфраструктуры, транспортного скелета москвы" ID="ID_1832681109" CREATED="1602847374620" MODIFIED="1602847420429"/>
<node TEXT="с перспективами разбития линий метро" ID="ID_88726837" CREATED="1602847421561" MODIFIED="1602847433240"/>
<node TEXT="подключение московских центральных диаметров" ID="ID_215721317" CREATED="1602847433700" MODIFIED="1602847454669"/>
<node TEXT="именно персонализация и" ID="ID_80321114" CREATED="1602847464239" MODIFIED="1602847478555"/>
<node TEXT="многомодальная история с построением маршрутов" ID="ID_1681166494" CREATED="1602847479815" MODIFIED="1602847501200">
<node TEXT="роли пользователя" ID="ID_685876693" CREATED="1602847532301" MODIFIED="1602847536231">
<node TEXT="исследователь" ID="ID_1589603930" CREATED="1602847592328" MODIFIED="1602847602975"/>
<node TEXT="рутина" ID="ID_584167742" CREATED="1602847603463" MODIFIED="1602847608940"/>
<node TEXT="поиск отдыха и развлечения" ID="ID_43035276" CREATED="1602847609288" MODIFIED="1602847616952"/>
<node TEXT="шоппер" ID="ID_144319077" CREATED="1602847617095" MODIFIED="1602847619613"/>
<node TEXT="курьер" ID="ID_562308574" CREATED="1602847619819" MODIFIED="1602847622718"/>
</node>
<node TEXT="свойства аудитори" ID="ID_888771186" CREATED="1602847536960" MODIFIED="1602847541837">
<node TEXT="школьник" ID="ID_266257590" CREATED="1602847552240" MODIFIED="1602847555598"/>
<node TEXT="студент" ID="ID_981020690" CREATED="1602847555970" MODIFIED="1602847558733"/>
<node TEXT="работник" ID="ID_1315640535" CREATED="1602847558885" MODIFIED="1602847564946"/>
<node TEXT="приезжий" ID="ID_19776430" CREATED="1602847565136" MODIFIED="1602847570517"/>
<node TEXT="иностранец" ID="ID_1278137352" CREATED="1602847571183" MODIFIED="1602847581667"/>
<node TEXT="пенсионер" ID="ID_1989840451" CREATED="1602847582182" MODIFIED="1602847588822"/>
</node>
<node TEXT="проверка модели поведения" ID="ID_1349623671" CREATED="1602847542083" MODIFIED="1602847549409"/>
</node>
<node TEXT="будет или уже сейчас актуальна для многих москвичей" ID="ID_409605044" CREATED="1602847506605" MODIFIED="1602847526920"/>
</node>
<node TEXT="Анастасия Плеханова, ЦОДД, Департамент транспорта города Москвы" ID="ID_184249456" CREATED="1602845977815" MODIFIED="1602846000882">
<node TEXT="Задача для решения городских нужд" ID="ID_1632786605" CREATED="1602846084592" MODIFIED="1602846099859"/>
<node TEXT="ЦОДД, Департамент транспорта города Москвы" ID="ID_241244082" CREATED="1602846032890" MODIFIED="1602846120268">
<node TEXT="центр организации дорожного движения" ID="ID_478554978" CREATED="1602847692131" MODIFIED="1602847702058"/>
</node>
<node TEXT="приложение Московский транспорт" ID="ID_1199724456" CREATED="1602846032862" MODIFIED="1602847741956">
<node TEXT="навигационное транспортное приложение" ID="ID_595538588" CREATED="1602847716651" MODIFIED="1602847728409"/>
<node TEXT="кторое базируется на принципах MAAS" ID="ID_941038440" CREATED="1602847742688" MODIFIED="1602847758863"/>
<node TEXT="MAAS - mobility as a service" ID="ID_350922705" CREATED="1602847767981" MODIFIED="1602847779657"/>
<node TEXT="отвечает за построение маршрута на всех видах транспорта" ID="ID_1190110090" CREATED="1602847804071" MODIFIED="1602847833129"/>
<node TEXT="более удобным для пользователя путём" ID="ID_478277913" CREATED="1602847839134" MODIFIED="1602847859957"/>
<node TEXT="это является одним из трендовых в мире развитий транспортной системы" ID="ID_1927617143" CREATED="1602847860430" MODIFIED="1602847905317"/>
<node TEXT="также актуальность подтверждается тем, что ежедневно на дорогах перемещается более 11-ти миллионов москвичей" ID="ID_831844166" CREATED="1602847906533" MODIFIED="1602847942608"/>
<node TEXT="из них около 6 млн поездок осуществляется на московском метро" ID="ID_1803117839" CREATED="1602847952769" MODIFIED="1602848105206"/>
<node TEXT="жители города постоянно пользуются городскими сервисами и приложениями" ID="ID_1060874837" CREATED="1602847983414" MODIFIED="1602848113574"/>
<node TEXT="поэтому целью создания приложения московский транспорт было объединить все эти сервисы в одно приложение" ID="ID_946169521" CREATED="1602848004151" MODIFIED="1602848213471"/>
<node TEXT="в качесте задачи на хакатон мы выбрали построение интерактивной схемы метро" ID="ID_896104454" CREATED="1602848214747" MODIFIED="1602848248391"/>
<node TEXT="во первых потому что сильно просят пользователи" ID="ID_16943843" CREATED="1602848249534" MODIFIED="1602848260007"/>
<node TEXT="во вторых мы хотим подойти к задаче персонализированно и сделать использование схемы более удобным" ID="ID_397007422" CREATED="1602848267870" MODIFIED="1602848303849">
<node TEXT="модель ограничений для пользователя" ID="ID_101256400" CREATED="1602848309329" MODIFIED="1602848321984"/>
<node TEXT="первое режим минимум кнопок только маршрут" ID="ID_474900712" CREATED="1602848322889" MODIFIED="1602848338656"/>
</node>
<node TEXT="предусмотрев возможность людям самим оставлять сообщения" ID="ID_1279259326" CREATED="1602848369691" MODIFIED="1602848389674">
<node TEXT="снимок экрана подчеркивание и коммент" ID="ID_1936398712" CREATED="1602848397714" MODIFIED="1602848412279"/>
<node TEXT="фото с камеры и коммент и обозначение локации" ID="ID_463813514" CREATED="1602848414728" MODIFIED="1602848432064"/>
</node>
<node TEXT="о работе транспорта" ID="ID_274527694" CREATED="1602848390803" MODIFIED="1602848396027"/>
<node TEXT="или о загруженности транспорта" ID="ID_1587415301" CREATED="1602848438976" MODIFIED="1602848447776">
<node TEXT="автоматические" ID="ID_1513580686" CREATED="1602848450763" MODIFIED="1602848457790">
<node TEXT="отчет о скорости передвижения" ID="ID_1764127271" CREATED="1602848457804" MODIFIED="1602848467793"/>
</node>
<node TEXT="ручные" ID="ID_546789081" CREATED="1602848468936" MODIFIED="1602848473229">
<node TEXT="обозначение нетерпения со стороны пользователя" ID="ID_1422850360" CREATED="1602848473240" MODIFIED="1602848493256"/>
</node>
</node>
<node TEXT="и в свою очередь сообщать им об этом" ID="ID_427911222" CREATED="1602848531233" MODIFIED="1602848545992">
<node TEXT="введение функций оповещения от простого к сложному" ID="ID_1997451864" CREATED="1602848549165" MODIFIED="1602848568419"/>
<node TEXT="план фич" ID="ID_164207522" CREATED="1602848572473" MODIFIED="1602848576145"/>
</node>
<node TEXT="в любом случае мы также будем обращать внимание при решении" ID="ID_1382753083" CREATED="1602848584151" MODIFIED="1602848608224"/>
<node TEXT="на плавность интерфейса" ID="ID_1973874139" CREATED="1602848609013" MODIFIED="1602848617177"/>
<node TEXT="и предложенное участниками решение" ID="ID_192601049" CREATED="1602848639108" MODIFIED="1602848649625"/>
<node TEXT="у всех участников будет возможность предожить что-то своё" ID="ID_1313463805" CREATED="1602848658064" MODIFIED="1602848679181"/>
<node TEXT="мы с удовольствием будем рассматривать все креативные варианты" ID="ID_1239091578" CREATED="1602848680334" MODIFIED="1602848699583"/>
<node TEXT="которые предожат участники" ID="ID_1729930866" CREATED="1602848707427" MODIFIED="1602848715144"/>
<node TEXT="Никита расскажет о главных принципах маас" ID="ID_1246058170" CREATED="1602848726039" MODIFIED="1602848738105"/>
</node>
<node TEXT="6 лям пассажиров" ID="ID_374454000" CREATED="1602846032862" MODIFIED="1602846032862"/>
<node TEXT="модель MAAS" ID="ID_987278003" CREATED="1602846032870" MODIFIED="1602846032870"/>
<node TEXT="запросы пользователей" ID="ID_662348649" CREATED="1602846032872" MODIFIED="1602846032872"/>
<node TEXT="возможность люсамим оставлять сообщения о транпорте" ID="ID_2292549" CREATED="1602846032876" MODIFIED="1602846032876"/>
<node TEXT="плавность интерфейса" ID="ID_864681703" CREATED="1602846032877" MODIFIED="1602846032877"/>
<node TEXT="мобильность как услуга" ID="ID_760607369" CREATED="1602846032892" MODIFIED="1602846032892"/>
<node TEXT="скорость удобство" ID="ID_250344110" CREATED="1602846032894" MODIFIED="1602846032894"/>
<node TEXT="планирование маршрута" ID="ID_1982345615" CREATED="1602846032895" MODIFIED="1602846032895"/>
</node>
<node TEXT="Никита Скорик, ЦОДД, Департамент транспорта города Москвы" ID="ID_621072033" CREATED="1602845988627" MODIFIED="1602845996889" LINK="https://static.xx.fbcdn.net/images/emoji.php/v9/t72/1/16/1f538.png)">
<node TEXT="Мобильность как услуга имеет несколько ключевых точек для комфортности для передвижения граждан" ID="ID_1469729623" CREATED="1602848774587" MODIFIED="1602848801732"/>
<node TEXT="во первых это планирование маршрута" ID="ID_1310113575" CREATED="1602848812351" MODIFIED="1602848830943">
<node TEXT="маршрут будет построен в зависимости от выбранных предпочтений пользователя" ID="ID_1674129634" CREATED="1602848835032" MODIFIED="1602848856560">
<node TEXT="по скорости" ID="ID_1331609185" CREATED="1602848872944" MODIFIED="1602848875526"/>
<node TEXT="удобству" ID="ID_1728636699" CREATED="1602848876073" MODIFIED="1602848878205"/>
<node TEXT="и другим параметрам" ID="ID_731822240" CREATED="1602848885258" MODIFIED="1602848890512"/>
</node>
<node TEXT="также доступно планировение маршрута для мало мобильных граждан" ID="ID_579199940" CREATED="1602848897918" MODIFIED="1602848920376">
<node TEXT="наличие лифтов на дороге" ID="ID_834612667" CREATED="1602848921875" MODIFIED="1602848931848"/>
<node TEXT="наличие не ступенчатых переходов для колясок" ID="ID_989456381" CREATED="1602848936679" MODIFIED="1602848964819"/>
<node TEXT="тут ещё надо вспомнить про велосипедистов на метро и в переходах" ID="ID_1160642539" CREATED="1602848965825" MODIFIED="1602848982900"/>
<node TEXT="самокаты" ID="ID_1375990970" CREATED="1602848983141" MODIFIED="1602848985450"/>
<node TEXT="коляски с детьми" ID="ID_390782093" CREATED="1602848985625" MODIFIED="1602848992106"/>
</node>
</node>
<node TEXT="во вторых мульти модальные маршруты" ID="ID_271474659" CREATED="1602848998172" MODIFIED="1602849014238">
<node TEXT="они позволяют построить маршрут сразу на нескольких видах транспорта" ID="ID_1365503843" CREATED="1602849046853" MODIFIED="1602849063104"/>
<node TEXT="предлагая лучшие опции перемещения по городу в зависимости от планов граждан" ID="ID_1628863337" CREATED="1602849094024" MODIFIED="1602849124169"/>
</node>
<node TEXT="в третьих это информация в реальном времени" ID="ID_91881448" CREATED="1602849125704" MODIFIED="1602849144062">
<node TEXT="это означает что граждане могут узнать о прибытии" ID="ID_301807727" CREATED="1602849145196" MODIFIED="1602849158929"/>
<node TEXT="и загруженности транспорта" ID="ID_1361294444" CREATED="1602849159340" MODIFIED="1602849177308"/>
</node>
<node TEXT="и четвертая самая ключевая функция маас" ID="ID_442564539" CREATED="1602849178707" MODIFIED="1602849196821">
<node TEXT="это сквозная оплата" ID="ID_25898541" CREATED="1602849198911" MODIFIED="1602849205512"/>
<node TEXT="это означает гражданин может оплатить весь маршрут одним билетом" ID="ID_80346209" CREATED="1602849218668" MODIFIED="1602849274592"/>
<node TEXT="то есть больше не надо делать отдельную остановку для отдельного вида транспорта" ID="ID_140850646" CREATED="1602849283465" MODIFIED="1602849306552"/>
</node>
<node TEXT="на которых основывается приложение московский транспорт" ID="ID_1966420867" CREATED="1602849321015" MODIFIED="1602849388982"/>
<node TEXT="но мы также наблюдаем за пожеланиями граждан" ID="ID_1206850646" CREATED="1602849390211" MODIFIED="1602849413517"/>
<node TEXT="для максимально удобного перемещения по городу" ID="ID_1690127760" CREATED="1602849413981" MODIFIED="1602849424711"/>
<node TEXT="именно поэтому в рамках хакатона лидеры цифровой трансформации  мы попросили участников разработать интерактивную карту московского метрополитена" ID="ID_364607517" CREATED="1602849432852" MODIFIED="1602849490567"/>
<node TEXT="вся техническая информация будет направлена участникам в день хакатона" ID="ID_746212159" CREATED="1602849493512" MODIFIED="1602849517312"/>
<node TEXT="ещё мы ждём участников со всей страны поучаствовать в решении задачи" ID="ID_1852026459" CREATED="1602849528606" MODIFIED="1602849548125"/>
<node TEXT="а две лучших команды проведут две недели с нашей командой разработки" ID="ID_1278014973" CREATED="1602849565098" MODIFIED="1602849585254"/>
<node TEXT="доведя свой проект до идеала" ID="ID_1941042017" CREATED="1602849623298" MODIFIED="1602849632884"/>
<node TEXT="в дальнейшем это решение будет интегрировано в нашем поиложении" ID="ID_1901091967" CREATED="1602849645177" MODIFIED="1602849671815"/>
<node TEXT="также будут рады видеть всех заинтересованных в нашем задании участников" ID="ID_1368679669" CREATED="1602849689885" MODIFIED="1602849715240"/>
</node>
<node TEXT="Максим Власов" ID="ID_1401161477" CREATED="1602849746287" MODIFIED="1602849747663">
<node TEXT="персонализация для мобильных граждан" ID="ID_1403418225" CREATED="1602849750198" MODIFIED="1602849766276"/>
<node TEXT="янд метро" ID="ID_238702071" CREATED="1602849766489" MODIFIED="1602849771219"/>
<node TEXT="конкурентов" ID="ID_1317807244" CREATED="1602849771400" MODIFIED="1602849783746"/>
<node TEXT="идеал - инфо Насти ключевые слова" ID="ID_1683593444" CREATED="1602849791300" MODIFIED="1603825226996">
<node TEXT="интерактив карта" ID="ID_1819799651" CREATED="1602849800782" MODIFIED="1602849806333"/>
<node TEXT="персонализация" ID="ID_1651885273" CREATED="1602849806606" MODIFIED="1602849810806"/>
<node TEXT="сами на карте отмечаю события" ID="ID_1970172760" CREATED="1602849811151" MODIFIED="1602849820108"/>
<node TEXT="перегрузка" ID="ID_1279496807" CREATED="1602849823502" MODIFIED="1602849829719"/>
<node TEXT="кто-то что-то забыл" ID="ID_967278360" CREATED="1602849829899" MODIFIED="1602849835772"/>
<node TEXT="собираем биг дата" ID="ID_530768908" CREATED="1602849835929" MODIFIED="1602849841140"/>
<node TEXT="выводим сообщение" ID="ID_386641243" CREATED="1602849841689" MODIFIED="1602849846240"/>
<node TEXT="обращение в службы" ID="ID_1276538668" CREATED="1602849846412" MODIFIED="1603469427434"/>
<node TEXT="междун опыт" ID="ID_1122885244" CREATED="1602849852127" MODIFIED="1602849862390"/>
<node TEXT="есть интересные метро" ID="ID_63131119" CREATED="1602849863074" MODIFIED="1602849868564"/>
<node TEXT="см функцию маломобильным гражданам в приоритете" ID="ID_221771578" CREATED="1602849868742" MODIFIED="1602849882167"/>
</node>
<node TEXT="ник" ID="ID_1596210916" CREATED="1602849905655" MODIFIED="1602849983367">
<node TEXT="сделать слоёную схему" ID="ID_1472485775" CREATED="1602849985523" MODIFIED="1602849996015"/>
</node>
</node>
</node>
</node>
<node TEXT="ОБСУЖДЕНИЕ" ID="ID_496247728" CREATED="1604130105694" MODIFIED="1604130117849">
<node TEXT="расшифровка обсуждения" ID="ID_123111620" CREATED="1603740538329" MODIFIED="1604176544396">
<node TEXT="парящая линия" ID="ID_1343182259" CREATED="1603548236210" MODIFIED="1603548236210"/>
<node TEXT="способы визуализации" ID="ID_1395512706" CREATED="1603548236210" MODIFIED="1603548236210"/>
<node TEXT="изложить варианты на бумаге" ID="ID_968900221" CREATED="1603548236221" MODIFIED="1603548236221"/>
<node TEXT="мы хотим показать 3д модельку станции метро" ID="ID_1205184394" CREATED="1603548236222" MODIFIED="1603548236222"/>
<node TEXT="заходим смотрим маркер? кюар" ID="ID_975782044" CREATED="1603548236224" MODIFIED="1603548236224"/>
<node TEXT="или это слэм" ID="ID_1494720340" CREATED="1603548236226" MODIFIED="1603548236226"/>
<node TEXT="- я не сказал что можно без ар, главное на карте обозначить где находится пользолватель" ID="ID_1547061711" CREATED="1603548236230" MODIFIED="1603548236230"/>
<node TEXT="гео коорд 1" ID="ID_980307242" CREATED="1603548236232" MODIFIED="1603548236232"/>
<node TEXT="2 якоря окруж пространства" ID="ID_1574274378" CREATED="1603548236234" MODIFIED="1603548236234"/>
<node TEXT="нужно понять что нужно сделать" ID="ID_1780071868" CREATED="1603548236235" MODIFIED="1603548236235"/>
<node TEXT="через айбикон или через якоря это довольно разные технологии" ID="ID_1534906399" CREATED="1603548236236" MODIFIED="1603548236236"/>
<node TEXT="и довольно разный юзер экспириенс" ID="ID_125609100" CREATED="1603548236246" MODIFIED="1603548236246"/>
<node TEXT="надо понять юзер экспириенс" ID="ID_1390574561" CREATED="1603548236247" MODIFIED="1603548236247"/>
<node TEXT="что происходит" ID="ID_1948143315" CREATED="1603548236253" MODIFIED="1603548236253"/>
<node TEXT="что пользователь должен сделать" ID="ID_279203718" CREATED="1603548236255" MODIFIED="1603548236255"/>
<node TEXT="и исходя из этого привлекаем либо одного либо другого человека" ID="ID_972182761" CREATED="1603548236256" MODIFIED="1603548236256">
<node TEXT="1-цифровой двойник с параметризацией" ID="ID_1033403508" CREATED="1603548236258" MODIFIED="1603548236258"/>
<node TEXT="2- системы поиска и верификации координат" ID="ID_519897065" CREATED="1603548236261" MODIFIED="1603548236261"/>
<node TEXT="3- режим гида при движении" ID="ID_169524814" CREATED="1603548236264" MODIFIED="1603548236264"/>
<node TEXT="таблица сранения подходов от простого к сложному а)удобство б)онлайн к оффлайн в)сложность реализации б)зависимости реализации г)комбинирование реализаций д)нагрузка на цпу и расход энергии е)(А)плавность работы" ID="ID_1109283646" CREATED="1603548236270" MODIFIED="1603548236270"/>
<node TEXT="кейсы по аудитории" ID="ID_1974017209" CREATED="1603548236271" MODIFIED="1603548236271"/>
<node TEXT="а) пенсионер" ID="ID_933743847" CREATED="1603548236274" MODIFIED="1603548236274"/>
<node TEXT="б)подросток" ID="ID_397212877" CREATED="1603548236275" MODIFIED="1603548236275"/>
<node TEXT="в)молодёж" ID="ID_1239243925" CREATED="1603548236281" MODIFIED="1603548236281"/>
<node TEXT="д)человек средних лет" ID="ID_1191310939" CREATED="1603548236283" MODIFIED="1603548236283"/>
</node>
<node TEXT="получили координату дальше что?" ID="ID_642220588" CREATED="1603548236286" MODIFIED="1603548236286"/>
<node TEXT="схематическая миниатюра 3д" ID="ID_1614445780" CREATED="1603548236288" MODIFIED="1603548236288"/>
<node TEXT="масштабная модель 3д(режим сопоставления станций)" ID="ID_1931257836" CREATED="1603548236290" MODIFIED="1603548236290"/>
<node TEXT="почти плоская карта 2.5д" ID="ID_1243425149" CREATED="1603548236292" MODIFIED="1603548236292"/>
<node TEXT="описать кнопки меню и вращения" ID="ID_838967337" CREATED="1603548236294" MODIFIED="1603548236294"/>
<node TEXT="список параметров станции" ID="ID_1568540793" CREATED="1603548236294" MODIFIED="1603548308161"/>
<node TEXT="реляционная база маршрутизации по станции" ID="ID_559072791" CREATED="1603548236296" MODIFIED="1603548312921"/>
<node TEXT="вэйлайн" ID="ID_1529865575" CREATED="1603548236297" MODIFIED="1603548236297">
<node TEXT="wayline" ID="ID_563147195" CREATED="1603548321860" MODIFIED="1603548331234"/>
</node>
<node TEXT="процент пешком в метрах, эскалатор в метрах, туннели, доп проходка по вестибюлю" ID="ID_496430070" CREATED="1603548236299" MODIFIED="1603548236299"/>
<node TEXT="список параметров для фильтров" ID="ID_831551358" CREATED="1603548236300" MODIFIED="1603548236300"/>
<node TEXT="набор пресетов для фильтров" ID="ID_852433326" CREATED="1603548236301" MODIFIED="1603548236301"/>
<node TEXT="фильтры по ключевому слову=роли пассажира" ID="ID_1313208786" CREATED="1603548236303" MODIFIED="1603548236303"/>
<node TEXT="якоря" ID="ID_1839958003" CREATED="1603548236304" MODIFIED="1603548236304">
<node TEXT="на модели (ракурс, вид, заметка, фото в модели)" ID="ID_954923461" CREATED="1603548236306" MODIFIED="1603548236306"/>
<node TEXT="на станции к координатам(снимок экрана с видом станции(с оврелеем и без), ракурс, вид, заметка, фото в модели)" ID="ID_1568451714" CREATED="1603548236307" MODIFIED="1603548236307"/>
<node TEXT="что на 2,5д карте? колонны, счастливые приметы, статуи," ID="ID_1961616583" CREATED="1603548236308" MODIFIED="1603548236308"/>
</node>
<node TEXT="способы добавления 3д объектов на карты импорт из окружноговидео в 3д" ID="ID_407409615" CREATED="1603548236310" MODIFIED="1603548236310"/>
<node TEXT="детализация это рода работы" ID="ID_1038595018" CREATED="1603548236312" MODIFIED="1603548363409"/>
<node TEXT="надо без детализации сделать прямолинейное решение в вау эффектом" ID="ID_521898831" CREATED="1603548236314" MODIFIED="1603548236314"/>
<node TEXT="глянуть проекцию на пресс релизы" ID="ID_915090337" CREATED="1603548236315" MODIFIED="1603548236315"/>
<node TEXT="парящая линия - понятная ценность" ID="ID_1892198606" CREATED="1603548236317" MODIFIED="1603548236317">
<node TEXT="сделать три кадра с парящей линией." ID="ID_1720838332" CREATED="1603548236319" MODIFIED="1603548236319"/>
</node>
<node TEXT="человек берёт сотовый телефон определяет каким-то образом координаты свои" ID="ID_1390679250" CREATED="1603548236322" MODIFIED="1603548236322"/>
<node TEXT="и ему в зависимости от того чего он хочет" ID="ID_1265552026" CREATED="1603548236323" MODIFIED="1603548236323"/>
<node TEXT="ему это надо тоже ввести" ID="ID_645316923" CREATED="1603548236325" MODIFIED="1603548236325"/>
<node TEXT="он получает летящую линию маршрута оптимальным образом" ID="ID_388694440" CREATED="1603548236326" MODIFIED="1603548236326">
<node TEXT="!ремарка - проработать модель внимания в процессе применения честемы человеком на ходу" ID="ID_1912808759" CREATED="1603548236327" MODIFIED="1603548236327"/>
<node TEXT="стоит" ID="ID_1236121099" CREATED="1603548236328" MODIFIED="1603548236328"/>
<node TEXT="идёт" ID="ID_1798766824" CREATED="1603548236330" MODIFIED="1603548236330"/>
<node TEXT="поворачивается" ID="ID_1349556326" CREATED="1603548236330" MODIFIED="1603548236330"/>
<node TEXT="где стоит" ID="ID_1295223562" CREATED="1603548236331" MODIFIED="1603548236331"/>
</node>
<node TEXT="в целом надо понимать что у них одна из задач, это чтобы приложуха работала без интернета" ID="ID_1154142183" CREATED="1603548236331" MODIFIED="1603548236331">
<node TEXT="!режим подобно snmp trap, сигнал по ивенту запроса на навигацию" ID="ID_1132907120" CREATED="1603548236332" MODIFIED="1603548236332"/>
<node TEXT="!! Составить список эелементов данных событий при навигации" ID="ID_1138365977" CREATED="1603548236333" MODIFIED="1603548397929"/>
<node TEXT="запрос подсказки аудио" ID="ID_1228912247" CREATED="1603548236334" MODIFIED="1603548236334"/>
<node TEXT="запрос подсказки видео" ID="ID_1956477837" CREATED="1603548236335" MODIFIED="1603548236335"/>
<node TEXT="верификация местоположения" ID="ID_41038109" CREATED="1603548236336" MODIFIED="1603548236336"/>
<node TEXT="обращение к приложению" ID="ID_80008568" CREATED="1603548236336" MODIFIED="1603548236336"/>
<node TEXT="элемент текущие координаты+ тип запроса на навигацию - отправка на сервер" ID="ID_1872938530" CREATED="1603548236337" MODIFIED="1603548236337"/>
</node>
<node TEXT="чтобы она ничего не подтягивала могла в оффлайн режиме работать" ID="ID_1812468104" CREATED="1603548236338" MODIFIED="1603548236338"/>
<node TEXT="соответственно при таких раскладах, много деталей суперских мы еще и не сможем туда запихать." ID="ID_407666345" CREATED="1603548236340" MODIFIED="1603548236340">
<node TEXT="!демо" ID="ID_514277162" CREATED="1603548236341" MODIFIED="1603548236341"/>
<node TEXT="оффлайнавигация аудио - ввод справочного кода локации 591А 483G номер места и буква направление" ID="ID_489154111" CREATED="1603548236342" MODIFIED="1603548236342"/>
<node TEXT="оффлайн навигация ввод кода - ввод справочного кода локации 591А 483G номер места и буква направление" ID="ID_263488364" CREATED="1603548236343" MODIFIED="1603548236343"/>
<node TEXT="оффлайн навигация по кюар" ID="ID_967322028" CREATED="1603548236344" MODIFIED="1603548236344"/>
<node TEXT="оффлайн навигация по свайп картинке" ID="ID_1528665561" CREATED="1603548236346" MODIFIED="1603548236346"/>
<node TEXT="полу оффлайн" ID="ID_1385528681" CREATED="1603548236347" MODIFIED="1603548236347"/>
<node TEXT="онлайн навигация" ID="ID_110581399" CREATED="1603548236349" MODIFIED="1603548236349"/>
</node>
<node TEXT="поэтому я бы предложил сконцентрироваться именно на маршрутизации" ID="ID_609680744" CREATED="1603548236350" MODIFIED="1603548236350"/>
<node TEXT="то есть построение оптимального маршрута по цифровому двойнику" ID="ID_1644903256" CREATED="1603548236351" MODIFIED="1603548236351">
<node TEXT="!модель сравнения идеального маршрута и фактического." ID="ID_699610920" CREATED="1603548236354" MODIFIED="1603548236354"/>
<node TEXT="при онлайн просто дельту считать по координатам" ID="ID_657992954" CREATED="1603548236356" MODIFIED="1603548236356"/>
<node TEXT="при оффлайн сравнивать количество шагов и темп" ID="ID_198407504" CREATED="1603548236357" MODIFIED="1603548236357"/>
<node TEXT="найти алгоритмы шаги в расстояние при помощи акселерометра" ID="ID_117691865" CREATED="1603548236358" MODIFIED="1603548236358"/>
</node>
<node TEXT="исходя из того где находится пользователь и точки куда ему надо прийти" ID="ID_1101529030" CREATED="1603548236360" MODIFIED="1603548236360">
<node TEXT="!типы маршрутов и сравнений" ID="ID_591455199" CREATED="1603548236361" MODIFIED="1603548236361"/>
<node TEXT="проходка на станции" ID="ID_344790962" CREATED="1603548236363" MODIFIED="1603548236363"/>
<node TEXT="проезд на поезде" ID="ID_1478674826" CREATED="1603548236364" MODIFIED="1603548236364"/>
<node TEXT="обработка ошибок маршрута" ID="ID_38055077" CREATED="1603548236365" MODIFIED="1603548236365"/>
<node TEXT="вы ошиблись или решили сменить маршрут или сделать детур?" ID="ID_8396345" CREATED="1603548236365" MODIFIED="1603548236365"/>
<node TEXT="режим детура - перерасчёт маршрута" ID="ID_1104873116" CREATED="1603548236365" MODIFIED="1603548236365"/>
<node TEXT="ввод дополнительных целей" ID="ID_1614620728" CREATED="1603548236366" MODIFIED="1603548236366"/>
</node>
<node TEXT="Яр" ID="ID_233476157" CREATED="1603548236368" MODIFIED="1603548236368"/>
<node TEXT="надо сделать МВП -МВП" ID="ID_1964406123" CREATED="1603548236369" MODIFIED="1603548236369"/>
<node TEXT="определить координаты не вопрос" ID="ID_301447438" CREATED="1603548236369" MODIFIED="1603548236369"/>
<node TEXT="что касается локально и без интернета, почему же?" ID="ID_129831858" CREATED="1603548236370" MODIFIED="1603548236370"/>
<node TEXT="сейчас везде есть интернет" ID="ID_211901235" CREATED="1603548236371" MODIFIED="1603548236371"/>
<node TEXT="облако точек можно хранить в мобиле" ID="ID_162704625" CREATED="1603548236372" MODIFIED="1603548236372"/>
<node TEXT="и дальше по облаку точек находим координату" ID="ID_343308924" CREATED="1603548236374" MODIFIED="1603548236374">
<node TEXT="!яр-что подразумевается под облаком точек?" ID="ID_560271374" CREATED="1603548236375" MODIFIED="1603548236375"/>
<node TEXT="реперные от маршрута? к" ID="ID_1503193154" CREATED="1603548236376" MODIFIED="1603548236376"/>
<node TEXT="как их генерировать?" ID="ID_1561272371" CREATED="1603548236379" MODIFIED="1603548508833"/>
<node TEXT="!!робот переключения между системами координат" ID="ID_1327382816" CREATED="1603548236380" MODIFIED="1603548236380">
<node TEXT="таблица сравнения способов опреденения координат" ID="ID_1690770367" CREATED="1603548236381" MODIFIED="1603548236381"/>
<node TEXT="скорость поиска" ID="ID_1994978331" CREATED="1603548236382" MODIFIED="1603548236382"/>
<node TEXT="точность" ID="ID_926822220" CREATED="1603548236384" MODIFIED="1603548236384"/>
<node TEXT="краткосросная точность" ID="ID_1303563248" CREATED="1603548236384" MODIFIED="1603548236384"/>
<node TEXT="зависимость от внещних факторов" ID="ID_364584425" CREATED="1603548236385" MODIFIED="1603548236385"/>
<node TEXT="зависимость от внутренних факторов" ID="ID_690232048" CREATED="1603548236386" MODIFIED="1603548236386"/>
<node TEXT="возможность усредниения" ID="ID_1698069128" CREATED="1603548236388" MODIFIED="1603548236388"/>
<node TEXT="зоны прогнозирования смены координат" ID="ID_839807709" CREATED="1603548236389" MODIFIED="1603548236389"/>
<node TEXT="время действия координат в зависимости от зоны и темпа движения" ID="ID_42120137" CREATED="1603548236390" MODIFIED="1603548236390"/>
<node TEXT="возможные помехи при определении" ID="ID_1649837969" CREATED="1603548236391" MODIFIED="1603548236391"/>
<node TEXT="возможность работы опредения координат в толпе" ID="ID_299688114" CREATED="1603548236392" MODIFIED="1603548236392"/>
<node TEXT="возможность опредения координат когда мало народу" ID="ID_483570006" CREATED="1603548236394" MODIFIED="1603548236394"/>
<node TEXT="скорость определения координат" ID="ID_648932201" CREATED="1603548236395" MODIFIED="1603548236395"/>
<node TEXT="требования для координации по зонам метро, например точки коронных моментов, то есть моменты решений влево или вправо" ID="ID_1571547256" CREATED="1603548236396" MODIFIED="1603548236396"/>
<node TEXT="краткосрочные долгосрочные ориентиры\" ID="ID_352210721" CREATED="1603548236397" MODIFIED="1603548236397"/>
<node TEXT="расчет количества альтернатив движения для однозначности подсказок" ID="ID_1466865969" CREATED="1603548236398" MODIFIED="1603548236398"/>
<node TEXT="возможность примерения алгоритмов ии" ID="ID_1956135822" CREATED="1603548236399" MODIFIED="1603548236399"/>
</node>
</node>
<node TEXT="что тогда реализовать" ID="ID_1647061594" CREATED="1603548236401" MODIFIED="1603548236401"/>
<node TEXT="давайте подумаем чтобы делать мвп мвп ну желательно как-то сделать по изящному" ID="ID_245754406" CREATED="1603548236401" MODIFIED="1603548236401"/>
<node TEXT="нужно продумать юзер экспириенс" ID="ID_188636006" CREATED="1603548236402" MODIFIED="1603548236402"/>
<node TEXT="чтобы было удобно внести координаты" ID="ID_135868381" CREATED="1603548236403" MODIFIED="1603548236403">
<node TEXT="!внести или верифицировать" ID="ID_1669221126" CREATED="1603548236405" MODIFIED="1603548236405"/>
</node>
<node TEXT="возможность удобно указать свои предпочтения" ID="ID_1462008784" CREATED="1603548236406" MODIFIED="1603548572738"/>
<node TEXT="не хочу идти по этому эскалатор," ID="ID_311355799" CREATED="1603548236407" MODIFIED="1603548236407"/>
<node TEXT="я хочу посмотеть какую-то достопримечательность и тд" ID="ID_607806158" CREATED="1603548236409" MODIFIED="1603548236409"/>
<node TEXT="потом про детали, коль говоришь" ID="ID_243751537" CREATED="1603548236410" MODIFIED="1603548236410"/>
<node TEXT="там гид по метро встроить" ID="ID_7999483" CREATED="1603548236411" MODIFIED="1603548236411"/>
<node TEXT="или что угодно, это круто" ID="ID_649945686" CREATED="1603548236412" MODIFIED="1603548236412"/>
<node TEXT="но мы может об этом только рассказать как мы фьюче можем сделать" ID="ID_1418009988" CREATED="1603548236413" MODIFIED="1603548236413"/>
<node TEXT="а вот за два дня хакатона" ID="ID_1476063941" CREATED="1603548236414" MODIFIED="1603548236414"/>
<node TEXT="мы можем сделать просто базу и с этоу базой надо хорошо выглядеть" ID="ID_1838074425" CREATED="1603548236416" MODIFIED="1604176544321"/>
<node TEXT="Ник" ID="ID_1651727877" CREATED="1603548236417" MODIFIED="1603548236417"/>
<node TEXT="история про детализацию я как вижу, как способ забежать вперед и посмотреть а что там будет" ID="ID_413916380" CREATED="1603548236418" MODIFIED="1603740589664"/>
<node TEXT="и выбрать фича фич" ID="ID_1226449175" CREATED="1603548236419" MODIFIED="1603548236419">
<node TEXT="!либо подготовить конструкции или конструктор из элементов которые пойдет в готовку, справочные материалы и заготовки" ID="ID_48365571" CREATED="1603548236421" MODIFIED="1603548236421"/>
<node TEXT="чтобы реализация шла плавно" ID="ID_1074948906" CREATED="1603548605723" MODIFIED="1603548617090"/>
<node TEXT="справочные списки" ID="ID_1182379720" CREATED="1603548618916" MODIFIED="1603548622667"/>
</node>
<node TEXT="я с трудом понимаю эту бабульку, которая хочет найти поезд метро, она приехала из волгогради и вот она не может сориентироваться" ID="ID_80231755" CREATED="1603548236423" MODIFIED="1603548236423">
<node TEXT="!онбординг панель" ID="ID_1783050860" CREATED="1603548236423" MODIFIED="1603548236423"/>
<node TEXT="вывод сбоку маршрута выбора опций - пошагово, чтобы можно было скакунть к правке опций, но изначалоно это несколько последовательных экранов выбора опций" ID="ID_169013406" CREATED="1603548236425" MODIFIED="1603548236425"/>
<node TEXT="и сохранение результат и отметки о качество в отдельный профиль" ID="ID_1018369903" CREATED="1603548236425" MODIFIED="1603548236425"/>
<node TEXT="рехим сравнения опций выбранных и факт движения" ID="ID_955549279" CREATED="1603548236426" MODIFIED="1603548236426"/>
<node TEXT="режим удаленного ассистента" ID="ID_1156845121" CREATED="1603548236427" MODIFIED="1603548236427"/>
<node TEXT="трекер перемещений с аудио подсказками" ID="ID_671535593" CREATED="1603548236428" MODIFIED="1603548236428"/>
</node>
<node TEXT="то есть понятно что в игровой манере кому-то это может заходить это будет весело и прикольно" ID="ID_20554842" CREATED="1603548236429" MODIFIED="1603548236429"/>
<node TEXT="но вот реальному пользователю, с реальной проблемой" ID="ID_1708229652" CREATED="1603548236430" MODIFIED="1603548236430"/>
<node TEXT="например женщина с ребенком" ID="ID_1025804804" CREATED="1603548236431" MODIFIED="1603548236431">
<node TEXT="! режим" ID="ID_933482463" CREATED="1603548236433" MODIFIED="1603548236433"/>
<node TEXT="ведущий и ведомый" ID="ID_1547363839" CREATED="1603548236434" MODIFIED="1603548236434"/>
<node TEXT="профиль родителя и" ID="ID_999661734" CREATED="1603548236435" MODIFIED="1603548236435"/>
<node TEXT="профиль ребенка, чтобы сложнее было потеряться" ID="ID_1981327745" CREATED="1603548236435" MODIFIED="1603548236435"/>
<node TEXT="или быстро найтись" ID="ID_1521498348" CREATED="1603548236436" MODIFIED="1603548236436"/>
<node TEXT="!! или группа школьников с преподователями , тогда два-ти ведущих" ID="ID_1756126390" CREATED="1603548236437" MODIFIED="1603548236437"/>
<node TEXT="и группа ведомых" ID="ID_1543282960" CREATED="1603548236438" MODIFIED="1603548236438"/>
<node TEXT="указываем линк на команду и мониторим движение кучкой, чтобы все были в безопаснгости и не терялись" ID="ID_1991126465" CREATED="1603548236439" MODIFIED="1603548236439"/>
</node>
<node TEXT="как эта штука будет работать например в толпе" ID="ID_1001663884" CREATED="1603548236439" MODIFIED="1603548236439"/>
<node TEXT="например если плотность большая" ID="ID_101949257" CREATED="1603548236441" MODIFIED="1603548236441">
<node TEXT="!думаю в толпе самое удобное это аудио гид с подсказками куда идут люди" ID="ID_459125350" CREATED="1603548236442" MODIFIED="1603548236442"/>
<node TEXT="к какой толе можно присоединяться а к какой нет." ID="ID_1552482614" CREATED="1603548236443" MODIFIED="1603548667174"/>
</node>
<node TEXT="не будет ли человек засмотревшись на телефон случайно падать на рельсы" ID="ID_433168793" CREATED="1603548236445" MODIFIED="1603548236445"/>
<node TEXT="то есть вот такие условия надо продумать" ID="ID_412533737" CREATED="1603548236446" MODIFIED="1603548236446">
<node TEXT="! режим аудиогида" ID="ID_962182423" CREATED="1603548236448" MODIFIED="1603548236448"/>
<node TEXT="аудио предупреждения отойти от линии вглубь перрона" ID="ID_630447406" CREATED="1603548236449" MODIFIED="1603548236449"/>
<node TEXT="предупреждения в ар слое - мол, осторожно рельсы!" ID="ID_669697567" CREATED="1603548236450" MODIFIED="1603548236450"/>
</node>
<node TEXT="Ярослав-" ID="ID_1271998697" CREATED="1603548236452" MODIFIED="1604096009868"/>
<node TEXT="и основное что они просят это навигацию" ID="ID_1616714924" CREATED="1603548236454" MODIFIED="1603548236454"/>
<node TEXT="кейс звучит именно так" ID="ID_363359533" CREATED="1603548236454" MODIFIED="1603548236454"/>
<node TEXT="поэтому я предлагаю сфокусироваться именно на навигационнной части" ID="ID_663108649" CREATED="1603548236455" MODIFIED="1603548236455"/>
<node TEXT="и может быть предусмотреть какие-то вау эффекты," ID="ID_1903960006" CREATED="1603548236456" MODIFIED="1603548236456"/>
<node TEXT="которые могу зацепить бизнес заказчиков" ID="ID_815926876" CREATED="1603548236457" MODIFIED="1603548236457"/>
<node TEXT="скажут: ну типа круто!" ID="ID_213171777" CREATED="1603548236458" MODIFIED="1603548236458"/>
<node TEXT="это максимум из деталей что мы сможем сделать за два дня" ID="ID_1422463498" CREATED="1603548236459" MODIFIED="1603548236459"/>
<node TEXT="Яр" ID="ID_1084768681" CREATED="1603548236460" MODIFIED="1603548236460"/>
<node TEXT="я считаю это классно это применимо вообще где угодно" ID="ID_1365145707" CREATED="1603548236461" MODIFIED="1603548236461"/>
<node TEXT="это можно сделать по городу" ID="ID_1263270991" CREATED="1603548236462" MODIFIED="1603548236462"/>
<node TEXT="это можно сделать по торговому центру" ID="ID_1170672457" CREATED="1603548236463" MODIFIED="1603548236463"/>
<node TEXT="и здесь классная монетизация" ID="ID_1128286729" CREATED="1603548236464" MODIFIED="1603548236464"/>
<node TEXT="потому что мы показываем навигацию с метро в метро" ID="ID_725650716" CREATED="1603548236466" MODIFIED="1603548236466">
<node TEXT="!минималки по требованиям для демонстарции маршрутизации" ID="ID_1587311241" CREATED="1603548236467" MODIFIED="1603548236467"/>
<node TEXT="масштабирование маршрутизации" ID="ID_733953322" CREATED="1603548236468" MODIFIED="1603548236468"/>
</node>
<node TEXT="и здесь мы можем показывать бизнес точки" ID="ID_213105006" CREATED="1603548236470" MODIFIED="1603548236470"/>
<node TEXT="типа здесь для точки получи скидку по промокоду" ID="ID_1143497556" CREATED="1603548236471" MODIFIED="1603548236471"/>
<node TEXT="еще немного" ID="ID_663216379" CREATED="1603548236472" MODIFIED="1603548236472"/>
<node TEXT="я не вижу смысла отрисовывать метро например" ID="ID_871475669" CREATED="1603548236473" MODIFIED="1603548236473"/>
<node TEXT="ну 2д карту это ок" ID="ID_1426694736" CREATED="1603548236474" MODIFIED="1603548236474"/>
<node TEXT="чтобы показать людям оптимальные маршруты" ID="ID_110378701" CREATED="1603548236475" MODIFIED="1603548236475">
<node TEXT="!или знакомые маршруты" ID="ID_1847220549" CREATED="1603548236476" MODIFIED="1603548236476"/>
</node>
<node TEXT="а отрисовывать в ар полные модели?" ID="ID_1805329446" CREATED="1603548236477" MODIFIED="1603548236477"/>
<node TEXT="ну кто и будет разглядывать и зачем" ID="ID_67117598" CREATED="1603548236478" MODIFIED="1603548236478"/>
<node TEXT="у меня есть такой кейс где я отрисовывал целый дом в ар" ID="ID_244769267" CREATED="1603548236479" MODIFIED="1603548236479"/>
<node TEXT="реал тайм размер и времени" ID="ID_1961686115" CREATED="1603548236482" MODIFIED="1603548236482"/>
<node TEXT="есть видео на канале" ID="ID_1777296912" CREATED="1603548236484" MODIFIED="1603548236484"/>
<node TEXT="и можно с планшета позгрузиться походить по нему" ID="ID_1449338970" CREATED="1603548236487" MODIFIED="1603548236487"/>
<node TEXT="а можно и в маленьком размере посмотреть" ID="ID_369812319" CREATED="1603548236488" MODIFIED="1603548736338"/>
<node TEXT="он встаёт на пол" ID="ID_1111806888" CREATED="1603548236490" MODIFIED="1603548236490"/>
<node TEXT="есть видео это прикольно но это не заходит" ID="ID_138273710" CREATED="1603548236491" MODIFIED="1603548236491"/>
<node TEXT="вау есть но интереса нет, пользоваться вряд ли кто-то будет" ID="ID_344804833" CREATED="1603548236492" MODIFIED="1603548236492"/>
<node TEXT="а навигация, именно трёхмерная это класс" ID="ID_397123821" CREATED="1603548236494" MODIFIED="1603548236494"/>
<node TEXT="есть гугл мэпс, офигенская навигация" ID="ID_605290186" CREATED="1603548236495" MODIFIED="1603548236495"/>
<node TEXT="еще для кореи?" ID="ID_845972712" CREATED="1603548236497" MODIFIED="1603548236497"/>
<node TEXT="можно оттуда фишки попробовать притянуть" ID="ID_774872649" CREATED="1603548236498" MODIFIED="1603548236498"/>
<node TEXT="и в результате похожее сделать то есть мы в метро зашли и" ID="ID_1147931260" CREATED="1603548236499" MODIFIED="1603548753657"/>
<node TEXT="нам показывается навигация" ID="ID_1334366486" CREATED="1603548236499" MODIFIED="1603548236499"/>
<node TEXT="как навигация рассчитывается" ID="ID_960237502" CREATED="1603548236501" MODIFIED="1603548236501"/>
<node TEXT="а ар нужен для того чтобы отобразить" ID="ID_1630098787" CREATED="1603548236502" MODIFIED="1603548236502"/>
<node TEXT="здесь это будет очень хорошо на рынок заходить" ID="ID_1366105665" CREATED="1603548236503" MODIFIED="1603548770146"/>
<node TEXT="единственное что пользователи не захотят скачивать приложение" ID="ID_900843460" CREATED="1603548236505" MODIFIED="1603548236505"/>
<node TEXT="это большая боль здесь" ID="ID_1459399988" CREATED="1603548236507" MODIFIED="1603548236507"/>
<node TEXT="но если мы говорим про купоны скидки и вообще, то почему бы и нет" ID="ID_1569108703" CREATED="1603548236508" MODIFIED="1603548236508"/>
<node TEXT="люди могут скачивать приложение не только ради навигации" ID="ID_1392087240" CREATED="1603548236509" MODIFIED="1603548236509"/>
<node TEXT="а для того чтобы получить купон в соседней бургерной" ID="ID_435045" CREATED="1603548236510" MODIFIED="1603548236510"/>
<node TEXT="Яр-" ID="ID_454398682" CREATED="1603548236512" MODIFIED="1604096020454"/>
<node TEXT="а почему они не захотят приложуху скачивать?" ID="ID_1741563407" CREATED="1603548236514" MODIFIED="1603548236514"/>
<node TEXT="ну никто не хочет скачивать" ID="ID_1065990793" CREATED="1603548236514" MODIFIED="1603548236514"/>
<node TEXT="особенно пользователи Айос" ID="ID_1988423289" CREATED="1603548236516" MODIFIED="1603548236516"/>
<node TEXT="потому что память ограничена" ID="ID_799636215" CREATED="1603548236518" MODIFIED="1603548236518"/>
<node TEXT="у нас в россии большинство айосников это 6, 7, SE айфоны и там мало памяти" ID="ID_1991586756" CREATED="1603548236520" MODIFIED="1603548236520"/>
<node TEXT="поэтому конечно в идеале всё на веб" ID="ID_78284067" CREATED="1603548236521" MODIFIED="1603548236521"/>
<node TEXT="веб ар только развивается" ID="ID_1553799965" CREATED="1603548236523" MODIFIED="1603548236523"/>
<node TEXT="и такой кейс будет сделать сложно" ID="ID_793916754" CREATED="1603548236524" MODIFIED="1603548236524"/>
<node TEXT="в общем целом я представляю следующим образом" ID="ID_1581946964" CREATED="1603548236525" MODIFIED="1603548236525"/>
<node TEXT="у нас просто одно метро" ID="ID_1481880119" CREATED="1603548236526" MODIFIED="1603548236526"/>
<node TEXT="получаем якоря" ID="ID_1938721249" CREATED="1603548236527" MODIFIED="1603548236527"/>
<node TEXT="пусть это будут облачные" ID="ID_973617820" CREATED="1603548236528" MODIFIED="1603548236528">
<node TEXT="!! как обеспечить минималку по демонстрации маршрутизации?" ID="ID_381241278" CREATED="1603548236529" MODIFIED="1603548236529"/>
</node>
<node TEXT="пусть в облаке хранятся" ID="ID_660960740" CREATED="1603548236529" MODIFIED="1603548794474"/>
<node TEXT="и дальше их нужно оцифровать" ID="ID_321121208" CREATED="1603548236531" MODIFIED="1603548236531"/>
<node TEXT="благодаря коре мы узнаём где мы находимся" ID="ID_1685048445" CREATED="1603548236532" MODIFIED="1603548236532"/>
<node TEXT="и дальше мы показываем стрелочки в ар куда же нам идти" ID="ID_538971620" CREATED="1603548236533" MODIFIED="1603548236533"/>
<node TEXT="вниз по эскалатору," ID="ID_1263206106" CREATED="1603548236535" MODIFIED="1603548236535"/>
<node TEXT="вверх по эскалатору" ID="ID_170299656" CREATED="1603548236536" MODIFIED="1603548236536"/>
<node TEXT="какой нам выход нужен" ID="ID_1653853241" CREATED="1603548236537" MODIFIED="1603548236537"/>
<node TEXT="и тд, такой функционал," ID="ID_1639166198" CREATED="1603548236538" MODIFIED="1603548236538"/>
<node TEXT="понятно что куда мы хотим прийти надо тоже подумать" ID="ID_1690248733" CREATED="1603548236538" MODIFIED="1603548236538"/>
<node TEXT="это уже не по ар не по юнити это надо алгоритм разрабатывать оптимальных путей" ID="ID_1165383650" CREATED="1603548236539" MODIFIED="1603548236539">
<node TEXT="!!важно алгоритм оптимальных путей" ID="ID_523178495" CREATED="1603548236541" MODIFIED="1603548236541"/>
<node TEXT="соколов изложить драфт" ID="ID_480090096" CREATED="1603548236542" MODIFIED="1603548236542"/>
</node>
<node TEXT="надо показать просто прототип" ID="ID_168435800" CREATED="1603548236543" MODIFIED="1603548236543"/>
<node TEXT="да, визуал" ID="ID_1705488078" CREATED="1603548236544" MODIFIED="1603548236544"/>
<node TEXT="но с элементами кода" ID="ID_954668857" CREATED="1603548236546" MODIFIED="1603548236546"/>
<node TEXT="элементами продукта" ID="ID_258124507" CREATED="1603548236546" MODIFIED="1603548236546"/>
<node TEXT="вот он запустился и мы" ID="ID_992697" CREATED="1603548236547" MODIFIED="1603548236547"/>
<node TEXT="мы в конце концов аркодим на станции" ID="ID_57418500" CREATED="1603548236547" MODIFIED="1603548236547">
<node TEXT="!аркодим слово" ID="ID_744596844" CREATED="1603548236548" MODIFIED="1603548236548"/>
</node>
<node TEXT="можно сделать демку как идем на станции метро" ID="ID_1443548723" CREATED="1603548236549" MODIFIED="1603548236549">
<node TEXT="!канвас в портретном режиме для блендера 9на21" ID="ID_1496909977" CREATED="1603548236550" MODIFIED="1603548236550"/>
</node>
<node TEXT="вау эффект" ID="ID_471413637" CREATED="1603548236552" MODIFIED="1603548236552"/>
<node TEXT="основа будет чисто функциональная, но чтобы и как-то и поразвлечь пользователя" ID="ID_989747764" CREATED="1603548236555" MODIFIED="1603548236555"/>
<node TEXT="можно подумать просто схематичная станция, вагон, платформа, эскалатор, вот что-то такое" ID="ID_1105719397" CREATED="1603548236556" MODIFIED="1603548236556"/>
<node TEXT="стобы это вписалось в целом в идеологию" ID="ID_1846991629" CREATED="1603548236557" MODIFIED="1603548236557"/>
<node TEXT="цифровых двойников" ID="ID_1934600068" CREATED="1603548236558" MODIFIED="1603548236558"/>
<node TEXT="и навигацию по цифровым двойникам" ID="ID_294336849" CREATED="1603548236559" MODIFIED="1603548236559"/>
<node TEXT="мы когда это сделаем может придём ещё к каким-то интересным идеям навигационным" ID="ID_257396935" CREATED="1603548236559" MODIFIED="1603548837425"/>
<node TEXT="мы сейчас как-то не видим" ID="ID_705419505" CREATED="1603548236561" MODIFIED="1603548236561"/>
<node TEXT="это будет такой серч своего рода решений" ID="ID_494070711" CREATED="1603548236562" MODIFIED="1603548236562"/>
<node TEXT="Юля" ID="ID_394110842" CREATED="1603548236564" MODIFIED="1604096045963"/>
<node TEXT="Коль - протоколируй это дело" ID="ID_1541751201" CREATED="1603548236565" MODIFIED="1603548236565"/>
<node TEXT="чтобы яровлав мог прочесть в любой момент" ID="ID_1749393791" CREATED="1603548236566" MODIFIED="1603548236566"/>
<node TEXT="яр" ID="ID_637774037" CREATED="1603548236568" MODIFIED="1603548236568"/>
<node TEXT="ок есть наработки" ID="ID_352534637" CREATED="1603548236570" MODIFIED="1603548236570"/>
<node TEXT="требуют исходный код" ID="ID_1564331601" CREATED="1603548236572" MODIFIED="1603548236572"/>
<node TEXT="даём базу" ID="ID_269234675" CREATED="1603548236572" MODIFIED="1603548236572"/>
</node>
<node TEXT="видеколл чат дискорд Команда дельта" ID="ID_1421234972" CREATED="1603740349546" MODIFIED="1604130222481">
<node TEXT="https://www.navilens.com//" ID="ID_514875355" CREATED="1603740428379" MODIFIED="1603740428379" LINK="https://www.navilens.com//"/>
<node TEXT="sokolctoСегодня, в 19:17" ID="ID_668791504" CREATED="1603740428381" MODIFIED="1603740428381"/>
<node TEXT="sokolctoСегодня, в 19:18" ID="ID_261906638" CREATED="1603740428386" MODIFIED="1603740428386"/>
<node TEXT="кто тут кто? напишите имя в чат" ID="ID_1930148333" CREATED="1603740428386" MODIFIED="1603740428386"/>
<node TEXT="Коля, кликай на General" ID="ID_753815023" CREATED="1603740428389" MODIFIED="1603740428389"/>
<node TEXT="JULLIMONСегодня, в 19:20" ID="ID_873461933" CREATED="1603740428390" MODIFIED="1603740428390"/>
<node TEXT="неполадки с миком, сек" ID="ID_1979634844" CREATED="1603740428391" MODIFIED="1603740428391"/>
<node TEXT="Юля Гусева" ID="ID_1760187714" CREATED="1603740428391" MODIFIED="1603740428391"/>
<node TEXT="Если ты едешь в объезд, то получаешь плюшку." ID="ID_519082837" CREATED="1603740428393" MODIFIED="1603740428393"/>
<node TEXT="AR реклама" ID="ID_1469581052" CREATED="1603740428395" MODIFIED="1603740428395"/>
<node TEXT="AR реклама" ID="ID_1242657519" CREATED="1603740428396" MODIFIED="1603740428396"/>
<node TEXT="Интегрировать несколько каналов информации" ID="ID_1584429938" CREATED="1603740428397" MODIFIED="1603740428397"/>
<node TEXT="Вопросы: критерии оценки проектов" ID="ID_180445988" CREATED="1603740428398" MODIFIED="1603740428398"/>
<node TEXT="что предпочтительнее: код, дизайн или экономика" ID="ID_1841660" CREATED="1603740428399" MODIFIED="1603740428399"/>
<node TEXT="Нужно ли делать cust dev" ID="ID_112201521" CREATED="1603740428401" MODIFIED="1603740428401"/>
<node TEXT="https://miro.com/" ID="ID_571020821" CREATED="1603740428403" MODIFIED="1603740428403" LINK="https://miro.com/"/>
<node TEXT="https://miro.com/" ID="ID_499897671" CREATED="1603740428403" MODIFIED="1603740428403" LINK="https://miro.com/"/>
<node TEXT="Miro | Free Online Collaborative Whiteboard Platform" ID="ID_856403029" CREATED="1603740428404" MODIFIED="1603740428404"/>
<node TEXT="Scalable, secure, cross-device and enterprise-ready team collaboration whiteboard for distributed teams. Join 9M+ users from around the world." ID="ID_639474395" CREATED="1603740428405" MODIFIED="1603740428405"/>
<node TEXT="AsterFerre" ID="ID_807373954" CREATED="1603740428409" MODIFIED="1603740428409">
<node TEXT="приземляется на сервере." ID="ID_1310941604" CREATED="1603740428410" MODIFIED="1603740428410"/>
</node>
<node TEXT="Сегодня, в 19:45" ID="ID_952441134" CREATED="1603740428410" MODIFIED="1603740428410"/>
<node TEXT="AsterFerreСегодня, в 19:46" ID="ID_967207182" CREATED="1603740428411" MODIFIED="1603740428411"/>
<node TEXT="Привет" ID="ID_852341023" CREATED="1603740428411" MODIFIED="1603740428411"/>
<node TEXT="Привет!" ID="ID_1208001562" CREATED="1603740428413" MODIFIED="1603740428413"/>
<node TEXT="AsterFerreСегодня, в 19:46" ID="ID_633278271" CREATED="1603740428414" MODIFIED="1603740428414"/>
<node TEXT="Добрался до вас наконец то" ID="ID_1829476528" CREATED="1603740428415" MODIFIED="1603740428415"/>
<node TEXT=":slight_smile:" ID="ID_903576444" CREATED="1603740428419" MODIFIED="1603740428419"/>
<node TEXT="Подключайся к General каналу" ID="ID_662849916" CREATED="1603740428420" MODIFIED="1603740428420"/>
<node TEXT="sokolctoСегодня, в 19:46" ID="ID_1777887373" CREATED="1603740428422" MODIFIED="1603740428422"/>
<node TEXT="Ярослав привет!" ID="ID_769390426" CREATED="1603740428423" MODIFIED="1603740428423"/>
<node TEXT="голос включи" ID="ID_1337454415" CREATED="1603740428423" MODIFIED="1603740428423"/>
<node TEXT="AsterFerreСегодня, в 19:52" ID="ID_1941503817" CREATED="1603740428424" MODIFIED="1603740428424"/>
<node TEXT="https://www.youtube.com/channel/UCBl08O6OdXWHKBjDJf7vksQ" ID="ID_1668107934" CREATED="1603740428424" MODIFIED="1603740428424" LINK="https://www.youtube.com/channel/UCBl08O6OdXWHKBjDJf7vksQ"/>
<node TEXT="YouTube" ID="ID_451789243" CREATED="1603740428425" MODIFIED="1603740428425"/>
<node TEXT="Ярослав GoodAR" ID="ID_1165215994" CREATED="1603740428428" MODIFIED="1603740428428"/>
<node TEXT="киргизкий, узбекский, таджикский языки" ID="ID_1544453731" CREATED="1603740428430" MODIFIED="1603740428430"/>
<node TEXT="sokolctoСегодня, в 20:01" ID="ID_1266249495" CREATED="1603740428431" MODIFIED="1603740428431"/>
<node TEXT="можно слово?" ID="ID_1280450027" CREATED="1603740428432" MODIFIED="1603740428432"/>
<node TEXT="cjm" ID="ID_1965606127" CREATED="1603740428433" MODIFIED="1603740428433"/>
<node TEXT="пользователи" ID="ID_213680" CREATED="1603740428433" MODIFIED="1603740428433"/>
<node TEXT="путь пользователя" ID="ID_911484117" CREATED="1603740428434" MODIFIED="1603740428434"/>
<node TEXT="изучение проблематики пользователя на пути в метро" ID="ID_1948382070" CREATED="1603740428434" MODIFIED="1603740428434"/>
<node TEXT="чтение якорей" ID="ID_9299641" CREATED="1603740428435" MODIFIED="1603740428435"/>
<node TEXT="Привет," ID="ID_771908913" CREATED="1603740428436" MODIFIED="1603740428436"/>
<node TEXT="kukulogic (kukupopa)" ID="ID_949781376" CREATED="1603740428437" MODIFIED="1603740428437"/>
<node TEXT=". Поздоровайся со всеми!" ID="ID_1240989116" CREATED="1603740428438" MODIFIED="1603740428438"/>
<node TEXT="Сегодня, в 20:04" ID="ID_545272680" CREATED="1603740428439" MODIFIED="1603740428439"/>
<node TEXT="На какой поезд сесть - на правый или на левый" ID="ID_532360029" CREATED="1603740428440" MODIFIED="1604130222469"/>
<node TEXT="Через сколько приедет поезд" ID="ID_1732935569" CREATED="1603740428441" MODIFIED="1603740428441"/>
<node TEXT="Таблички не всегда удобны, приходится доходить до середины станции" ID="ID_1845204286" CREATED="1603740428443" MODIFIED="1603740428443"/>
<node TEXT="kukulogic (kukupopa)Сегодня, в 20:07" ID="ID_1474277422" CREATED="1603740428445" MODIFIED="1603740428445"/>
<node TEXT="Я с вами" ID="ID_3539221" CREATED="1603740428446" MODIFIED="1603740428446"/>
<node TEXT="Это дима, юнити" ID="ID_116467091" CREATED="1603740428448" MODIFIED="1603740428448"/>
<node TEXT="Привет Дима!" ID="ID_1530208416" CREATED="1603740428450" MODIFIED="1603740428450"/>
<node TEXT="Подключайся в General" ID="ID_1383483502" CREATED="1603740428451" MODIFIED="1603740428451"/>
<node TEXT="Боль - переход с одной станции на другую, ты боишься выйти не туда." ID="ID_1547457592" CREATED="1603740428452" MODIFIED="1603740428452"/>
<node TEXT="Нумерация выходов не всегда понятна, идешь по указателям и выходишь вместо первого выхода в четвертый" ID="ID_1947045322" CREATED="1603740428461" MODIFIED="1603740428461"/>
<node TEXT="Навигация между станциями метро, МЦК и МЦД" ID="ID_1059036506" CREATED="1603740428465" MODIFIED="1603740428465"/>
<node TEXT="sokolctoСегодня, в 20:09" ID="ID_1863564397" CREATED="1603740428482" MODIFIED="1603740428482"/>
<node TEXT="демонстрация в ар что на поверхности за тем или иным выходом с указателями улиц и центра" ID="ID_88868478" CREATED="1603740428484" MODIFIED="1603740428484"/>
<node TEXT="стоишь на станции смотришь в ар слой панорамой у предполагаемого выхода" ID="ID_689427725" CREATED="1603740428485" MODIFIED="1603740428485"/>
<node TEXT="ОК!" ID="ID_20296929" CREATED="1603740428513" MODIFIED="1603740428513"/>
<node TEXT="Предложение пользователю, чтобы он включил камеру и ему будет показываться путь" ID="ID_894995961" CREATED="1603740428515" MODIFIED="1603740428515"/>
<node TEXT="Подойдет для приезжих, иностранцев" ID="ID_1563663870" CREATED="1603740428516" MODIFIED="1603740428516"/>
<node TEXT="JULLIMONСегодня, в 20:22" ID="ID_1672175799" CREATED="1603740428521" MODIFIED="1603740428521"/>
<node TEXT="https://www.easyar.com/" ID="ID_457330368" CREATED="1603740428524" MODIFIED="1603740428524" LINK="https://www.easyar.com/"/>
<node TEXT="Augmented Reality &amp; AR SDK" ID="ID_124898727" CREATED="1603740428525" MODIFIED="1603740428525"/>
<node TEXT="EasyAR" ID="ID_527744243" CREATED="1603740428527" MODIFIED="1603740428527"/>
<node TEXT="EasyAR Sense is a standalone SDK, it provides flexible dataflow-oriented component-based API and do not depend on any non-system libraries or tools like Unity3D. Support for Unity, EasyAR Sense Unity Plugin, is a very thin wrapper to expose EasyAR Sense features into Unity. Al..." ID="ID_551781914" CREATED="1603740428533" MODIFIED="1603740428533"/>
<node TEXT="AsterFerreСегодня, в 20:31" ID="ID_1560928447" CREATED="1603740428534" MODIFIED="1603740428534"/>
<node TEXT="https://youtu.be/y_4mHKQIPgc" ID="ID_1571157729" CREATED="1603740428540" MODIFIED="1603740428540" LINK="https://youtu.be/y_4mHKQIPgc"/>
<node TEXT="YouTube" ID="ID_1316368991" CREATED="1603740428543" MODIFIED="1603740428543"/>
<node TEXT="Ярослав GoodAR" ID="ID_1487312880" CREATED="1603740428545" MODIFIED="1603740428545"/>
<node TEXT="9 мая 2020 г." ID="ID_776781337" CREATED="1603740428546" MODIFIED="1603740428546"/>
<node TEXT="https://youtu.be/8SnXnzMQlCo" ID="ID_723984255" CREATED="1603740428547" MODIFIED="1603740428547" LINK="https://youtu.be/8SnXnzMQlCo"/>
<node TEXT="YouTube" ID="ID_962682364" CREATED="1603740428547" MODIFIED="1603740428547"/>
<node TEXT="Ярослав GoodAR" ID="ID_1309953967" CREATED="1603740428551" MODIFIED="1603740428551"/>
<node TEXT="2 июля 2020 г." ID="ID_1935349897" CREATED="1603740428552" MODIFIED="1603740428552"/>
<node TEXT="AsterFerreСегодня, в 20:47" ID="ID_55685971" CREATED="1603740428553" MODIFIED="1603740428553"/>
<node TEXT="https://izx.io/" ID="ID_1092046071" CREATED="1603740428554" MODIFIED="1603740428554" LINK="https://izx.io/"/>
<node TEXT="sokolctoСегодня, в 21:21" ID="ID_1414511965" CREATED="1603740428555" MODIFIED="1603740428555"/>
</node>
</node>
<node TEXT="ПЛАН - ЗАДАЧИ ОТВ СРОКИ" ID="ID_1530664894" CREATED="1604130165235" MODIFIED="1604176719012">
<node TEXT="задачи сроки комментарии ответственные" ID="ID_436356499" CREATED="1603824388203" MODIFIED="1604095953300">
<node TEXT="Дима" ID="ID_832926356" CREATED="1603824434625" MODIFIED="1603824434625">
<node TEXT="вечер - модели станций" ID="ID_1559754071" CREATED="1603824434625" MODIFIED="1604130636599">
<node TEXT="Результат" ID="ID_239901326" CREATED="1603825438192" MODIFIED="1603825448392">
<node TEXT="набор моделей" ID="ID_154247156" CREATED="1603825466830" MODIFIED="1603825470914"/>
<node TEXT="сцена с моделями" ID="ID_1100770081" CREATED="1603825471538" MODIFIED="1603825480651"/>
<node TEXT="анимация сцены по трансформации из надземной подземной части в укладку на одну плоскость всех площадок в одну карту с элементами 3д" ID="ID_850077038" CREATED="1603825481038" MODIFIED="1603825552106"/>
</node>
</node>
</node>
<node TEXT="Юля" ID="ID_1908924191" CREATED="1603824434626" MODIFIED="1603824434626">
<node TEXT="кастомер ждорни мэп" ID="ID_1265565752" CREATED="1603824434628" MODIFIED="1603824434628">
<node TEXT="Результат" ID="ID_1133783239" CREATED="1603825438192" MODIFIED="1603825448392">
<node TEXT="таблица" ID="ID_642365221" CREATED="1603825556977" MODIFIED="1603825562311"/>
</node>
<node TEXT="Пример" ID="ID_700796094" CREATED="1603825705978" MODIFIED="1603825711232">
<node TEXT="Учитель (Представитель школы)" ID="ID_766201051" CREATED="1603825747101" MODIFIED="1603825773528">
<node ID="ID_1681947988" CREATED="1603826143276" MODIFIED="1604096572427"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table border="0" style="width: 80%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 0; border-right-width: 0; border-bottom-width: 0; border-left-width: 0">
      <tr>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            Этапы
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            Знакомство с сайтом
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            Выбор программы
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            Бронирование программы
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            Перед программой
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            Во время программы
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            После программы
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
      </tr>
      <tr>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            <b>Пользовательский опыт</b>
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
      </tr>
      <tr>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            Что делает
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Просматривает главную страницу
            </li>
            <li>
              Просматривает проекты школьников
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Просматривает список программ
            </li>
            <li>
              Просматривет страницу программы
            </li>
            <li>
              Просматривает раздел помощи пользователя
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Добавляет программу в корзину
            </li>
            <li>
              Указывает требуемые даты
            </li>
            <li>
              Отправляет заявку
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Утверждает программу
            </li>
            <li>
              Добавляет детей в программу
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Сопровождает группу
            </li>
            <li>
              Проходит повышение квалификации
            </li>
            <li>
              Следит за особенностями работы детей в программе
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Выполняет проектную работу с детьми
            </li>
            <li>
              Отмечает наградами детей
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
      </tr>
      <tr>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            Что думает и чувствует
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Требуется больше информации о проекте
            </li>
            <li>
              Как Зарегистрироваться?
            </li>
            <li>
              Как собрать группу?
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Нет чёткого понимания какая программа нужна
            </li>
            <li>
              Нет рекомендаций
            </li>
            <li>
              Нет удобного поиска и сравнения
            </li>
            <li>
              Недостаточно информации в разделе помощи
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Не уверен как оформить программу
            </li>
            <li>
              Не понятно кто и как эту программу исполнит
            </li>
            <li>
              Не понятно сколько и когда оплатить
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Должен выбирать оптимальное предложение
            </li>
            <li>
              Вариант должен понравиться школьникам и родителям
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Должен ориентироваться в новых условиях
            </li>
            <li>
              Его работа соответствует методологии?
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Была ли программа полезна?
            </li>
            <li>
              Удалось ли достигнуть поставленных педагогических целей?
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
      </tr>
      <tr>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            Рекомендации
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
      </tr>
      <tr>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            Улучшения
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Информация о проекте на главной странице
            </li>
            <li>
              Основные преимущества на главной странице
            </li>
            <li>
              Прямая ссылка на программы в отдельном блоке на ГС
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Подробная информация по программе
            </li>
            <li>
              Возможность добавить программу в избранное или в закладки
            </li>
            <li>
              Расширенный поиск и простая рекомендательная система
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Пошаговый тур по оформлению заявки со статус баром: програма&gt; данные&gt; подтверждение
            </li>
            <li>
              Возможность задать гибкие даты
            </li>
            <li>
              Возможность положить несколько программ в корзину
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Удобный интерфейс приглашения детей на платформу и в программу
            </li>
            <li>
              Опросы для детей и родителей, какие программы им интересны.
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Методическая информация в аккуанте учителя
            </li>
            <li>
              Возможность задать вопрос организаторам через платформу
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <ol>
            <li>
              Функция рейтинга программы от преподавателя
            </li>
            <li>
              Возможность вести модерируемый блог о проектах школьника
            </li>
          </ol>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
      </tr>
      <tr>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
        <td valign="top" style="width: 12%; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-width: 1; border-right-width: 1; border-bottom-width: 1; border-left-width: 1">
          <p style="margin-top: 1; margin-right: 1; margin-bottom: 1; margin-left: 1">
            
          </p>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Этапы" ID="ID_218950949" CREATED="1603825758195" MODIFIED="1603825803624">
<node TEXT="Знакомство с сайтом" ID="ID_1121678246" CREATED="1603825821185" MODIFIED="1603825832387"/>
<node TEXT="Выбор программы" ID="ID_423573333" CREATED="1603825834293" MODIFIED="1603825838570"/>
<node TEXT="Бронирование программы" ID="ID_801070050" CREATED="1603825839416" MODIFIED="1603825847214"/>
<node TEXT="Перед программой" ID="ID_1050205342" CREATED="1603825847739" MODIFIED="1603825861307"/>
<node TEXT="Во время программы" ID="ID_1069669127" CREATED="1603825863031" MODIFIED="1603825874945"/>
<node TEXT="После программы" ID="ID_707994791" CREATED="1603825888440" MODIFIED="1603825894542"/>
</node>
<node TEXT="Пользовательский опыт" ID="ID_1034500799" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что делает" ID="ID_1345974758" CREATED="1603825943521" MODIFIED="1603825947431"/>
<node TEXT="Что думает и чувствует" ID="ID_907445246" CREATED="1603825947814" MODIFIED="1603825954086"/>
</node>
<node TEXT="Рекомендации" ID="ID_927933370" CREATED="1603825963836" MODIFIED="1603825972847">
<node TEXT="Улучшения" ID="ID_1150460374" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
<node TEXT="Карта CJM макет образец в1" ID="ID_1769733107" CREATED="1603827704423" MODIFIED="1603827897061">
<node TEXT="Этапы" ID="ID_1170469043" CREATED="1603825758195" MODIFIED="1603825803624">
<node TEXT="Знакомство с сайтом" ID="ID_1671008712" CREATED="1603825821185" MODIFIED="1603825832387">
<node TEXT="Пользовательский опыт" ID="ID_1835375150" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что делает" ID="ID_1122308384" CREATED="1603825943521" MODIFIED="1603825947431"/>
<node TEXT="Что думает и чувствует" ID="ID_319485536" CREATED="1603825947814" MODIFIED="1603825954086"/>
</node>
<node TEXT="Рекомендации" ID="ID_750852457" CREATED="1603825963836" MODIFIED="1603825972847">
<node TEXT="Улучшения" ID="ID_922138192" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Выбор программы" ID="ID_865935336" CREATED="1603825834293" MODIFIED="1603825838570">
<node TEXT="Пользовательский опыт" ID="ID_1587745648" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что делает" ID="ID_400087455" CREATED="1603825943521" MODIFIED="1603825947431"/>
<node TEXT="Что думает и чувствует" ID="ID_110039951" CREATED="1603825947814" MODIFIED="1603825954086"/>
</node>
<node TEXT="Рекомендации" ID="ID_118131066" CREATED="1603825963836" MODIFIED="1603825972847">
<node TEXT="Улучшения" ID="ID_1274365221" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Бронирование программы" ID="ID_54334506" CREATED="1603825839416" MODIFIED="1603825847214">
<node TEXT="Пользовательский опыт" ID="ID_1939143184" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что делает" ID="ID_1200967410" CREATED="1603825943521" MODIFIED="1603825947431"/>
<node TEXT="Что думает и чувствует" ID="ID_1831869827" CREATED="1603825947814" MODIFIED="1603825954086"/>
</node>
<node TEXT="Рекомендации" ID="ID_1717913036" CREATED="1603825963836" MODIFIED="1603825972847">
<node TEXT="Улучшения" ID="ID_1157037857" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Перед программой" ID="ID_1160353335" CREATED="1603825847739" MODIFIED="1603825861307">
<node TEXT="Пользовательский опыт" ID="ID_1296165309" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что делает" ID="ID_316632132" CREATED="1603825943521" MODIFIED="1603825947431"/>
<node TEXT="Что думает и чувствует" ID="ID_1163612344" CREATED="1603825947814" MODIFIED="1603825954086"/>
</node>
<node TEXT="Рекомендации" ID="ID_1088164609" CREATED="1603825963836" MODIFIED="1603825972847">
<node TEXT="Улучшения" ID="ID_1467191143" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Во время программы" ID="ID_1887398404" CREATED="1603825863031" MODIFIED="1603825874945">
<node TEXT="Пользовательский опыт" ID="ID_1237834951" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что делает" ID="ID_1915799287" CREATED="1603825943521" MODIFIED="1603825947431"/>
<node TEXT="Что думает и чувствует" ID="ID_1861434833" CREATED="1603825947814" MODIFIED="1603825954086"/>
</node>
<node TEXT="Рекомендации" ID="ID_1027857061" CREATED="1603825963836" MODIFIED="1603825972847">
<node TEXT="Улучшения" ID="ID_891223210" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="После программы" ID="ID_1240516027" CREATED="1603825888440" MODIFIED="1603825894542">
<node TEXT="Пользовательский опыт" ID="ID_443232654" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что делает" ID="ID_791658315" CREATED="1603825943521" MODIFIED="1603825947431"/>
<node TEXT="Что думает и чувствует" ID="ID_1154485492" CREATED="1603825947814" MODIFIED="1603825954086"/>
</node>
<node TEXT="Рекомендации" ID="ID_1306124109" CREATED="1603825963836" MODIFIED="1603825972847">
<node TEXT="Улучшения" ID="ID_223552426" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
</node>
<node TEXT="Пользовательский опыт" ID="ID_1713362370" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что делает" ID="ID_1821236313" CREATED="1603825943521" MODIFIED="1603825947431"/>
<node TEXT="Что думает и чувствует" ID="ID_1893066916" CREATED="1603825947814" MODIFIED="1603825954086"/>
</node>
<node TEXT="Рекомендации" ID="ID_139722518" CREATED="1603825963836" MODIFIED="1603825972847">
<node TEXT="Улучшения" ID="ID_27250973" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
</node>
</node>
<node TEXT="кастомер флоу" ID="ID_51548423" CREATED="1603824434628" MODIFIED="1603824434628">
<node TEXT="Результат" ID="ID_141305983" CREATED="1603825438192" MODIFIED="1603825448392"/>
</node>
<node TEXT="примеры дизайна интерфейса" ID="ID_963243407" CREATED="1603824434629" MODIFIED="1603824434629">
<node TEXT="Результат" ID="ID_440812114" CREATED="1603825438192" MODIFIED="1603825448392"/>
</node>
<node TEXT="к ср или чт" ID="ID_1864897736" CREATED="1603824434629" MODIFIED="1603824434629">
<node TEXT="Результат" ID="ID_665075905" CREATED="1603825438192" MODIFIED="1603825448392"/>
</node>
</node>
<node TEXT="Ярослав" ID="ID_947777307" CREATED="1603824434631" MODIFIED="1604095953300">
<node TEXT="в чт смотрим модели и делает импорт в юнити и облако точек в режимах ар и 3д" ID="ID_328637029" CREATED="1603824434631" MODIFIED="1603824434631">
<node TEXT="Результат" ID="ID_1026619693" CREATED="1603825438192" MODIFIED="1603825448392"/>
</node>
<node TEXT="Желательно прикинуть план работ и список что потребуется" ID="ID_598607902" CREATED="1603824434632" MODIFIED="1603824434632">
<node TEXT="Результат" ID="ID_369573503" CREATED="1603825438192" MODIFIED="1603825448392"/>
</node>
</node>
<node TEXT="Николай" ID="ID_449272055" CREATED="1603824434633" MODIFIED="1603824434633">
<node TEXT="выжимка из собрания" ID="ID_1234798841" CREATED="1603824434636" MODIFIED="1603824434636">
<node TEXT="Результат" ID="ID_1811763232" CREATED="1603825438192" MODIFIED="1603825448392"/>
</node>
<node TEXT="cjm" ID="ID_925108073" CREATED="1603824434637" MODIFIED="1603824434637">
<node TEXT="Результат" ID="ID_61677313" CREATED="1603825438192" MODIFIED="1603825448392"/>
</node>
<node TEXT="детализация карты" ID="ID_1684913149" CREATED="1603824434637" MODIFIED="1603824434637">
<node TEXT="Результат" ID="ID_713371438" CREATED="1603825438192" MODIFIED="1603825448392"/>
</node>
<node TEXT="Факультативно пример станции в 3д в блендер" ID="ID_785033876" CREATED="1603824434638" MODIFIED="1603824434638">
<node TEXT="Результат" ID="ID_840569420" CREATED="1603825438192" MODIFIED="1603825448392"/>
</node>
<node TEXT="CJM overdrive" ID="ID_1218290452" CREATED="1603825264133" MODIFIED="1603825281840">
<node TEXT="3д череда максимального набора событий на пути пассажира" ID="ID_806295808" CREATED="1603825337259" MODIFIED="1603828174354"/>
<node TEXT="2д это порядок с примерением профилировки приоритезации по очреди пукта в зависимости от значимости" ID="ID_1387216925" CREATED="1603825364842" MODIFIED="1603825408208"/>
</node>
</node>
</node>
<node TEXT="Записать экранку работы для тизера проекта, там будет портрет участника и тайм лэпс с экрана" ID="ID_479034355" CREATED="1603964116627" MODIFIED="1604176719007">
<node ID="ID_1285405314" CREATED="1603964208968" MODIFIED="1603964208968" LINK="https://obsproject.com/ru/download"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://obsproject.com/ru/download">https://obsproject.com/ru/download</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1696498931" CREATED="1603964215820" MODIFIED="1603964215820" LINK="https://cdn-fastly.obsproject.com/downloads/OBS-Studio-26.0.2-Full-x64.zip"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://cdn-fastly.obsproject.com/downloads/OBS-Studio-26.0.2-Full-x64.zip" class="grey_btn download-welcome" target="_blank" rel="noopener">Скачать Zip</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Юля" ID="ID_1950527438" CREATED="1603963724089" MODIFIED="1603963726799">
<node TEXT="Предлагается мокап в афтеэффектс - наложить интерфейс меню поверх видео" ID="ID_814563623" CREATED="1603963728609" MODIFIED="1603963765821">
<node TEXT="1920х1080" ID="ID_239475702" CREATED="1603963765821" MODIFIED="1603963772261"/>
<node TEXT="1080х1920" ID="ID_2402219" CREATED="1603963772421" MODIFIED="1603963778461"/>
<node TEXT="два редима видео так как мы не знаем что удобно пользователю и это будет предусмотрительно" ID="ID_1228076599" CREATED="1603963783501" MODIFIED="1603963814282"/>
<node TEXT="Киллер фича - смена ориентации дисплея портрет и альбом, один для руки, второй для phonerig? phone collar" ID="ID_1683435991" CREATED="1603963818852" MODIFIED="1603963936300">
<node TEXT="phone collar разновидность носимого дисплея, заточен под боковое зрения и навигаю на пути" ID="ID_71900793" CREATED="1603963941545" MODIFIED="1603963976658">
<node ID="ID_579669212" CREATED="1603964064673" MODIFIED="1603964064673" LINK="https://translate.yandex.ru/?utm_source=wizard&amp;text=%D0%B2%D0%BE%D1%80%D0%BE%D1%82%20%D1%80%D1%83%D0%B1%D0%B0%D1%88%D0%BA%D0%B8%20%D0%B2%D0%BE%D1%80%D0%BE%D1%82%20%D0%BA%D1%83%D1%80%D1%82%D0%BA%D0%B8〈=ru-en"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://translate.yandex.ru/?utm_source=wizard&amp;text=%D0%B2%D0%BE%D1%80%D0%BE%D1%82%20%D1%80%D1%83%D0%B1%D0%B0%D1%88%D0%BA%D0%B8%20%D0%B2%D0%BE%D1%80%D0%BE%D1%82%20%D0%BA%D1%83%D1%80%D1%82%D0%BA%D0%B8〈=ru-en">https://translate.yandex.ru/?utm_source=wizard&amp;text=%D0%B2%D0%BE%D1%80%D0%BE%D1%82%20%D1%80%D1%83%D0%B1%D0%B0%D1%88%D0%BA%D0%B8%20%D0%B2%D0%BE%D1%80%D0%BE%D1%82%20%D0%BA%D1%83%D1%80%D1%82%D0%BA%D0%B8〈=ru-en</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="грядущий тренд под гибкие дисплеи" ID="ID_329544893" CREATED="1603964672242" MODIFIED="1603964686764"/>
</node>
<node TEXT="phone rig - плечевой риг для камеры или телефона, в случае телефона прдположительно часть рюкзака, а рюкзак применяется как обвес" ID="ID_77849573" CREATED="1603963978023" MODIFIED="1603964048799"/>
</node>
</node>
<node TEXT="Сделать наброски интерфейса в фигме" ID="ID_624370457" CREATED="1603964074956" MODIFIED="1603964094570"/>
<node TEXT="Найти модели для добавления в ар слой" ID="ID_498679223" CREATED="1603964094954" MODIFIED="1603964111294"/>
<node TEXT="Сделать наброски концепции интерфейса" ID="ID_1665083233" CREATED="1603964280665" MODIFIED="1603964292092"/>
</node>
<node TEXT="Дима" ID="ID_34131047" CREATED="1603963264076" MODIFIED="1603963271968">
<node TEXT="моделит в 3д" ID="ID_1250991934" CREATED="1603963271978" MODIFIED="1603963277338"/>
<node TEXT="режим симулирования 3д сцены" ID="ID_783738447" CREATED="1603963405300" MODIFIED="1603963412510"/>
<node TEXT="сборка сцены как в игре от 3-го лица" ID="ID_1562880557" CREATED="1603963277568" MODIFIED="1603963297149"/>
<node TEXT="сборка сцены от 1-го лица" ID="ID_1151506052" CREATED="1603963297779" MODIFIED="1603963309019"/>
<node TEXT="Нужны модели доп персонажей для размещения" ID="ID_1115022470" CREATED="1603963323199" MODIFIED="1603963336319"/>
</node>
<node TEXT="Ярослав" ID="ID_840169459" CREATED="1603963318779" MODIFIED="1603963344529">
<node TEXT="якоря по кюар с демонстрацией 3д, какое 3д?" ID="ID_1694292192" CREATED="1603963344539" MODIFIED="1603963557558">
<node TEXT="модель станции с текущей локацией" ID="ID_942616552" CREATED="1603963379620" MODIFIED="1603963397160">
<node TEXT="сборка сцены как в игре от 3-го лица" ID="ID_174211690" CREATED="1603963277568" MODIFIED="1603963297149"/>
<node TEXT="сборка сцены от 1-го лица" ID="ID_669779565" CREATED="1603963297779" MODIFIED="1603963309019"/>
</node>
<node TEXT="персонал" ID="ID_573630108" CREATED="1603963420790" MODIFIED="1603963425950"/>
<node TEXT="персонаж на кюар" ID="ID_1416812075" CREATED="1603963426210" MODIFIED="1603963438220">
<node TEXT="дракон" ID="ID_3841286" CREATED="1603963467482" MODIFIED="1603963473502"/>
<node TEXT="реверанс вежливого полицейского с указанием дубинкой куда идти (требуется экспертиза допустимости" ID="ID_309245892" CREATED="1603963473682" MODIFIED="1603963536694"/>
</node>
<node TEXT="персонаж с поиском вокруг после линкинга по кюар" ID="ID_1561102403" CREATED="1603963438580" MODIFIED="1603963586725">
<node TEXT="пушкинская - пушкин" ID="ID_605747161" CREATED="1603963457290" MODIFIED="1603963465282"/>
<node TEXT="то есть надо проверить окружение чтобы найти к чему лочен персонаж, но не кюар миниатюра" ID="ID_1845770716" CREATED="1603963592905" MODIFIED="1603963623646"/>
</node>
</node>
<node TEXT="локинг в изиар, по характерным чертам метро" ID="ID_1039665657" CREATED="1603963632256" MODIFIED="1603964810961">
<node TEXT="режим АР" ID="ID_302425991" CREATED="1603964812687" MODIFIED="1603964818672"/>
</node>
<node TEXT="!требуется идти в метро и узнать и договориться о сьёмке видео и ар, возможно клеить на стену нельзя, тогда попросить полицейского кюар подержать, попробовать попросить" ID="ID_1064044331" CREATED="1603963655846" MODIFIED="1603963716749"/>
</node>
</node>
</node>
<node TEXT="ПРОРАБОТКА АНАЛИТИКА АЛГОРИТМЫ" ID="ID_616448355" CREATED="1604130322555" MODIFIED="1604130335732">
<node TEXT="не забыть" ID="ID_1864259763" CREATED="1604130339577" MODIFIED="1604130343480">
<node TEXT="анонс NAVIGINE" ID="ID_1871493659" CREATED="1604130343487" MODIFIED="1604130355409"/>
</node>
<node TEXT="режимы примения (use cycle-estetics)" ID="ID_1821390659" CREATED="1603964770641" MODIFIED="1603969149434">
<node TEXT="телефон в руках без ар" ID="ID_1367454427" CREATED="1603964776465" MODIFIED="1603965591916">
<attribute NAME="Дмитрий" VALUE=""/>
<node TEXT="сборка сцены как в игре от 3-го лица" ID="ID_1872620811" CREATED="1603963277568" MODIFIED="1603963297149">
<node TEXT="сборка сцены обзор 3д карты для формирования внутренноего преставления или обучения пользователя самостоятельно ориентироваться по признакам" ID="ID_1969164801" CREATED="1603963277568" MODIFIED="1603964928973">
<node TEXT="модель станции" ID="ID_1632948537" CREATED="1603964930552" MODIFIED="1603964938863"/>
<node TEXT="элементы случайны" ID="ID_723986393" CREATED="1603964939615" MODIFIED="1603964946439"/>
</node>
<node TEXT="навигация курсором" ID="ID_1370971609" CREATED="1603966153876" MODIFIED="1603966168839"/>
<node TEXT="демо навигации к искомой точке" ID="ID_1487545312" CREATED="1603966169594" MODIFIED="1603966183768"/>
</node>
<node TEXT="сборка сцены от 1-го лица" ID="ID_85813882" CREATED="1603963297779" MODIFIED="1603963309019">
<node TEXT="сборка сцены обзор 3д карты для формирования внутренноего преставления или обучения пользователя самостоятельно ориентироваться по признакам" ID="ID_577120403" CREATED="1603963277568" MODIFIED="1603964928973">
<node TEXT="модель станции" ID="ID_545417505" CREATED="1603964930552" MODIFIED="1603964938863"/>
<node TEXT="элементы случайны" ID="ID_450672138" CREATED="1603964939615" MODIFIED="1603964946439"/>
</node>
<node TEXT="навигация курсором" ID="ID_701788408" CREATED="1603966153876" MODIFIED="1603966168839"/>
<node TEXT="демо навигации к искомой точке" ID="ID_1106811037" CREATED="1603966169594" MODIFIED="1603966183768"/>
</node>
</node>
<node TEXT="телефон в руках с ар" ID="ID_1927402832" CREATED="1603964795170" MODIFIED="1603965603069">
<attribute NAME="Ярослав" VALUE=""/>
<node TEXT="сборка сцены от 1-го лица" ID="ID_1897374666" CREATED="1603963297779" MODIFIED="1603963309019">
<node TEXT="якорь распознавание ярких отличмых элементов станции" ID="ID_185063131" CREATED="1603965667130" MODIFIED="1603966202681"/>
<node TEXT="модель станции" ID="ID_815311474" CREATED="1603964930552" MODIFIED="1603964938863"/>
<node TEXT="элементы случайны" ID="ID_1867416752" CREATED="1603964939615" MODIFIED="1603964946439"/>
<node TEXT="статистическое подтверждение удобства навигационных гипотез" ID="ID_1126378600" CREATED="1603964946860" MODIFIED="1603965702610">
<node TEXT="режим ар тиндер" ID="ID_1635697378" CREATED="1603964970330" MODIFIED="1603964978451"/>
<node TEXT="человек видит видеокадр и по периметру приложение показывает наиболее вероятные релевантные ориентиры" ID="ID_1894401757" CREATED="1603964978990" MODIFIED="1603966236583"/>
<node TEXT="пользователь удерживает обьект, объект начинает увеличиваться и детализироваться" ID="ID_631368100" CREATED="1603965018221" MODIFIED="1603966243665"/>
<node TEXT="пользователь узнаёт или не узнаёт обьект" ID="ID_607749501" CREATED="1603965056059" MODIFIED="1603965071957"/>
<node TEXT="свайпает вправо если да" ID="ID_204703892" CREATED="1603965073054" MODIFIED="1603965083933"/>
<node TEXT="свайпает влево если нет" ID="ID_486993264" CREATED="1603965084484" MODIFIED="1603965091730"/>
<node TEXT="также это режим добавления характерных черт станций удобных пользователю и привлекающих их внимание, и потом ии как датасе скармливаем" ID="ID_1219133279" CREATED="1603966077825" MODIFIED="1603966122301"/>
</node>
</node>
<node TEXT="Сборка сцены от 1-го лица" ID="ID_599556427" CREATED="1603965630285" MODIFIED="1603965648565">
<node TEXT="якорь кюар" ID="ID_417114598" CREATED="1603965648573" MODIFIED="1603965657940"/>
<node TEXT="тут нужен персонаж" ID="ID_474441391" CREATED="1603966278045" MODIFIED="1603966285394"/>
<node TEXT="демонстрация риалтайм" ID="ID_1927625823" CREATED="1603966289444" MODIFIED="1603966295338"/>
<node TEXT="персонаж может служить указателем верного пути" ID="ID_1630318402" CREATED="1603966295604" MODIFIED="1603966308115"/>
</node>
<node TEXT="риалтайм примеры навигации" ID="ID_272103316" CREATED="1603965174495" MODIFIED="1603965188645">
<node TEXT="поиск решения-пути" ID="ID_396298477" CREATED="1603965188649" MODIFIED="1603965724271"/>
<node TEXT="верификация локации" ID="ID_1672683995" CREATED="1603965194737" MODIFIED="1603965199943"/>
<node TEXT="обучение навигации" ID="ID_349312179" CREATED="1603965200973" MODIFIED="1603965209026"/>
</node>
</node>
<node TEXT="далее дополнения" ID="ID_334876153" CREATED="1603965429057" MODIFIED="1603966005768">
<attribute NAME="Николай" VALUE=""/>
</node>
<node TEXT="телефон в кармане, с наушниками" ID="ID_1854076064" CREATED="1603965238167" MODIFIED="1603965266682">
<node TEXT="навигация по акселерометру, посчёт шагов и вектора" ID="ID_1007761280" CREATED="1603965375826" MODIFIED="1603965394576">
<node TEXT="когда давать алгоритм?" ID="ID_42805716" CREATED="1603966341368" MODIFIED="1603966347995"/>
<node TEXT="чередование с онлайн для верификации локации" ID="ID_111709353" CREATED="1603966348380" MODIFIED="1603966369870"/>
</node>
<node TEXT="жесткий онлайн" ID="ID_6714777" CREATED="1603965397388" MODIFIED="1603965405814">
<node TEXT="допустим мы решили по получению точных координат и вектора движения в риалтайм" ID="ID_645022668" CREATED="1603966378879" MODIFIED="1603966404937"/>
<node TEXT="тогда существует гипотеза о том что визуальные помехи и отвлекащие факторы это помеха безопасности движения на перроне у рельс" ID="ID_1885771269" CREATED="1603966405212" MODIFIED="1603966447809"/>
<node TEXT="допустим что экран и телефон в руках пользователя  не допустим, ничего в руках и в поле зрения нереально быть не должно" ID="ID_1778040066" CREATED="1603966450178" MODIFIED="1603966487487"/>
<node TEXT="тогда путь телефон в кармане, а наушники в ушах" ID="ID_258980766" CREATED="1603966487629" MODIFIED="1603967879517"/>
<node TEXT="Так как ничто пассажира не отвлекает то мы можем зная его вектро движения и положение вести аудио подсказками" ID="ID_832392574" CREATED="1603966514821" MODIFIED="1603966560093"/>
<node TEXT="заметим что аудио эфир при таком подходе в поезде может быть синхронизирован с видео на экране в вагоне" ID="ID_1103078054" CREATED="1603966560914" MODIFIED="1603966623159"/>
<node TEXT="также своевременно ставя на пуазу в режиме тайм шифт музыку, аудио книги и новости, обеспечивая максимальный комфорт и плавность движения в потоке людей" ID="ID_415715830" CREATED="1603966623762" MODIFIED="1603966706416"/>
<node TEXT="то же касется и работы на ходу, когдау нужно вести переговоры но и станцию нельзя пропустить" ID="ID_406001074" CREATED="1603966723369" MODIFIED="1603966751408"/>
<node TEXT="таким образом можно предсказать с учетом выше сказанного мобильного оператора на транспорте в виде много функционального воип приложения" ID="ID_1272388130" CREATED="1603966752061" MODIFIED="1603966799846"/>
</node>
<node TEXT="жесткий офлайн" ID="ID_1795453368" CREATED="1603965405959" MODIFIED="1603965411266">
<node TEXT="Особенностью данного режима является ограничения на верификацию фактического местоположения пользователя" ID="ID_1455352689" CREATED="1603966822671" MODIFIED="1603966856295"/>
<node TEXT="Какие есть выходы, если нет сети?" ID="ID_1466796721" CREATED="1603966867223" MODIFIED="1603967891313"/>
<node TEXT="Ответ: встреонная бд с облаком точек и признаков локации, показания датчиков акселеромтров и магнитометров, световые датчики, соседние названия BSSID wifi можем не рассматривать, и, наконец собственные показания пользователя и окружения" ID="ID_870441312" CREATED="1603966879281" MODIFIED="1603966998338"/>
<node TEXT="Что делаем?" ID="ID_1458078089" CREATED="1603966999224" MODIFIED="1603967048538">
<node ID="ID_825979658" CREATED="1603967050065" MODIFIED="1603967050065"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &nbsp;алгоритм аналитики по количеству шагов и направлению движения пользователя
    </p>
  </body>
</html>
</richcontent>
<node TEXT="односторонняя верификаци" ID="ID_892626348" CREATED="1603967436620" MODIFIED="1603967448232"/>
</node>
<node TEXT="алгоритм распознавания устных описаний станции и окружения пользователя с распозаванием в текст и поиск по признакам станции или места" ID="ID_564471049" CREATED="1603967052502" MODIFIED="1603967340730">
<node TEXT="односторонняя верификаци" ID="ID_377481531" CREATED="1603967436620" MODIFIED="1603967448232"/>
<node TEXT=",,,," ID="ID_1574286820" CREATED="1603967524879" MODIFIED="1603967529502"/>
</node>
<node TEXT="алгоритм распозвание эмоций в голосе по ориентирам в станции" ID="ID_12629068" CREATED="1603967114591" MODIFIED="1603967156108">
<node TEXT="односторонняя верификаци" ID="ID_1813884710" CREATED="1603967436620" MODIFIED="1603967448232"/>
</node>
<node TEXT="если компас достоверен то можем определить до половины вариантов выходов со станции в направлении к цели" ID="ID_892651369" CREATED="1603967157463" MODIFIED="1603967207788">
<node TEXT="односторонняя верификаци" ID="ID_3669836" CREATED="1603967436620" MODIFIED="1603967448232"/>
</node>
<node TEXT="алгоритм нахождения локации по рфид меткам" ID="ID_1820257384" CREATED="1603967226712" MODIFIED="1603967366152">
<node TEXT="односторонняя верификаци" ID="ID_993913375" CREATED="1603967436620" MODIFIED="1603967448232"/>
<node TEXT="двусторонняя верификация" ID="ID_1505455615" CREATED="1603967448722" MODIFIED="1603967458806"/>
</node>
<node TEXT="алгоритv нахождения локации по NFC" ID="ID_1086149877" CREATED="1603967247226" MODIFIED="1603967267932">
<node TEXT="просто и быстро" ID="ID_518173979" CREATED="1603967371863" MODIFIED="1603967379900"/>
<node TEXT="двусторонняя верификация" ID="ID_1988540384" CREATED="1603967448722" MODIFIED="1603967458806"/>
</node>
<node TEXT="алгоритм составления карты потоков на основе многомерной векторной диаграммы акселерометра" ID="ID_1202782654" CREATED="1603967268671" MODIFIED="1603967309946">
<node TEXT="односторонняя верификаци" ID="ID_176595794" CREATED="1603967436620" MODIFIED="1603967448232"/>
</node>
<node TEXT="алгоритм заимствования координат у соседа" ID="ID_1822431219" CREATED="1603967322396" MODIFIED="1603967394368">
<node TEXT="односторонняя верификаци" ID="ID_871796961" CREATED="1603967436620" MODIFIED="1603967448232"/>
<node TEXT="двусторонняя верификация" ID="ID_1647143768" CREATED="1603967448722" MODIFIED="1603967458806"/>
</node>
<node TEXT="алгоритм аудио навигация" ID="ID_258205968" CREATED="1603967901277" MODIFIED="1603967932365">
<node TEXT="своя птичка на каждую станцию))" ID="ID_513210334" CREATED="1603967911934" MODIFIED="1603967922245"/>
</node>
<node TEXT="алгоритм навигации по частотно световым сигналам" ID="ID_1905728747" CREATED="1603967932875" MODIFIED="1603967958329">
<node TEXT="односторонняя верификаци" ID="ID_907193837" CREATED="1603967436620" MODIFIED="1603967448232"/>
<node TEXT="двусторонняя верификация" ID="ID_1587790917" CREATED="1603967448722" MODIFIED="1603967458806"/>
</node>
<node TEXT="алгоритм магнитная навигация на станции" ID="ID_1703945158" CREATED="1603967983373" MODIFIED="1603968000312">
<node TEXT="точки с обозначением компаса + цвет маркера" ID="ID_1038702181" CREATED="1603968000318" MODIFIED="1603968020590"/>
<node TEXT="насильное изменение поля" ID="ID_627582666" CREATED="1603968029535" MODIFIED="1603968037598"/>
<node TEXT="матрица магнитных навигаторов под перроном" ID="ID_1049461961" CREATED="1603968052522" MODIFIED="1603968068390"/>
</node>
<node TEXT="навигация внимания пассажира" ID="ID_1557530236" CREATED="1603968121735" MODIFIED="1603968130720">
<node TEXT="акселерометры в наушниках" ID="ID_1619738283" CREATED="1603968130725" MODIFIED="1603968145512"/>
</node>
<node TEXT="1" OBJECT="java.lang.Long|1" ID="ID_1527400431" CREATED="1603968074692" MODIFIED="1603968104405"/>
<node TEXT="" ID="ID_885260303" CREATED="1603967625693" MODIFIED="1603967625693"/>
<node TEXT="отвлекся и не только в кармане, а если вообще оффлайн" ID="ID_1431184922" CREATED="1603967753311" MODIFIED="1603967837184"/>
<node TEXT="прибегаем к внешней верификации локации по кюар" ID="ID_360619885" CREATED="1603967208549" MODIFIED="1603967226402">
<node TEXT="односторонняя верификаци" ID="ID_1454977072" CREATED="1603967436620" MODIFIED="1603967448232"/>
<node TEXT="двусторонняя верификация" ID="ID_1541121250" CREATED="1603967448722" MODIFIED="1603967458806"/>
</node>
<node TEXT="Алгоритм размещения и создания стандарта сигнальных визуальных точек(ЧП буквенночисловые желательно)" ID="ID_865859934" CREATED="1603967395049" MODIFIED="1603967683523">
<node TEXT="динамические безопаснее?" ID="ID_788924436" CREATED="1603967602206" MODIFIED="1603967616693">
<node TEXT="" ID="ID_503087806" CREATED="1603967619466" MODIFIED="1603967619466"/>
<node TEXT="двусторонняя верификация" ID="ID_1336913163" CREATED="1603967448722" MODIFIED="1603967458806"/>
</node>
<node TEXT="алибаба и сорок разбойников..." ID="ID_283251681" CREATED="1603967629518" MODIFIED="1603967637234"/>
<node TEXT="просто статичесие" ID="ID_578925961" CREATED="1603967706329" MODIFIED="1603967718840"/>
<node TEXT="динамические на жисплеях метро, ещё и фокусом внимания будет для камер мобил" ID="ID_410511416" CREATED="1603967720743" MODIFIED="1603967749980"/>
</node>
</node>
</node>
<node TEXT="режим аудио гида" ID="ID_304000057" CREATED="1603965419786" MODIFIED="1603965426307">
<node TEXT="движение по маршруту" ID="ID_1652473463" CREATED="1603968117102" MODIFIED="1603968158741"/>
<node TEXT="но особенно это хоршо при движении в поезде в ар слоем, когда пользователь видит что над ним в 360 перемещая телефон, например пробки наверху или акции в магазинах над ним, такой городской рентген" ID="ID_791571485" CREATED="1603968158999" MODIFIED="1603968241707"/>
</node>
<node TEXT="без ар без 3д, только внутренняя обработка" ID="ID_654861941" CREATED="1603969201158" MODIFIED="1603969222561"/>
</node>
<node TEXT="телефон в кармане, плюс гаджет палка bluetooth с гироскопом указателем для слепых" ID="ID_739059678" CREATED="1603965267363" MODIFIED="1603965934333">
<node TEXT="по сути гироскоп вращаясь вправо или влево создаёт угловой вектор по пути отклоняя палку и клиент это чувствует" ID="ID_1544026523" CREATED="1603965770431" MODIFIED="1603965820089"/>
<node TEXT="также можно встроить рфид считыватель в палку и подпол" ID="ID_1064741286" CREATED="1603965820446" MODIFIED="1603965845200"/>
<node TEXT="рфид может быть и у обычного человека в ботинке" ID="ID_1536188394" CREATED="1603965846051" MODIFIED="1603965870765"/>
<node TEXT="можно разместить камеру в палку и с нейронкой распозанвать текстуры пола и кюар кода" ID="ID_496814845" CREATED="1603965886004" MODIFIED="1603965917546"/>
<node TEXT="обеспечение малоподвижных групп" ID="ID_1751069556" CREATED="1603969228540" MODIFIED="1603969239409"/>
</node>
<node TEXT="телефон на держателе у коляски, режим навигатора" ID="ID_1740259354" CREATED="1603965300326" MODIFIED="1603965321814">
<node TEXT="поиск возмозможных маршрутов для колесного транспорта" ID="ID_50672176" CREATED="1603965321818" MODIFIED="1603965347943"/>
<node TEXT="инвалид" ID="ID_842037611" CREATED="1603965351529" MODIFIED="1603965355013"/>
<node TEXT="мама с коляской" ID="ID_541374739" CREATED="1603965355173" MODIFIED="1603965359539"/>
<node TEXT="обеспечение малоподвижных групп" ID="ID_338273792" CREATED="1603969255394" MODIFIED="1603969258471"/>
</node>
<node TEXT="телефон на phonerig" ID="ID_382199621" CREATED="1603965748656" MODIFIED="1603965762027"/>
<node TEXT="наушники в ушах и телефон в руках, пассажир сидит или стоит в вагоне" ID="ID_1476845941" CREATED="1603968260940" MODIFIED="1603968293761">
<node TEXT="Кадр: человек едет в поезде, сидит, в руках телефон. Он наводит на потолок и видит стокман над ним, он нажимает аудио и запускается ролик" ID="ID_1239679844" CREATED="1603968298831" MODIFIED="1603968369690"/>
<node TEXT="Город под рентгеном при движении под землей позволяет навести на здание и увидеть акции и предложения в нём на текущий день, забронировать билет, получить купон на посещение" ID="ID_1609272577" CREATED="1603968369874" MODIFIED="1603968451485"/>
<node TEXT="самое интересное что в режим простоя и движения на транспорте можно в режиме ренген интегрировать все бд из треков хакатона" ID="ID_553771854" CREATED="1603968654967" MODIFIED="1603968709130">
<node TEXT="карта собачек" ID="ID_1979761953" CREATED="1603968714872" MODIFIED="1603968724495"/>
<node TEXT="карта городского благоустройства" ID="ID_176916044" CREATED="1603968725660" MODIFIED="1603968733325"/>
<node TEXT="симуляция строительства" ID="ID_1722508655" CREATED="1603968733747" MODIFIED="1603968742756"/>
<node TEXT="тут ведь и ты вроде в пробке и делать нечего и информация к тебе на самом деле ближе, то есть веротяность попадания на локацию и соответсвенно реальный интерес из симуляции в ар близки" ID="ID_577969061" CREATED="1603968743555" MODIFIED="1603968814879"/>
</node>
<node TEXT="" ID="ID_1287585610" CREATED="1603968710442" MODIFIED="1603968710442"/>
</node>
</node>
<node TEXT="Формула полного CJM-full=JCM-extended(путь пользовательского опыта) X(помножить) use cycle-estetics(режимы применения)" ID="ID_206878760" CREATED="1603969031710" MODIFIED="1603969186299"/>
<node TEXT="Карта CJM макет в2" ID="ID_1417004106" CREATED="1603827704423" MODIFIED="1603828031564">
<node TEXT="Этапы" ID="ID_765867590" CREATED="1603825758195" MODIFIED="1603997889338">
<icon BUILTIN="button_ok"/>
<node TEXT="Заголовок: Этап" ID="ID_611240188" CREATED="1603828501335" MODIFIED="1603828517750">
<node TEXT="Подзаголовок" ID="ID_1051575875" CREATED="1603828517771" MODIFIED="1603828539758">
<node TEXT="Подподзаголовок" ID="ID_1005307995" CREATED="1603828539766" MODIFIED="1603828589349">
<node TEXT="Подподподзаголовок" ID="ID_911680135" CREATED="1603828539766" MODIFIED="1603828586517">
<node TEXT="...." ID="ID_223394483" CREATED="1603828857030" MODIFIED="1603828862592"/>
</node>
</node>
</node>
</node>
<node TEXT="Этап частный" LOCALIZED_STYLE_REF="styles.important" ID="ID_1341503544" CREATED="1603828818508" MODIFIED="1603828884565">
<node TEXT="Пользовательский опыт" ID="ID_637457388" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1698845599" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_182427075" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_780469115" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1272708252" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_540910510" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_491108694" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1082474900" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1773402680" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1907512263" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Выбор приложения в1 поиск" ID="ID_1696488812" CREATED="1603828130432" MODIFIED="1603829119086">
<node TEXT="Пользовательский опыт" ID="ID_947006004" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_523473678" CREATED="1603825947814" MODIFIED="1603830082638">
<icon BUILTIN="forward"/>
<node TEXT="Рекомендации общие" ID="ID_904177977" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1695638763" CREATED="1603825972856" MODIFIED="1603829444510"/>
<node TEXT="Предоставить публичный короткий линк на приложение" ID="ID_300704678" CREATED="1603829582315" MODIFIED="1603829608173"/>
<node TEXT="Сделать веб конфигуратор маршрута с переходом в приложение и сохранением введенной информации" ID="ID_592289168" CREATED="1603829665783" MODIFIED="1603829700349"/>
<node TEXT="Сделать веб приложение" ID="ID_1851884400" CREATED="1603829725280" MODIFIED="1603829738630"/>
</node>
<node TEXT="Как быстрее начать смотреть маршрут" ID="ID_1616314611" CREATED="1603829188426" MODIFIED="1603829244255"/>
</node>
<node TEXT="Что делает частное" ID="ID_37083345" CREATED="1603825943521" MODIFIED="1603830088244">
<icon BUILTIN="down"/>
<node TEXT="Что думает и чувствует частное" ID="ID_380843643" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1810461198" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_206094646" CREATED="1603825972856" MODIFIED="1603829387604"/>
</node>
</node>
</node>
<node TEXT="Выбирает магазин приложений" ID="ID_171012968" CREATED="1603828999618" MODIFIED="1603829020270">
<node TEXT="Какой магазин приложений?" ID="ID_1905823796" CREATED="1603829282594" MODIFIED="1603829377151">
<node TEXT="Присутствие в ИОС и андроид и веб версия" ID="ID_991817383" CREATED="1603829312343" MODIFIED="1603829329037"/>
</node>
</node>
<node TEXT="Вводит ключевое слово" ID="ID_1871617166" CREATED="1603829020994" MODIFIED="1603829051664">
<node TEXT="Какое слово характериет этот тип приложений?" ID="ID_223072951" CREATED="1603829292738" MODIFIED="1603829371412">
<node TEXT="Проработать семантическое ядро слов и классифицировать приложения навигаторы" ID="ID_1670017141" CREATED="1603829811622" MODIFIED="1603829838423"/>
<node TEXT="Надо посмотеть на рельтат проработки для дальнейших рекомендаций" ID="ID_1176794741" CREATED="1603829847303" MODIFIED="1603829867735"/>
</node>
</node>
<node TEXT="Смотрит на рейтинг приложений" ID="ID_981969097" CREATED="1603829054115" MODIFIED="1603829889270"/>
<node TEXT="Выбирает бесплатное" ID="ID_1541444537" CREATED="1603829890360" MODIFIED="1603829896548"/>
<node TEXT="Выбирает с функциоей оплаты билетов" ID="ID_1505714481" CREATED="1603829896811" MODIFIED="1603829908406"/>
<node TEXT="Выбирает самое легкое приложение по весу установщика" ID="ID_1353562835" CREATED="1603829911544" MODIFIED="1603829930192"/>
</node>
<node TEXT="Рекомендации общие" ID="ID_1076070597" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1119408156" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Установка приложения" ID="ID_84546015" CREATED="1603828114813" MODIFIED="1603828127071">
<node TEXT="Пользовательский опыт" ID="ID_1647833093" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_909989353" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_718299751" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_377392259" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_365385430" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1569094742" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1227425009" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_908006357" CREATED="1603825972856" MODIFIED="1603834011604"/>
</node>
</node>
</node>
<node TEXT="Нажимает скачать" ID="ID_79937118" CREATED="1603830124698" MODIFIED="1603830144611"/>
<node TEXT="Нажимает открыть" ID="ID_194416920" CREATED="1603830136320" MODIFIED="1603830140967"/>
</node>
<node TEXT="Рекомендации общие" ID="ID_1522988780" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_783883833" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Регистрация в приложении" ID="ID_59558504" CREATED="1603830217718" MODIFIED="1603830230047">
<node TEXT="Пользовательский опыт" ID="ID_1135300819" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_941651137" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_961311650" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_446299820" CREATED="1603825972856" MODIFIED="1603829444510"/>
<node TEXT="Сделать регистрацию по номеру телефона" ID="ID_596044762" CREATED="1603830284109" MODIFIED="1603830381140"/>
<node TEXT="Сделать регистрацию по USSD запросу с телефона, без ввода номера, если например не помнит, чтобы достаточно приложение открыть и нажать запрос USSD,  а там сразу смс о балансе и ответка кода по регистрации" ID="ID_1197858807" CREATED="1603830292687" MODIFIED="1603830446478"/>
<node TEXT="Сделать сервис при наборе которого он сообщает текущий номер в аудио словесном или распознаваемом модемном звуке" ID="ID_304621954" CREATED="1603830464703" MODIFIED="1603830517283"/>
</node>
<node TEXT="Не помнит какой у него номер" ID="ID_1172302563" CREATED="1603830607289" MODIFIED="1603830625300"/>
</node>
<node TEXT="Что делает частное" ID="ID_998528116" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1295912130" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_601786418" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_164734639" CREATED="1603825972856" MODIFIED="1603834013096"/>
</node>
</node>
</node>
<node TEXT="Видит экран приветствия: Войти и регистрация" ID="ID_992714789" CREATED="1603830732618" MODIFIED="1603830774481">
<node TEXT="Я первый раз м не только маршрут посмотреть" ID="ID_1191849744" CREATED="1603830792279" MODIFIED="1603830868958">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1712259898" STARTINCLINATION="631;0;" ENDINCLINATION="631;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Я второй раз мне посмотреть маршрут и оплатить проезд" ID="ID_1382659585" CREATED="1603830810710" MODIFIED="1603830879452">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1261737456" STARTINCLINATION="579;0;" ENDINCLINATION="579;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
</node>
<node TEXT="Вводит номер телефона" ID="ID_863134983" CREATED="1603830176845" MODIFIED="1603830190130"/>
<node TEXT="Получает смс с кодом" ID="ID_70466638" CREATED="1603830275446" MODIFIED="1603830551222"/>
<node TEXT="Приложение запрашавает доступ к смс и сканирует подтверждение запроса" ID="ID_1100809191" CREATED="1603830551592" MODIFIED="1603830589926"/>
</node>
<node TEXT="Рекомендации общие" ID="ID_278906888" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_848710964" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Добавление карты оплаты или платёжного средства" ID="ID_1261737456" CREATED="1603830687676" MODIFIED="1603831075990">
<node TEXT="Пользовательский опыт" ID="ID_1383545050" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_861981660" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_557362759" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_774540593" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1663073174" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_265246994" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1169323959" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_220339640" CREATED="1603825972856" MODIFIED="1603834021881"/>
</node>
</node>
</node>
<node TEXT="Вводит номер карты на экране" ID="ID_1052518565" CREATED="1603830176845" MODIFIED="1603830918046">
<node TEXT="мне просто с карты оплатить" ID="ID_1406747050" CREATED="1603830970909" MODIFIED="1603830978720"/>
</node>
<node TEXT="Открывает сканирование через камеру" ID="ID_1891158310" CREATED="1603830919034" MODIFIED="1603830937651">
<node TEXT="боюсь ошибиться или полохо вижу, машина точнее меня работает" ID="ID_1616240674" CREATED="1603830982253" MODIFIED="1603831007721"/>
</node>
<node TEXT="Сканирует карту" ID="ID_653070605" CREATED="1603830938295" MODIFIED="1603830942946">
<node TEXT="боюсь ошибиться или полохо вижу, машина точнее меня работает" ID="ID_1627630335" CREATED="1603830982253" MODIFIED="1603831007721"/>
</node>
<node TEXT="Сканирует Кьюар код на скидку на проезд" ID="ID_595194792" CREATED="1603830943343" MODIFIED="1603830962986">
<node TEXT="я не робот чтобы читать уникальный скидочный код на проезд или кофе" ID="ID_852285079" CREATED="1603830982253" MODIFIED="1603831050236"/>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_134343810" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_955800024" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Знакомство с приложением" ID="ID_1712259898" CREATED="1603825821185" MODIFIED="1603828058807">
<node TEXT="Пользовательский опыт" ID="ID_209821513" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_396465746" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_504298674" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1919499998" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1826107760" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1343837692" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1903764504" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1452828542" CREATED="1603825972856" MODIFIED="1603834024302"/>
</node>
</node>
</node>
<node TEXT="Ищет ввод маршрута" ID="ID_1965313466" CREATED="1603831119185" MODIFIED="1603831155113">
<node TEXT="я новичок, сейчас важно доехать до места и оплатить проезд" ID="ID_927676830" CREATED="1603831171764" MODIFIED="1603831189890"/>
</node>
<node TEXT="Вводит от станции до станции" ID="ID_1896651488" CREATED="1603831197330" MODIFIED="1603831629006">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1408200328" STARTINCLINATION="378;0;" ENDINCLINATION="378;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Вводит от адреса до адреса" ID="ID_1438176784" CREATED="1603831596951" MODIFIED="1603832137717">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1654535441" STARTINCLINATION="395;0;" ENDINCLINATION="395;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_170381019" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_163199669" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Выбор маршрута от метро до метро аналитический режим" ID="ID_1408200328" CREATED="1603825834293" MODIFIED="1603832087779">
<node TEXT="Пользовательский опыт" ID="ID_70783351" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_21892459" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1217942969" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1984721030" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1355482868" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_59912732" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_304977343" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_192176072" CREATED="1603825972856" MODIFIED="1603834007175"/>
</node>
</node>
</node>
<node TEXT="Видит общую карту метро и варианты маршрутов" ID="ID_679627565" CREATED="1603831679048" MODIFIED="1603831702227"/>
<node TEXT="Видит снизу состав вариантов маршрутов: переходы, пешком сколько метров, эскалаторы, количество остановок, ремонты в метро, количество кафешек" ID="ID_1166477651" CREATED="1603831703248" MODIFIED="1603831795658"/>
<node TEXT="Видит маршрут цветными секторами с процентами" ID="ID_687288356" CREATED="1603831828123" MODIFIED="1603831858858"/>
<node TEXT="Видит стрелочку детализации, при нажатии которой видно что сколько занимает по процентам и по времени" ID="ID_1244295998" CREATED="1603831860406" MODIFIED="1603831891146"/>
<node TEXT="Также возможно активировать видимость оплаты за сектора на маршруте, это нужно например для адаптации в лондоне" ID="ID_50314593" CREATED="1603831909674" MODIFIED="1603831964992"/>
</node>
<node TEXT="Рекомендации общие" ID="ID_368565490" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_248748014" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Выбор маршрута от метро до метро реал тайм навигационный режим" ID="ID_414179587" CREATED="1603825834293" MODIFIED="1603832120325">
<node TEXT="Пользовательский опыт" ID="ID_882317645" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1821807504" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_289102732" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_59835716" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1625672814" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1607741229" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1640143379" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1941998578" CREATED="1603825972856" MODIFIED="1603834003334"/>
</node>
</node>
</node>
<node TEXT="Видит общую карту метро и ближайшую станцию метро" ID="ID_829114500" CREATED="1603831679048" MODIFIED="1603832137907"/>
<node TEXT="Видит конпку начать ар маршрут" ID="ID_1675087340" CREATED="1603831909674" MODIFIED="1603832289791"/>
<node TEXT="Стрелка на карте указывает маршрут до метро пешком или на автобусе или электричке или велосипеде" ID="ID_1876283657" CREATED="1603832294045" MODIFIED="1603832357460"/>
</node>
<node TEXT="Рекомендации общие" ID="ID_928497862" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_472277008" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Выбор маршрута от адреса до адреса" ID="ID_1654535441" CREATED="1603828080822" MODIFIED="1603828095422">
<node TEXT="Пользовательский опыт" ID="ID_1978466150" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1912809564" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_776584217" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1000444166" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1328819169" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1540697216" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_176143246" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_735282328" CREATED="1603825972856" MODIFIED="1603833999054"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1230206969" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_218515547" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Перед маршрутом" ID="ID_748713208" CREATED="1603825847739" MODIFIED="1603833572126">
<node TEXT="Пользовательский опыт" ID="ID_1387772874" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_500970457" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1223757855" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_193435492" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_7813461" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_580846337" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1118283722" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_337222853" CREATED="1603825972856" MODIFIED="1603833997101"/>
</node>
</node>
</node>
<node TEXT="Сравнивает маршруты" ID="ID_1072980879" CREATED="1603833812784" MODIFIED="1603833818887"/>
</node>
<node TEXT="Рекомендации общие" ID="ID_1759437258" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1666227836" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Бронирование маршрута и движение по маршруту" ID="ID_1512923275" CREATED="1603825839416" MODIFIED="1603832394031">
<node TEXT="Пользовательский опыт" ID="ID_1385920979" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_709705233" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_154958606" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1084495797" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_197757770" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1175706812" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_432481582" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1010983036" CREATED="1603825972856" MODIFIED="1603833993271"/>
</node>
</node>
</node>
<node TEXT="Смотрит продолжение маршрута на вокзале" ID="ID_1044116003" CREATED="1603833823151" MODIFIED="1603833841625"/>
</node>
<node TEXT="Рекомендации общие" ID="ID_1384063462" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1069476136" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Во время программы" ID="ID_1985208921" CREATED="1603825863031" MODIFIED="1603825874945">
<node TEXT="Пользовательский опыт" ID="ID_979970722" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_84542471" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_209254628" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_755745258" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_606048111" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1004315981" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_531967259" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1608040654" CREATED="1603825972856" MODIFIED="1603833989458"/>
</node>
</node>
</node>
<node TEXT="Слушает музыку или радио" ID="ID_1891065463" CREATED="1603833850428" MODIFIED="1603833865582"/>
</node>
<node TEXT="Рекомендации общие" ID="ID_1738704478" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_981760890" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Маршрут до метро" ID="ID_1462116401" CREATED="1603832395543" MODIFIED="1603832410083">
<node TEXT="Пользовательский опыт" ID="ID_1704310498" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1642873648" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_884378836" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_893081879" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1070748466" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1773903550" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_424865485" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1440979440" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_967634982" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1229700367" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Машрут до метро с детуром за кофе" ID="ID_762303888" CREATED="1603832410577" MODIFIED="1603832426275">
<node TEXT="Пользовательский опыт" ID="ID_1301760279" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1852501514" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1007423008" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1940319364" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_255041616" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_873241673" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1166652525" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_890376635" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1420575874" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_579186513" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Поиск помойки" ID="ID_406267697" CREATED="1603832427914" MODIFIED="1603832438465">
<node TEXT="Пользовательский опыт" ID="ID_748099122" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1138853962" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1777480806" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_983015133" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1885898003" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_875790958" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_827041873" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1409146326" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_255120649" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_854638424" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Поиск туалета у метро или в метро" ID="ID_1536955266" CREATED="1603832438650" MODIFIED="1603832461439">
<node TEXT="Пользовательский опыт" ID="ID_239957492" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1196226175" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1062494116" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1886377599" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1307464852" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_92898750" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1258913718" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1037530396" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_526012355" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1530277724" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Навигация до вестибюля с улицы" ID="ID_1377716575" CREATED="1603832465709" MODIFIED="1603832525791">
<node TEXT="Пользовательский опыт" ID="ID_662204839" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_145189175" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_315615514" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1857912539" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1429211138" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_152485020" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1405005791" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_947074775" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1348633649" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_880220176" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Навигация по подземным переходам до метро" ID="ID_1187256409" CREATED="1603832719710" MODIFIED="1603832732948">
<node TEXT="Пользовательский опыт" ID="ID_1984915792" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_704115848" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1393623259" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_37087134" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1998205839" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1306282340" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1943857111" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1233269263" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_325823785" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_500206817" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Вход в вестибюль" ID="ID_443329273" CREATED="1603832526550" MODIFIED="1603832534986">
<node TEXT="Пользовательский опыт" ID="ID_1773178315" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_165361015" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1094765380" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_906020952" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1881648486" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1874524908" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1890691173" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1938833157" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1546787894" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_290534226" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Кассы метро" ID="ID_945181030" CREATED="1603832548735" MODIFIED="1603832574318">
<node TEXT="Пользовательский опыт" ID="ID_547238955" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1198961446" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1626722130" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_796154316" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_32878932" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1361183896" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1757406313" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_806724571" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1000615606" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_61610523" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Куда идти после входа" ID="ID_1424927233" CREATED="1603832650467" MODIFIED="1603832670860">
<node TEXT="Пользовательский опыт" ID="ID_870015602" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1716461490" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_173675465" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1707782729" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_609911473" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1298040182" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_309601088" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1578289601" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_552991803" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1868834066" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Проход турникетов" ID="ID_1930570651" CREATED="1603832535306" MODIFIED="1603832546930">
<node TEXT="Пользовательский опыт" ID="ID_1281323001" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1803436998" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_763851980" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_970948553" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1822051509" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_792652074" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_812429112" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1690854325" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_30954677" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_416992552" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Спуск по лестнице" ID="ID_1654970242" CREATED="1603832578637" MODIFIED="1603832599536">
<node TEXT="Пользовательский опыт" ID="ID_913885038" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1327614110" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_59579690" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_233451476" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1233362470" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1118796851" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_510437525" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_367263613" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_353565587" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1420101435" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Спуск по эскалатору" ID="ID_687129262" CREATED="1603832599708" MODIFIED="1603832618198">
<node TEXT="Пользовательский опыт" ID="ID_652601613" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1905118763" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_124838852" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1525183460" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1951849775" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1440636231" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_585930396" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_825354040" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_74797474" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_884080986" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Конец экалатора" ID="ID_814051655" CREATED="1603832606043" MODIFIED="1603832748040">
<node TEXT="Пользовательский опыт" ID="ID_924931436" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1739464621" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_516813125" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1428307950" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1205406427" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_611053048" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_633743760" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_708279377" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1025950792" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1130698580" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Платформа метро" ID="ID_289837371" CREATED="1603832748223" MODIFIED="1603832756314">
<node TEXT="Пользовательский опыт" ID="ID_1759801183" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1261664808" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1611491391" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_217609920" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1486847616" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_464912449" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1103335758" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_503994349" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_192485681" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_252096148" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Ориентирование налево или направо" ID="ID_721556611" CREATED="1603832760068" MODIFIED="1603832779557">
<node TEXT="Пользовательский опыт" ID="ID_1470678616" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1744552288" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_238318449" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1458313147" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_493623677" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1252657197" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1265942315" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1544743027" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_448186572" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1445168734" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Ориентирование по внутренним переходам" ID="ID_67491247" CREATED="1603832779779" MODIFIED="1603832791392">
<node TEXT="Пользовательский опыт" ID="ID_1675097586" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_832566229" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1474130917" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1436385953" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_791226268" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_545136917" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1757504784" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1665344892" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_188136509" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_80414123" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Путь к поезду, ориентирование первый и последний вагон в связке со следующим выходом из вагона" ID="ID_1275573813" CREATED="1603832791519" MODIFIED="1603832822167">
<node TEXT="Пользовательский опыт" ID="ID_260394970" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_9650617" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_330467960" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1495452281" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1695381458" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1565857555" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_633253454" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_169056382" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_474748864" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_569323133" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="у края перрона" ID="ID_258478549" CREATED="1603833656388" MODIFIED="1603833664734">
<node ID="ID_1629435138" CREATED="1603833687472" MODIFIED="1603833687472" LINK="https://yandex.ru/search/?clid=2186620&amp;text=%D0%BF%D0%B5%D1%80%D1%80%D0%BE%D0%BD&amp;lr=20728&amp;redircnt=1603833672.1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://yandex.ru/search/?clid=2186620&amp;text=%D0%BF%D0%B5%D1%80%D1%80%D0%BE%D0%BD&amp;lr=20728&amp;redircnt=1603833672.1">https://yandex.ru/search/?clid=2186620&amp;text=%D0%BF%D0%B5%D1%80%D1%80%D0%BE%D0%BD&amp;lr=20728&amp;redircnt=1603833672.1</a>
  </body>
</html>
</richcontent>
<node ID="ID_1548383883" CREATED="1603833695056" MODIFIED="1603833695056" LINK="https://ru.wikipedia.org/wiki/%D0%9F%D0%B5%D1%80%D1%80%D0%BE%D0%BD"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_502475761" CREATED="1603833695058" MODIFIED="1603833695058"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="fact__description typo typo_text_l typo_line_m">
      <b>Перро́н</b>&nbsp;(фр. <b>perron</b>&nbsp;«крыльцо»): Железнодорожный <b>перрон</b>&nbsp;&nbsp;— укреплённая платформа, проходящая параллельно железнодорожным путям, предназначенная для посадки и высадки пассажиров поездов и погрузочно-разгрузочных работ.
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Пользовательский опыт" ID="ID_1359728796" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1329056245" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1570992395" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1337795771" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_988132992" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_402056126" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1531282305" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_864296548" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_155702770" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1325863031" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Ожидание поезда" ID="ID_14011940" CREATED="1603833953598" MODIFIED="1603833962623">
<node TEXT="Пользовательский опыт" ID="ID_897416349" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_417245342" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_762113892" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_222702559" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1502959544" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1728914845" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1078743397" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_129041451" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1093756452" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_113250578" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="вход в вагон" ID="ID_1558963456" CREATED="1603832823418" MODIFIED="1603832833684">
<node TEXT="Пользовательский опыт" ID="ID_754057463" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1338293793" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1616757931" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1975929637" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1134988466" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1917752599" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_23701521" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_746951889" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_546252700" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1390931784" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="место в вагоне" ID="ID_745920150" CREATED="1603832833941" MODIFIED="1603832838253">
<node TEXT="Пользовательский опыт" ID="ID_1643866194" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_435670738" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_731285603" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1341681511" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1852540590" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1123779391" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_492110498" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1818452121" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1756693934" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_504868409" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="реклама в вагоне" ID="ID_1559025931" CREATED="1603832838394" MODIFIED="1603832846424">
<node TEXT="Пользовательский опыт" ID="ID_608352092" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_827533771" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_951083636" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_741315026" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1097141156" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1442995375" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_446402862" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_172990105" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_11642719" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1234991700" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="вагонные подземные ар экскурсии" ID="ID_1710911810" CREATED="1603832846560" MODIFIED="1603832868097">
<node TEXT="Пользовательский опыт" ID="ID_241700516" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1212947140" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1803771426" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_613951328" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_394737905" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1250611704" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_430015541" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_420358637" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1258176847" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1029420983" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="перемещение по вагону для поиска места или оптимизации точки выхода" ID="ID_1738826567" CREATED="1603832873835" MODIFIED="1603832900205">
<node TEXT="Пользовательский опыт" ID="ID_362828217" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_673983230" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1401825547" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1381566054" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_602478053" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_999806365" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_114383767" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_44244076" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_201756050" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_561485758" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="проверка маршрута перед выходом из вагона" ID="ID_1253245351" CREATED="1603832940137" MODIFIED="1603832949482">
<node TEXT="Пользовательский опыт" ID="ID_938229055" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_270681851" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_471308225" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1432484338" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1802079429" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_864976094" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_457322017" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_90970561" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1883714242" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1980143957" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="толчия при выходе из вагона" ID="ID_1933098924" CREATED="1603832962329" MODIFIED="1603832976535">
<node TEXT="Пользовательский опыт" ID="ID_1833716838" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1485822585" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_574123157" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_506005992" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1329872508" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1812642698" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_779892430" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_546878946" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1844304440" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_675285409" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="выход из вагона" ID="ID_649785608" CREATED="1603832900844" MODIFIED="1603832911082">
<node TEXT="Пользовательский опыт" ID="ID_653685833" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1013471082" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1020635362" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1620903726" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_942487827" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_425297527" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1720137406" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_616903860" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_561624321" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1604966825" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="продолжение маршрута по перрону" ID="ID_231223098" CREATED="1603832911830" MODIFIED="1603833028608">
<node TEXT="Пользовательский опыт" ID="ID_23535474" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1748257036" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_152262826" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1106147516" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_611060446" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1502132049" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1837445756" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_734558908" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1985359562" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_498068854" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="поиск перехода на другую линию" ID="ID_1845506624" CREATED="1603833028868" MODIFIED="1603833038801">
<node TEXT="Пользовательский опыт" ID="ID_1120270861" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1706915087" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1640609369" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_692675092" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_828554849" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_294641809" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_325165318" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1779958462" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_227071494" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_234856017" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="ориентирование из нескольких линий (например киевская, или билиотека им ленина)" ID="ID_764302205" CREATED="1603833039143" MODIFIED="1603833081217">
<node TEXT="Пользовательский опыт" ID="ID_1612561106" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1032616253" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_519481391" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1559557028" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1623202793" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_889144054" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1762766192" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_285078869" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1822079220" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1058118760" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="движение по переходу" ID="ID_1019742654" CREATED="1603833082142" MODIFIED="1603833101625">
<node TEXT="Пользовательский опыт" ID="ID_882475541" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1208103930" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1014590970" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1188717266" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_634618911" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_976984930" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1014074867" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_57945585" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1107826396" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1386651883" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="ар экскурсия в переходе" ID="ID_638849510" CREATED="1603833102376" MODIFIED="1603833112983">
<node TEXT="Пользовательский опыт" ID="ID_391381991" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_173715054" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1243912912" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1252272439" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_676602664" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1252386973" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_912946392" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1289006829" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1026413824" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_766012774" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="экскурсия по перрону" ID="ID_926637725" CREATED="1603833113650" MODIFIED="1603833139577">
<node TEXT="Пользовательский опыт" ID="ID_583316369" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1875607771" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_557512373" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_626454991" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_213374461" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_538541309" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1274127460" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_128235147" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_195626238" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1303838107" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="размещение якорей" ID="ID_249027128" CREATED="1603833248435" MODIFIED="1603833260888">
<node TEXT="Пользовательский опыт" ID="ID_8058491" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_390327902" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_338314329" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_416772881" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1903971062" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_565384971" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_275276906" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1100825956" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1187256780" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_965299868" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="конечная линия" ID="ID_760864241" CREATED="1603833262807" MODIFIED="1603833448962">
<node TEXT="Пользовательский опыт" ID="ID_333937567" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1518127826" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_149629975" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_494824120" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1050721957" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_345302331" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_332028931" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1535677133" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1479591980" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_766112333" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="конечная станция" ID="ID_1835528487" CREATED="1603833449383" MODIFIED="1603833463278">
<node TEXT="Пользовательский опыт" ID="ID_733672374" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1868750620" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_608082623" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1862464966" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_219487987" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_565807004" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_262859356" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_281302383" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1062823949" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1063414434" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="конечный эскалатор" ID="ID_1004978438" CREATED="1603833463479" MODIFIED="1603833479673">
<node TEXT="Пользовательский опыт" ID="ID_877184141" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1554104753" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1278432672" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_449075027" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1285507802" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1804689413" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1125862856" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1720001255" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_223668078" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_312514203" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="конечная лестница" ID="ID_1451011512" CREATED="1603833480126" MODIFIED="1603833493254">
<node TEXT="Пользовательский опыт" ID="ID_1692675330" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_324637711" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_1429304822" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_92107485" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_1522353784" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1369339868" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1849647680" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_1063855072" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1701824163" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1848375836" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="После маршрута" ID="ID_255928197" CREATED="1603825888440" MODIFIED="1603833623269">
<node TEXT="Пользовательский опыт" ID="ID_453875177" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_879104108" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_679960429" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_299609324" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_768590674" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_897227582" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_876847034" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения" ID="ID_1281498141" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1967606693" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1040849043" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="После программы" ID="ID_463168418" CREATED="1603825888440" MODIFIED="1603825894542">
<node TEXT="Пользовательский опыт" ID="ID_638912908" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_946714100" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_583672001" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1603473718" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_475917916" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1487321814" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_1839245194" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения" ID="ID_508050906" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_663634669" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_106436344" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
<node TEXT="Лог маршрута" ID="ID_283165780" CREATED="1603832162184" MODIFIED="1603832173094">
<node TEXT="Пользовательский опыт" ID="ID_1250410571" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что думает и чувствует общее" ID="ID_1156451327" CREATED="1603825947814" MODIFIED="1603828779719">
<node TEXT="Рекомендации общие" ID="ID_581257325" CREATED="1603825963836" MODIFIED="1603829439204">
<node TEXT="Улучшения общие" ID="ID_1140184348" CREATED="1603825972856" MODIFIED="1603829444510"/>
</node>
</node>
<node TEXT="Что делает частное" ID="ID_778450978" CREATED="1603825943521" MODIFIED="1603828787675">
<node TEXT="Что думает и чувствует частное" ID="ID_1420719657" CREATED="1603825947814" MODIFIED="1603828798958">
<node TEXT="Рекомендации частные" ID="ID_733477945" CREATED="1603825963836" MODIFIED="1603828756162">
<node TEXT="Улучшения частные" ID="ID_19457546" CREATED="1603825972856" MODIFIED="1603829398957"/>
</node>
</node>
</node>
</node>
<node TEXT="Рекомендации общие" ID="ID_1356958462" CREATED="1603825963836" MODIFIED="1603828766478">
<node TEXT="Улучшения" ID="ID_1522617531" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
</node>
</node>
<node TEXT="Пользовательский опыт" ID="ID_1591295292" CREATED="1603825810238" MODIFIED="1603825817057">
<node TEXT="Что делает" ID="ID_1376944733" CREATED="1603825943521" MODIFIED="1603825947431"/>
<node TEXT="Что думает и чувствует" ID="ID_972944604" CREATED="1603825947814" MODIFIED="1603825954086"/>
</node>
<node TEXT="Рекомендации" ID="ID_49247178" CREATED="1603825963836" MODIFIED="1603825972847">
<node TEXT="Улучшения" ID="ID_570108836" CREATED="1603825972856" MODIFIED="1603825976604"/>
</node>
<node TEXT="Примечания" ID="ID_607532828" CREATED="1603828192356" MODIFIED="1603828202078">
<node TEXT="В данной работе рассматриваются все варианты, предпочтения отдаются простым по этапам реализации проекта" ID="ID_808543815" CREATED="1603828202092" MODIFIED="1603828246290"/>
<node TEXT="Также возможны критерии" ID="ID_108946125" CREATED="1603828247540" MODIFIED="1603828255563">
<node TEXT="порядок реализации, простой как наиболее предпочтительный в плане развития проекта" ID="ID_1199421212" CREATED="1603828255578" MODIFIED="1603828330823"/>
<node TEXT="онлайн к оффлайн режиму, онлайн как наиболее предпочтительный для нашего пассажира" ID="ID_332118683" CREATED="1603828265618" MODIFIED="1603828303804"/>
<node TEXT="Точный и обновляемый, точный как наиболее препочтительный, и не точный как крайность, но тоже чтобы работало" ID="ID_1966259489" CREATED="1603828332048" MODIFIED="1603828377675"/>
<node TEXT="текущий и оценка актуальности, текущий против метрик активности акселерометра по шагам для ускорения обновления данных, так если человек стоит на месте, то актуальность данных вероятно высока и не требуется зашумлять эфир запросами" ID="ID_1579149510" CREATED="1603828385819" MODIFIED="1603828464078"/>
</node>
<node TEXT="режим профилирукемого макета сценариев решений на основе статистики" ID="ID_1921952431" CREATED="1603830030791" MODIFIED="1603830053330"/>
</node>
</node>
</node>
<node TEXT="ОВЕРДРАЙВ В РАМКАХ ХАКАТОНА" ID="ID_236384905" CREATED="1604130233896" MODIFIED="1604177339288">
<node TEXT="Соколов проработать пересечение с другими треками" ID="ID_1157239820" CREATED="1603956533223" MODIFIED="1604176737342">
<node ID="ID_1822984995" CREATED="1603956561380" MODIFIED="1603956561380" LINK="https://lk.hack2020.innoagency.ru/activities"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://lk.hack2020.innoagency.ru/activities">https://lk.hack2020.innoagency.ru/activities</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_636786711" CREATED="1603956610010" MODIFIED="1603956610010"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    Искусственный интеллект в городе
  </body>
</html>
</richcontent>
<node ID="ID_1331861133" CREATED="1603956617722" MODIFIED="1603956617722"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h4>
      1. Формирование интерактивной карты комплексного благоустройства города Москвы
    </h4>
  </body>
</html>
</richcontent>
<node ID="ID_1213372148" CREATED="1603956624482" MODIFIED="1603956624482"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="department">
      <div>
        <b>Главное контрольное управление города Москвы</b>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_112419869" CREATED="1603956624482" MODIFIED="1603956624482"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Решение должно представлять из себя систему анализа титульного списка объектов улично-дорожной сети города Москвы и тротуарной зоны подлежащих ремонту.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_665593285" CREATED="1603956632736" MODIFIED="1603956632736"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="content active">
      <p class="visible" style="display: block !important">
        Решение должно представлять из себя систему анализа титульного списка объектов улично-дорожной сети города Москвы и тротуарной зоны подлежащих ремонту. Анализ титульного списка представляет из себя автоматический алгоритм разгруппировки списка на единичные элементы, такие как проезжая часть, тротуары, обочины, бортовой камень и прочее, а также нанесение их на карту Москвы. Решение также должно выявлять пересечения одних и тех же объектов в случае их дублирования в разных титульных списках.
      </p>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_853788974" CREATED="1603956632736" MODIFIED="1603956632736"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="content active">
      <p class="visible" style="display: block !important">
        В качестве дополнительного задания предлагается реализовать систему построения маршрута следования контролеров, осуществляющих проверку необходимости выполнения работ по благоустройству в текущем году на данном объекте. Командам будет представлен титульный список объектов улично-дорожной сети города Москвы подлежащих ремонту в текущем году.
      </p>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_262436458" CREATED="1603956650207" MODIFIED="1603956650207"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h4>
      2. Разработка рекомендательного сервиса по контенту и активностям учреждений культуры
    </h4>
  </body>
</html>
</richcontent>
<node ID="ID_300797807" CREATED="1603956650217" MODIFIED="1603956650217"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="department">
      <div>
        <b>Департамент культуры города Москвы</b>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_144178261" CREATED="1603956650217" MODIFIED="1603956650217"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      В рамках данной задачи участникам предстоит разработать сервис, предлагающий посетителю библиотек и культурных центров Москвы уникальные персонализированные подборки контента и активностей учреждений на основе уже имеющегося &quot;культурного опыта&quot; человека.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_716107880" CREATED="1603956678762" MODIFIED="1603956678762"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    В рамках данной задачи участникам предстоит разработать сервис, предлагающий посетителю библиотек и культурных центров Москвы уникальные персонализированные подборки контента и активностей учреждений на основе уже имеющегося &quot;культурного опыта&quot; человека. Сам &quot;опыт&quot; включает сведения о прочтенных книгах и журналах, посещенных событиях и кружках, данные о которых посредством API предоставляет информационная система, функционирующая в учреждениях.
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_552613344" CREATED="1603956685545" MODIFIED="1603956685545"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h4>
      3. Разработка инструмента оценки качества работы алгоритмов разметки медицинских изображений
    </h4>
  </body>
</html>
</richcontent>
<node ID="ID_1344341066" CREATED="1603956694185" MODIFIED="1603956694185"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="department">
      <div>
        <b>Департамент здравоохранения города Москвы</b>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1550968617" CREATED="1603956694185" MODIFIED="1603956694185"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Анализ медицинских изображений – рентгенограмм, компьютерных, магнитно-резонансных томограмм и других диагностических исследований – это распространенная задача при обучении систем компьютерного зрения.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_689457970" CREATED="1603956702355" MODIFIED="1603956702355"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="content active">
      <p class="visible" style="display: block !important">
        Анализ медицинских изображений – рентгенограмм, компьютерных, магнитно-резонансных томограмм и других диагностических исследований – это распространенная задача при обучении систем компьютерного зрения. Но как оценить результат работы такой системы? Как понять, насколько правильно система выделяет те области, которые представляют диагностический интерес? Как сравнить, насколько она далека или близка от той разметки, которую сделает опытный врач? Существуют десятки способов сравнить в точности обе разметки. Но среди них нет ни одного полностью автоматизированного решения, которое бы удовлетворяло требованиям врачей.
      </p>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_51896858" CREATED="1603956702355" MODIFIED="1603956702355"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="content active">
      <p class="visible" style="display: block !important">
        В рамках хакатона командам предлагается разработать инструмент, который будет оценивать качество разметки медицинских изображений. Он должен автоматически определять набор метрик, а результаты его работы должны наиболее точно совпадать с мнением экспертов (результатами экспертной оценки).
      </p>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1443947986" CREATED="1603956715415" MODIFIED="1603956743276"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h4>
      4. Разработка умного правового помощника для предпринимателей
    </h4>
  </body>
</html>
</richcontent>
<node ID="ID_116316859" CREATED="1603956715415" MODIFIED="1603956715415"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="department">
      <div>
        <b>Департамент предпринимательства и инновационного развития города Москвы</b>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_570672107" CREATED="1603956715415" MODIFIED="1603956715415"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Идеальное решение состоит в том, что умный помощник на основании переписки может формировать простой и правильный ответ на правовые вопросы, возникающие в деятельности предпринимателей.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1675260521" CREATED="1603956728876" MODIFIED="1603956743276"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    Идеальное решение состоит в том, что умный помощник на основании переписки может формировать простой и правильный ответ на правовые вопросы, возникающие в деятельности предпринимателей. Помощник должен уметь определять тип документа и его ключевые данные для построения правильного ответа, а также распознавать входящий запрос и автоматически формировать проект ответного документа. Социальный эффект заключается в общедоступности правовой информационной консультации, что приводит к снижению правовой безграмотности, влекущей финансовые последствия для предпринимателей.
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_343374437" CREATED="1603956741016" MODIFIED="1603956741016"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h4>
      5. Автоматизированный анализ архивов фото- и скан- копий технических и контрактных документов
    </h4>
  </body>
</html>
</richcontent>
<node ID="ID_1663408892" CREATED="1603956757146" MODIFIED="1603956757146"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="department">
      <div>
        <b>Государственная инспекция по контролю за использованием объектов недвижимости города Москвы</b>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_324245198" CREATED="1603956757146" MODIFIED="1603956757146"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Необходимо распознать множество скан-копий технических и контрактных документов с определением их структурных элементов, классифицировать по заданному набору признаков.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1316255536" CREATED="1603956763306" MODIFIED="1603956763306"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    Необходимо распознать множество скан-копий технических и контрактных документов с определением их структурных элементов, классифицировать по заданному набору признаков. Результаты распознавания организовать в виде базы данных с возможностью полнотекcтового поиска и фильтрации по параметрам. Предоставить пользовательские интерфейсы как для работы с полученными результатами, так и для последующего самостоятельного распознавания документов, возможность построения аналитических панелей и отчетов, а также REST API для бесшовной интеграции.
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_604522703" CREATED="1603956771766" MODIFIED="1603956771766"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    Цифровизация городских структур
  </body>
</html>
</richcontent>
<node ID="ID_1245407854" CREATED="1603956787456" MODIFIED="1603956787456"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h4>
      6. Разработка сервиса поддержки предпринимателей «Легкий старт»
    </h4>
  </body>
</html>
</richcontent>
<node ID="ID_300930074" CREATED="1603956787456" MODIFIED="1603956787456"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="department">
      <div>
        <b>Департамент информационных технологий города Москвы</b>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_602816006" CREATED="1603956787456" MODIFIED="1603956787456"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Разработка рекомендательного сервиса для юридических лиц и индивидуальных предпринимателей по поддержке принятия решений об открытии новых (перепрофилирования действующих) торговых объектов с учетом особенностей итогового территориального размещения таких объектов и в разрезе выбранных направлений видов деятельности (категорий товаров/работ/услуг).
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_432768526" CREATED="1603956807007" MODIFIED="1603956807007"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    Разработка рекомендательного сервиса для юридических лиц и индивидуальных предпринимателей по поддержке принятия решений об открытии новых (перепрофилирования действующих) торговых объектов с учетом особенностей итогового территориального размещения таких объектов и в разрезе выбранных направлений видов деятельности (категорий товаров/работ/услуг).
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1321763015" CREATED="1603956787456" MODIFIED="1603956787456"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h4>
      7. Разработка виртуальной лаборатории по программированию «мой код»
    </h4>
  </body>
</html>
</richcontent>
<node ID="ID_348282585" CREATED="1603956787466" MODIFIED="1603956787466"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="department">
      <div>
        <b>Департамент образования и науки города Москвы</b>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1818775181" CREATED="1603956787466" MODIFIED="1603956787466"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Виртуальная лаборатория по программированию представляет собой браузерное решение, предоставляющее реализацию двух пользовательских сценариев: «Учитель» и «Ученик».
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_256841713" CREATED="1603956839159" MODIFIED="1603956839159"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    Виртуальная лаборатория по программированию представляет собой браузерное решение, предоставляющее реализацию двух пользовательских сценариев: «Учитель» и «Ученик». Пользовательский функционал «Учитель» должен обеспечивать возможность размещения в лаборатории учебных материалов, тренировочных заданий и кейсов, наборов тестов для проверки корректности программных кодов. Пользовательский функционал «Ученик» должен обеспечить возможность доступа к учебным материалам, заданиям и кейсам. Программный код решения, написанный на Pascal, Python, С, C++, Java, автоматически тестируется.
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_507122934" CREATED="1603956787466" MODIFIED="1603956787466"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h4>
      8. Разработка электронной базы животных без владельцев
    </h4>
  </body>
</html>
</richcontent>
<node ID="ID_214031059" CREATED="1603956787476" MODIFIED="1603956787476"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="department">
      <div>
        <b>Департамент жилищно-коммунального хозяйства города Москвы</b>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_516789078" CREATED="1603956787476" MODIFIED="1603956787476"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Участникам хакатона предлагается разработать информационную систему «База животных без владельцев», интегрированную с mos.ru.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1244203146" CREATED="1603956869333" MODIFIED="1603956869333"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    Участникам хакатона предлагается разработать информационную систему «База животных без владельцев», интегрированную с mos.ru. Реализация данной системы позволит автоматизировать процесс учета сведений о животных, содержащихся в приютах, а также упростить процедуру поиска новых владельцев для животных.
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1516006062" CREATED="1603956787476" MODIFIED="1603956787476"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h4>
      9. Разработка мобильного приложения для предупреждения несчастных случаев и учета рабочего времени на строительной площадке
    </h4>
  </body>
</html>
</richcontent>
<node ID="ID_685662141" CREATED="1603956787476" MODIFIED="1603956787476"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="department">
      <div>
        <b>Департамент строительства города Москвы</b>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_7268487" CREATED="1603956787486" MODIFIED="1603956787486"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Разработка приложения для мобильных устройств на android/ios для мониторинга активности персонала на строительной площадке. Разработка прошивки/микропрограммы для установки на часы/браслеты для взаимодействия с приложением по мониторингу персонала на строительной площадке.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_776344084" CREATED="1603956895015" MODIFIED="1603956895015"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    Разработка приложения для мобильных устройств на android/ios для мониторинга активности персонала на строительной площадке. Разработка прошивки/микропрограммы для установки на часы/браслеты для взаимодействия с приложением по мониторингу персонала на строительной площадке. Разработка серверного приложения для взаимодействия с мобильными устройствами, осуществляющее обработку данных.
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_403581444" CREATED="1603956787486" MODIFIED="1603956787486"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h4>
      10. Разработка модуля интерактивной карты метро города москвы с возможностью построения маршрута для мобильного приложения ios и android
    </h4>
  </body>
</html>
</richcontent>
<node ID="ID_1786547988" CREATED="1603956787486" MODIFIED="1603956787486"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="department">
      <div>
        <b>Московский транспорт</b>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1756794889" CREATED="1603956787486" MODIFIED="1603956787486"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Интерактивная карта метро, которая будет доступна в мобильном приложении на платформах iOS и Android.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1698544914" CREATED="1603956914947" MODIFIED="1603956914947"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="content active">
      <p class="visible" style="display: block !important">
        Интерактивная карта метро, которая будет доступна в мобильном приложении на платформах iOS и Android. Модуль включает в себя взаимодействие пользователя с картой, просмотр информации о станциях и построение оптимальных маршрутов не только в режиме online, но и без использования интернета.
      </p>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_590412957" CREATED="1603956914947" MODIFIED="1603956914947"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="content active">
      <p class="visible" style="display: block !important">
        Кроме того, для комфортной работы с картой, участникам необходимо уделить внимание скорости и плавности работы интерфейса.
      </p>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Применимо ли наше решение в других треках и как?" ID="ID_1943220188" CREATED="1603956574650" MODIFIED="1603956597510"/>
</node>
</node>
<node TEXT="порядок хакатона" ID="ID_321599913" CREATED="1604092936011" MODIFIED="1604176852238">
<node TEXT="🔥🔥Расписание 1ого чек поинта в Zoom!" ID="ID_267622431" CREATED="1604092895788" MODIFIED="1604092895788">
<node TEXT="Будьте готовы за 30 минут до вашего времени" ID="ID_1795913451" CREATED="1604092912789" MODIFIED="1604092912789"/>
<node TEXT="Формат: 2 мин на вашу презентацию идеи + 3 мин на вопросы от экспертов" ID="ID_490379331" CREATED="1604092912789" MODIFIED="1604092912789"/>
<node TEXT="Если будете показывать презентацию - готовьтесь заранее" ID="ID_1762787682" CREATED="1604092912791" MODIFIED="1604092912791"/>
<node TEXT="Тайминг будет строгим, так как команд очень много, так что формулируйте мысли чётко =)" ID="ID_1519549623" CREATED="1604092912793" MODIFIED="1604092912793"/>
<node TEXT="Ссылку на свою комнату в Zoom найдёте в разделе &quot;Хакатон&quot; на платформе (https://lk.hack2020.innoagency.ru/solutions)." ID="ID_1054780568" CREATED="1604092912795" MODIFIED="1604092912795" LINK="https://lk.hack2020.innoagency.ru/solutions)."/>
<node TEXT="11:00 42" ID="ID_1716399158" CREATED="1604092912798" MODIFIED="1604092912798"/>
<node TEXT="11:06 bream of dream" ID="ID_1007555757" CREATED="1604092912801" MODIFIED="1604092912801"/>
<node TEXT="11:12 COSMOTEQ DELTA" ID="ID_1167726882" CREATED="1604092912801" MODIFIED="1604092912801"/>
<node TEXT="11:18 Da Vinci" ID="ID_1653659881" CREATED="1604092912802" MODIFIED="1604092912802"/>
<node TEXT="11:24 DataMap" ID="ID_875854917" CREATED="1604092912803" MODIFIED="1604092912803"/>
<node TEXT="11:30 Five Blocks Down" ID="ID_1935619726" CREATED="1604092912803" MODIFIED="1604092912803"/>
<node TEXT="11:36 FluffyDev" ID="ID_121591380" CREATED="1604092912807" MODIFIED="1604092912807"/>
<node TEXT="11:42 Lorem ipsum" ID="ID_101830655" CREATED="1604092912808" MODIFIED="1604092912808"/>
<node TEXT="11:48 Nice" ID="ID_1145492908" CREATED="1604092912808" MODIFIED="1604092912808"/>
<node TEXT="11:54 ninsar" ID="ID_1080502513" CREATED="1604092912809" MODIFIED="1604092912809"/>
<node TEXT="12:00 ONE_CODE_MEN" ID="ID_893072341" CREATED="1604092912809" MODIFIED="1604092912809"/>
<node TEXT="12:06 ping_win" ID="ID_1225474052" CREATED="1604092912809" MODIFIED="1604092912809"/>
<node TEXT="12:12 PYC" ID="ID_1510558956" CREATED="1604092912810" MODIFIED="1604092912810"/>
<node TEXT="12:18 YetiCrab" ID="ID_58085044" CREATED="1604092912811" MODIFIED="1604092912811"/>
<node TEXT="12:24 Ветераны РэТэКа" ID="ID_1353926491" CREATED="1604092912812" MODIFIED="1604092912812"/>
<node TEXT="12:30 Космический батут Тети Зины" ID="ID_485431164" CREATED="1604092912812" MODIFIED="1604092912812"/>
<node TEXT="12:36 Работяги и Настя" ID="ID_556305505" CREATED="1604092912813" MODIFIED="1604092912813"/>
<node TEXT="12:42 Совет трёх" ID="ID_1210078737" CREATED="1604092912816" MODIFIED="1604092912816"/>
<node TEXT="12:48 Стратиенко" ID="ID_40755569" CREATED="1604092912816" MODIFIED="1604092912816"/>
<node TEXT="12:54 Тессеракт" ID="ID_457957930" CREATED="1604092912817" MODIFIED="1604092912817"/>
<node TEXT="13:00 PunkZ" ID="ID_823902895" CREATED="1604092912817" MODIFIED="1604092912817"/>
<node TEXT="13:06 scale-giant-six-south-элита-имфиита" ID="ID_345371399" CREATED="1604092912818" MODIFIED="1604092912818"/>
<node TEXT="13:12 Ночной кружок макроме" ID="ID_309869521" CREATED="1604092912818" MODIFIED="1604092912818"/>
<node TEXT="13:18 Gucci flip flops" ID="ID_393025659" CREATED="1604092912820" MODIFIED="1604092912820"/>
<node TEXT="13:24 Оракул" ID="ID_930590430" CREATED="1604092912822" MODIFIED="1604092912822"/>
<node TEXT="13:30 theTeam" ID="ID_926913999" CREATED="1604092912822" MODIFIED="1604092912822"/>
<node TEXT="13:36 Гэнг" ID="ID_867220370" CREATED="1604092912823" MODIFIED="1604092912823"/>
<node TEXT="13:42 Метро 2033" ID="ID_1790103286" CREATED="1604092912823" MODIFIED="1604092912823"/>
<node TEXT="Увидимся завтра!" ID="ID_1910843169" CREATED="1604092912824" MODIFIED="1604092912824"/>
<node TEXT="Ссылка на датасет (и всё остальное):" ID="ID_148269041" CREATED="1604092912824" MODIFIED="1604092912824"/>
<node TEXT="https://drive.google.com/drive/folders/1jWTYdKf1zc4e-4B2bjVNPun-LZbxSwXo" ID="ID_1288061613" CREATED="1604092912825" MODIFIED="1604092912825" LINK="https://drive.google.com/drive/folders/1jWTYdKf1zc4e-4B2bjVNPun-LZbxSwXo"/>
</node>
</node>
<node TEXT="11:12 COSMOTEQ DELTA" ID="ID_122202385" CREATED="1604092912801" MODIFIED="1604096538941">
<node TEXT="Киллер фичи" ID="ID_328964892" CREATED="1603989455304" MODIFIED="1604130320651">
<edge DASH="SOLID"/>
<node TEXT="Названия класса услуг" ID="ID_506628767" CREATED="1603989466078" MODIFIED="1603990827422">
<node TEXT="название услуг" ID="ID_1432660161" CREATED="1603990787298" MODIFIED="1603990803106">
<node TEXT="описание" ID="ID_129332480" CREATED="1604093422794" MODIFIED="1604093426335"/>
<node TEXT="описание, название фичи характеризующие" ID="ID_560747855" CREATED="1603990803113" MODIFIED="1603990954697">
<node TEXT="описание, описание фичи характеризующие" ID="ID_1783394375" CREATED="1603990803113" MODIFIED="1603990958273"/>
<node TEXT="интерактив" ID="ID_1841838344" CREATED="1603991614485" MODIFIED="1603991619283"/>
</node>
</node>
</node>
<node TEXT="Готовое" ID="ID_388699122" CREATED="1604093264162" MODIFIED="1604093381186" BACKGROUND_COLOR="#ff0000"/>
<node TEXT="ар навигация по точкам" ID="ID_126764178" CREATED="1603990337810" MODIFIED="1603990346237">
<node TEXT="персонаж показывает путь, например Пушкин" ID="ID_755362622" CREATED="1603990346250" MODIFIED="1603990930002">
<node TEXT="описание" ID="ID_1458703875" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_800099096" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_274945353" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="интерактив" ID="ID_970228442" CREATED="1603991614485" MODIFIED="1603991619283"/>
</node>
<node TEXT="точки=метки=якоря" ID="ID_1730682924" CREATED="1603990368295" MODIFIED="1603990401150">
<node TEXT="описание" ID="ID_352116670" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_110363860" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1739422898" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="метки цифра" ID="ID_1475584040" CREATED="1603990372476" MODIFIED="1603990377289"/>
<node TEXT="метки кюар" ID="ID_842195148" CREATED="1603990377474" MODIFIED="1603990382165"/>
</node>
</node>
<node TEXT="3д навигация по точкам" ID="ID_1196368317" CREATED="1603991078145" MODIFIED="1603991104113">
<node TEXT="карта в 3д или с персонажем от 3-го лица" ID="ID_539255682" CREATED="1603991106052" MODIFIED="1603991133755">
<node TEXT="описание" ID="ID_586597732" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_925235582" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1466846849" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
</node>
<node TEXT="3д навигация по облаку точек" ID="ID_904647930" CREATED="1603991140080" MODIFIED="1603991150901">
<node TEXT="карта 3д с персонажем от 3-го лица, локация персонажа соответствует локации пассажира сейчас или немного в будущем" ID="ID_1388970490" CREATED="1603991153675" MODIFIED="1603991197376">
<node TEXT="проходки персонажа в будущее" ID="ID_648558465" CREATED="1603991199663" MODIFIED="1603991207311">
<node TEXT="интерактив" ID="ID_280949855" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1647451394" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
</node>
<node TEXT="В разработке" ID="ID_1519140995" CREATED="1604093272258" MODIFIED="1604093391240" BACKGROUND_COLOR="#33ff33"/>
<node TEXT="Ар навигация в пути" ID="ID_1123920138" CREATED="1603990309176" MODIFIED="1603990337472">
<node TEXT="видео пути с оверлеем парящая линия или стрелки показывающие Ваш путь" ID="ID_348572671" CREATED="1603990315818" MODIFIED="1604095383869">
<node TEXT="описание" ID="ID_676349015" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_1569876551" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_424551713" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
</node>
<node TEXT="Аудио навигация самая плавная из возможных))" ID="ID_1946416574" CREATED="1603989477419" MODIFIED="1603990014308">
<node TEXT="аудио гид" ID="ID_1202274042" CREATED="1603990016265" MODIFIED="1603990021386">
<node TEXT="описание" ID="ID_487037287" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_1762642549" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1240362559" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="автоматичемкий аудио гид по станциям" ID="ID_1404798693" CREATED="1603990292023" MODIFIED="1603990304249">
<node TEXT="интерактив" ID="ID_755843003" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="аудио" ID="ID_1710974401" CREATED="1603991657453" MODIFIED="1603991660500"/>
<node TEXT="кнопки наушников" ID="ID_571076883" CREATED="1603991660757" MODIFIED="1603991666568"/>
<node TEXT="лайки моментов на таймлайн" ID="ID_157382748" CREATED="1603991840800" MODIFIED="1603991852884"/>
<node TEXT="фото с точкой аудио" ID="ID_1100961237" CREATED="1603991853314" MODIFIED="1603991859878"/>
</node>
</node>
</node>
<node TEXT="аудио экскурсии" ID="ID_561102827" CREATED="1603990021737" MODIFIED="1603990038701">
<node TEXT="описание" ID="ID_550728147" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_957105885" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_363864539" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="трекинг локации школьников и предподавателей, чтобы никто не потерялся в пути до музея и обратно" ID="ID_781475537" CREATED="1603990263139" MODIFIED="1603990288444">
<node TEXT="интерактив" ID="ID_877981008" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_379406239" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
<node TEXT="аудио радио" ID="ID_1649816939" CREATED="1603990040463" MODIFIED="1603990075907">
<node TEXT="описание" ID="ID_830962216" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_873672343" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1200177552" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="автоматическая пауза при необходимости выйти из вагона" ID="ID_50467905" CREATED="1603990200484" MODIFIED="1603990219767">
<node TEXT="интерактив" ID="ID_1740682608" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_459054633" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="каналы метро" ID="ID_1674532520" CREATED="1603990222466" MODIFIED="1603990234633">
<node TEXT="интерактив" ID="ID_998157805" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="участие в передаче" ID="ID_755366755" CREATED="1603991872131" MODIFIED="1603991875978"/>
</node>
</node>
<node TEXT="каналы веток" ID="ID_84755197" CREATED="1603990234988" MODIFIED="1603990238271">
<node TEXT="интерактив" ID="ID_935571502" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_571656438" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="каналы станций" ID="ID_1614688416" CREATED="1603990238424" MODIFIED="1603990241979">
<node TEXT="интерактив" ID="ID_720245106" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1491754908" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="подкасты" ID="ID_913056729" CREATED="1603990242774" MODIFIED="1603990244604">
<node TEXT="интерактив" ID="ID_619385270" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_336835503" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
<node TEXT="аудио книги" ID="ID_202675169" CREATED="1603990076366" MODIFIED="1603990082203">
<node TEXT="описание" ID="ID_1439494764" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_1891929488" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_565952771" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="автоматическая пауза при необходимости выйти из вагона" ID="ID_1174138433" CREATED="1603990200484" MODIFIED="1603990219767"/>
<node TEXT="магазин книг" ID="ID_1903675387" CREATED="1603990253302" MODIFIED="1603990259463"/>
</node>
<node TEXT="аудио реклама синхронная с дисплеями" ID="ID_1062936513" CREATED="1603990083402" MODIFIED="1603990110842">
<node TEXT="описание" ID="ID_437762344" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_756163501" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1166921134" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="синхронизация с аудио на дисплее в поле зрения" ID="ID_1195059843" CREATED="1603990172856" MODIFIED="1604093622502"/>
</node>
<node TEXT="аудио навигация группы" ID="ID_1623882655" CREATED="1603990116555" MODIFIED="1603990128608">
<node TEXT="описание" ID="ID_1822096028" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_1517782530" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1884107638" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="акселерометр в наушниках - функция подруливания внимания (поворот головы)" ID="ID_1867012227" CREATED="1603990132898" MODIFIED="1603990165085">
<node TEXT="интерактив" ID="ID_721971981" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_644324037" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
</node>
<node TEXT="ар рентген перрона и вестибюля" ID="ID_1196986294" CREATED="1603990714534" MODIFIED="1604130320648">
<node TEXT="стоишь на платформе и повернешь не повернёшь, а телефон наведешь, то и видно что там за лестницей в далеке, что за лестница, что за лестницей, что за турникетом, и что за вестибюлем, глядишь и идёшь" ID="ID_1802409135" CREATED="1603990552206" MODIFIED="1603990707868">
<node TEXT="интерактив" ID="ID_1955083219" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="интерактив" ID="ID_1087280045" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1589286585" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
</node>
<node TEXT="ар рентген города" ID="ID_309223239" CREATED="1603990427767" MODIFIED="1603990448131">
<node TEXT="сидишь в поезде и видишь здания над собой, достаточно навести камеру на потолок" ID="ID_1723544832" CREATED="1603990448142" MODIFIED="1603990515429">
<node TEXT="описание" ID="ID_1640077660" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_1508061570" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_556145854" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="архитектура" ID="ID_748750756" CREATED="1603990476607" MODIFIED="1603990481259">
<node TEXT="интерактив" ID="ID_44998332" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_994141288" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="музеи" ID="ID_1042465656" CREATED="1603990481546" MODIFIED="1603990484248">
<node TEXT="интерактив" ID="ID_79584526" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1543561911" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="театры" ID="ID_685958" CREATED="1603990484425" MODIFIED="1603990485687"/>
<node TEXT="купоны" ID="ID_310283774" CREATED="1603990485917" MODIFIED="1603990490068">
<node TEXT="интерактив" ID="ID_513619996" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="интерактив" ID="ID_1774675126" CREATED="1603991614485" MODIFIED="1603991619283"/>
</node>
</node>
<node TEXT="клик по зданию открывает купоны и акции" ID="ID_161365448" CREATED="1603990490400" MODIFIED="1603990504174">
<node TEXT="интерактив" ID="ID_1679931625" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1898338510" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
</node>
<node TEXT="ар навигация с ИИ" ID="ID_1650723279" CREATED="1603990975513" MODIFIED="1603990983294">
<node TEXT="трекинг облака точек" ID="ID_1717468101" CREATED="1603991347084" MODIFIED="1603991353687">
<node TEXT="описание" ID="ID_996895653" CREATED="1604093422794" MODIFIED="1604093426335">
<node TEXT="интерактив" ID="ID_1665334405" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_268385234" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="навигация по характерных эелементам кадра" ID="ID_702990640" CREATED="1604093539302" MODIFIED="1604093556705"/>
</node>
</node>
<node TEXT="ар рентген тоннелей" ID="ID_644251712" CREATED="1603990516493" MODIFIED="1603990528162">
<node TEXT="стоишь на перроне и видешь поезд вдалеке(!??)" ID="ID_1578114977" CREATED="1603990528175" MODIFIED="1603990551518">
<node TEXT="интерактив" ID="ID_1733457165" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="интерактив" ID="ID_665756488" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1446506405" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
</node>
<node TEXT="ар перрон" ID="ID_251044552" CREATED="1603990888460" MODIFIED="1603990898830">
<node TEXT="добавление на карту площадки перрона объектов" ID="ID_1540143153" CREATED="1603990995398" MODIFIED="1603991019829">
<node TEXT="фото" ID="ID_1209260325" CREATED="1603991021224" MODIFIED="1603991022980">
<node TEXT="интерактив" ID="ID_1088026018" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1319380334" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="видео" ID="ID_1378679253" CREATED="1603991023983" MODIFIED="1603991025227">
<node TEXT="интерактив" ID="ID_277204163" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_402892195" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="персонажи" ID="ID_332935796" CREATED="1603991025385" MODIFIED="1603991028265">
<node TEXT="интерактив" ID="ID_1354954444" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_82073401" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="персонажи со звуком" ID="ID_1041163855" CREATED="1603991028453" MODIFIED="1603991035647">
<node TEXT="интерактив" ID="ID_488029230" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1320362810" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
<node TEXT="магазин персонажей экскурсоводов" ID="ID_791997568" CREATED="1603991040186" MODIFIED="1603991050027">
<node TEXT="интерактив" ID="ID_1454180853" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_854924611" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
</node>
<node TEXT="ар навигационные аксессуары" ID="ID_1917620739" CREATED="1603991364526" MODIFIED="1603991379589">
<node TEXT="phone rig" ID="ID_1226914431" CREATED="1603991379600" MODIFIED="1603991388341">
<node TEXT="интерактив" ID="ID_735961457" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="интерактив" ID="ID_1515540661" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_108901771" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
<node TEXT="phone collar" ID="ID_1699657846" CREATED="1603991388679" MODIFIED="1603991396000">
<node TEXT="интерактив" ID="ID_1731720706" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="интерактив" ID="ID_510637499" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1914215532" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
<node TEXT="Авторы Соколов Гиколай и Юлия Гусева(пром диз)" ID="ID_1051808875" CREATED="1603991398526" MODIFIED="1603991429610">
<node TEXT="интерактив" ID="ID_643578208" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="интерактив" ID="ID_1781618653" CREATED="1603991614485" MODIFIED="1603991619283">
<node TEXT="наработки" ID="ID_1696702067" CREATED="1604093467116" MODIFIED="1604093471581"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="способы трекинга координат - главный пробел метро" ID="ID_773671257" CREATED="1603957049712" MODIFIED="1603957080602">
<node TEXT="онлайн" ID="ID_1999331293" CREATED="1603957087542" MODIFIED="1603957091112">
<node TEXT="триангуляция" ID="ID_11306758" CREATED="1603957102453" MODIFIED="1603957110543"/>
<node TEXT="камеры видео в метро" ID="ID_279924584" CREATED="1603957113053" MODIFIED="1603957125303"/>
<node TEXT="камеры видео с мобильного" ID="ID_1553589870" CREATED="1603957167784" MODIFIED="1603957186584"/>
</node>
<node TEXT="офлайн" ID="ID_1535295911" CREATED="1603957091412" MODIFIED="1603957093582">
<node TEXT="камеры видео с мобильного" ID="ID_457261597" CREATED="1603957167784" MODIFIED="1603957186584"/>
<node TEXT="якоря + акселерометр, подсчёт шагов и повороты" ID="ID_944108549" CREATED="1603957130953" MODIFIED="1603957158164">
<node TEXT="Наработки" ID="ID_1953934719" CREATED="1604130391925" MODIFIED="1604130401532">
<node TEXT="алгоритм" ID="ID_26804734" CREATED="1604130401538" MODIFIED="1604130409952"/>
</node>
</node>
<node TEXT="ар режим с трекингом ярких черт станции Сверточная нейронка" ID="ID_408030024" CREATED="1603957189064" MODIFIED="1603957239396">
<node TEXT="Наработки" ID="ID_933838550" CREATED="1604130391925" MODIFIED="1604130401532">
<node TEXT="код" ID="ID_885947094" CREATED="1604130401538" MODIFIED="1604130416782"/>
</node>
</node>
<node TEXT="ар режим с кюар якорей" ID="ID_1349549526" CREATED="1603957217014" MODIFIED="1603957258806">
<node TEXT="Наработки" ID="ID_1173856989" CREATED="1604130391925" MODIFIED="1604130401532">
<node TEXT="код" ID="ID_1658577571" CREATED="1604130401538" MODIFIED="1604130422999"/>
</node>
</node>
</node>
<node TEXT="гибрид" ID="ID_811697589" CREATED="1603957095733" MODIFIED="1603957098163"/>
<node TEXT="ссылки на прочие упоминая этого аспекта в карте(свести всё в одно место для удобства)" ID="ID_419969116" CREATED="1604176907499" MODIFIED="1604176947348"/>
</node>
</node>
<node TEXT="Наработки" ID="ID_814589178" CREATED="1604130973586" MODIFIED="1604130979483">
<node TEXT="Дима" ID="ID_954497167" CREATED="1604130979495" MODIFIED="1604130984648">
<node TEXT="https://skfb.ly/6VYEV" ID="ID_1352985043" CREATED="1604130984659" MODIFIED="1604130990415"/>
<node TEXT="мы позволим побродить по станции в режиме игры" ID="ID_1638232705" CREATED="1604131013137" MODIFIED="1604131337717"/>
</node>
<node TEXT="Юля" ID="ID_1282325629" CREATED="1604131028481" MODIFIED="1604131030996">
<node TEXT="интерфейс" ID="ID_1006113940" CREATED="1604131660139" MODIFIED="1604131668959">
<node TEXT="линк на фигму" ID="ID_258594856" CREATED="1604177145177" MODIFIED="1604177150528"/>
</node>
</node>
<node TEXT="Ярослав" ID="ID_1186339864" CREATED="1604131031516" MODIFIED="1604131036007">
<node TEXT="Мысли по презентации." ID="ID_218255936" CREATED="1604131686699" MODIFIED="1604131686699">
<node TEXT="1) у нас 6 слайдов." ID="ID_1184907851" CREATED="1604131686699" MODIFIED="1604131686699"/>
<node TEXT="2) Нужен дизайнер на презентацию." ID="ID_597012636" CREATED="1604131686700" MODIFIED="1604131686700"/>
<node TEXT="Мое предложение по слайдам:" ID="ID_1255345755" CREATED="1604131686701" MODIFIED="1604131686701"/>
<node TEXT="1) Название проекта, краткое описание." ID="ID_1394362582" CREATED="1604131686703" MODIFIED="1604131686703"/>
<node TEXT="2) Описание проекта, описание боли пользователей" ID="ID_688558692" CREATED="1604131686704" MODIFIED="1604131686704"/>
<node TEXT="3) Последний слайд с командой  (фото, роль)" ID="ID_1044637859" CREATED="1604131686705" MODIFIED="1604131686705"/>
<node TEXT="4) Режим  3Д/2Д картами метро и навигацией" ID="ID_1867295978" CREATED="1604131686706" MODIFIED="1604131686706"/>
<node TEXT="5) Режим дополненной реальности" ID="ID_599432599" CREATED="1604131686706" MODIFIED="1604131686706"/>
<node TEXT="6) Режим аудиогида" ID="ID_1618735436" CREATED="1604131686707" MODIFIED="1604131686707"/>
</node>
<node TEXT="Хочу расписать пайплайн разработки прототипа." ID="ID_1827717945" CREATED="1604131705567" MODIFIED="1604131705567">
<node TEXT="1) Определиться  со станцией метро (доступность самой станции, доступность 3Д модели)" ID="ID_1539028533" CREATED="1604131705568" MODIFIED="1604131705568"/>
<node TEXT="2) Определение объектов в кадре прототипа (Персонажи, стрелочки, станция)" ID="ID_653038979" CREATED="1604131705571" MODIFIED="1604131705571"/>
<node TEXT="3) Проработка аудиогида. Проектирование привязки якорей метро к аудио." ID="ID_1230543486" CREATED="1604131705574" MODIFIED="1604131705574"/>
<node TEXT="4) Создание прототипа с данными 3Д моделями и аудиотреками." ID="ID_39480892" CREATED="1604131705576" MODIFIED="1604131705576"/>
<node TEXT="5) Запуск прототипа в метро. Оцифровка метро якорями. привязки 3д моделей и аудиотреков к якорям в реальном времени. Видеосъемка." ID="ID_1917177039" CREATED="1604131705578" MODIFIED="1604131705578"/>
</node>
</node>
<node TEXT="Николай" ID="ID_1623623303" CREATED="1604131036458" MODIFIED="1604131042949">
<node TEXT="детализация и проработка в карте" ID="ID_936613684" CREATED="1604131723408" MODIFIED="1604177056117">
<node TEXT="экспорт на сегменты" ID="ID_1644675421" CREATED="1604177057306" MODIFIED="1604177063113"/>
</node>
</node>
</node>
<node TEXT="вступление" ID="ID_1710996161" CREATED="1604133506388" MODIFIED="1604144947847">
<node TEXT="Дима" ID="ID_655234987" CREATED="1604133667456" MODIFIED="1604133703016">
<node TEXT="3д режим Инновационный цифровой двойник" ID="ID_1175825329" CREATED="1604133703755" MODIFIED="1604177115568">
<node TEXT="Мы собрали клевую команду, есть интересные идеи, протестировать гипотезы, много свежих идей, продуктовые гипотезы, которые мы хотим протестировать в рамках конкурса, мы будем делать инновационный цифровой двойник станции и построение маршрутов с использованием технологий дополненной реальности.&#xa;Проблема метро - это ограниченное пространство, считаю людям будет приятно видеть, что там за поворотом и на правильном ли пассажир пути, ведь обычно на улице видно за 500 метров назад и вперед, также возможно сделать экскурсии из под земли)) это когда ты едешь и видишь что над тобой, но конечно основное это при движении в переходах и выбор поезда, чтобы результат передвижений всегда был ожидаемым и комфортным." ID="ID_592423027" CREATED="1604133518548" MODIFIED="1604133521653"/>
</node>
</node>
<node TEXT="Ярослав" ID="ID_731998909" CREATED="1604133693860" MODIFIED="1604133713558">
<node TEXT="ар якоря" ID="ID_1486854546" CREATED="1604133713601" MODIFIED="1604133721648"/>
</node>
<node TEXT="Николай" ID="ID_8414055" CREATED="1604133725124" MODIFIED="1604133731802">
<node TEXT="ар рентген" ID="ID_1963261536" CREATED="1604133731825" MODIFIED="1604133737600"/>
</node>
<node TEXT="Юля" ID="ID_342172405" CREATED="1604133744340" MODIFIED="1604133747861">
<node TEXT="Визуалка" ID="ID_1844296301" CREATED="1604133747887" MODIFIED="1604133751904"/>
</node>
</node>
<node TEXT="Вопросы трекеров 1чек" ID="ID_218492336" CREATED="1604142060716" MODIFIED="1604142136084">
<node TEXT="Никита Скорик" ID="ID_381036077" CREATED="1604142075805" MODIFIED="1604142075805">
<node TEXT="Наверное аудио навигация хорошая идея для слабовидящих граждан" ID="ID_1869874297" CREATED="1604142075805" MODIFIED="1604142075805"/>
</node>
<node TEXT="Анна Рогожина" ID="ID_896776880" CREATED="1604142075806" MODIFIED="1604142075806">
<node TEXT="Вы говорите про перемещение по станциям, а построение маршрутов между этими станциями как это вообще будет происходить?" ID="ID_897591122" CREATED="1604142075807" MODIFIED="1604142111476"/>
<node TEXT="Основная идея в том чтобы строить маршруты от одной станции к другой" ID="ID_420698376" CREATED="1604142075810" MODIFIED="1604142075810"/>
</node>
<node TEXT="Кирилл шатров" ID="ID_933451900" CREATED="1604142075811" MODIFIED="1604142075811">
<node TEXT="А как маршрутизация, точнее навигация?" ID="ID_1454632879" CREATED="1604142075813" MODIFIED="1604142075813"/>
</node>
</node>
</node>
<node TEXT="Инвестиционная презентация" POSITION="right" ID="ID_1815001994" CREATED="1604129989926" MODIFIED="1604130015313">
<node TEXT="Если успею" ID="ID_1216053450" CREATED="1604177389952" MODIFIED="1604177396380"/>
<node TEXT="Идея VS бизнес" LOCALIZED_STYLE_REF="default" ID="ID_1775865305" CREATED="1547044095210" MODIFIED="1603317729532">
<edge COLOR="#00007c"/>
<node TEXT="У нас есть идея, мы собираемся делать это" LOCALIZED_STYLE_REF="default" ID="ID_893114571" CREATED="1547044110067" MODIFIED="1603317544050"/>
<node TEXT="Унас есть бизнес, мы делаем это, в нас нужно инвестировать, потому что." LOCALIZED_STYLE_REF="default" ID="ID_830847799" CREATED="1547044125902" MODIFIED="1603317544058"/>
<node TEXT="В чем отличие?" LOCALIZED_STYLE_REF="default" ID="ID_119332431" CREATED="1547044167462" MODIFIED="1603317544066"/>
</node>
<node TEXT="Почему вы" LOCALIZED_STYLE_REF="default" ID="ID_1253886418" CREATED="1547044271569" MODIFIED="1603317729537">
<edge COLOR="#007c00"/>
<node TEXT="История ваших отношений с темой" LOCALIZED_STYLE_REF="default" ID="ID_1301839884" CREATED="1547044278557" MODIFIED="1603317544080"/>
<node TEXT="Уникальные компетенции и возможности" LOCALIZED_STYLE_REF="default" ID="ID_1832568465" CREATED="1547044293694" MODIFIED="1603317544080"/>
<node TEXT="Команда" LOCALIZED_STYLE_REF="default" ID="ID_1855861549" CREATED="1547044308449" MODIFIED="1603317544081"/>
</node>
<node TEXT="Проблема" LOCALIZED_STYLE_REF="default" ID="ID_419510026" CREATED="1547044210292" MODIFIED="1603317729545">
<edge COLOR="#7c007c"/>
<node TEXT="История" LOCALIZED_STYLE_REF="default" ID="ID_150848846" CREATED="1547044214074" MODIFIED="1603317544082"/>
<node TEXT="Понятная проблема + второй, более глубокий уровень понимания." LOCALIZED_STYLE_REF="default" ID="ID_1500642192" CREATED="1547044225844" MODIFIED="1603317544085"/>
<node TEXT="Масштаб проблемы и перспективы роста" LOCALIZED_STYLE_REF="default" ID="ID_777081844" CREATED="1547044249323" MODIFIED="1603317544089"/>
</node>
<node TEXT="Рынок" LOCALIZED_STYLE_REF="default" ID="ID_1205921092" CREATED="1547044312578" MODIFIED="1603317729551">
<edge COLOR="#007c7c"/>
<node TEXT="Структура рынка, динамика объёмы, прогнозы - Россия, США, мир" LOCALIZED_STYLE_REF="default" ID="ID_339913784" CREATED="1547044316639" MODIFIED="1603317544091"/>
<node TEXT="Когда и почему будет взрывной рост?" LOCALIZED_STYLE_REF="default" ID="ID_381335865" CREATED="1547044353625" MODIFIED="1603317544095"/>
</node>
<node TEXT="Тизер" LOCALIZED_STYLE_REF="default" ID="ID_1573038741" CREATED="1547044174862" MODIFIED="1603317729563">
<edge COLOR="#7c7c00"/>
<node TEXT="Как мы меняем мир. Что изменится в мире в результате нашей работы." LOCALIZED_STYLE_REF="default" ID="ID_1323649107" CREATED="1547044178233" MODIFIED="1603317544100"/>
</node>
<node TEXT="Маркетинг" LOCALIZED_STYLE_REF="default" ID="ID_1073807144" CREATED="1547044630355" MODIFIED="1603317694633">
<edge COLOR="#ff0000"/>
<node TEXT="Привлечение клиентов, продвижение" LOCALIZED_STYLE_REF="default" ID="ID_1445272369" CREATED="1547044637506" MODIFIED="1603317544069"/>
<node TEXT="Организация продаж" LOCALIZED_STYLE_REF="default" ID="ID_1914944365" CREATED="1547044682202" MODIFIED="1603317544070"/>
</node>
<node TEXT="Оргструктура" LOCALIZED_STYLE_REF="default" ID="ID_332731825" CREATED="1547044589504" MODIFIED="1603317694648">
<edge COLOR="#0000ff"/>
<node TEXT="Органы управления" LOCALIZED_STYLE_REF="default" ID="ID_992193630" CREATED="1547044600684" MODIFIED="1603317544073"/>
<node TEXT="Операционная структура" LOCALIZED_STYLE_REF="default" ID="ID_920578001" CREATED="1547044608493" MODIFIED="1603317544074"/>
<node TEXT="Партнеры (аутсорсеры)" LOCALIZED_STYLE_REF="default" ID="ID_1307992921" CREATED="1547044616481" MODIFIED="1603317544076"/>
</node>
<node TEXT="Почему в нас нужно инвестировать" LOCALIZED_STYLE_REF="default" ID="ID_1103868433" CREATED="1547044379169" MODIFIED="1603317784521" TEXT_SHORTENED="true">
<edge COLOR="#00ff00"/>
<node TEXT="Ключевые преимущества и обещания" LOCALIZED_STYLE_REF="default" ID="ID_1882957319" CREATED="1547044407976" MODIFIED="1603317544078" HGAP_QUANTITY="11.750000067055224 pt" VSHIFT_QUANTITY="-13.49999959766866 pt"/>
</node>
<node TEXT="Продукт" LOCALIZED_STYLE_REF="default" ID="ID_500867704" CREATED="1547044654590" MODIFIED="1603317694667">
<edge COLOR="#ff00ff"/>
<node TEXT="Источники денег" LOCALIZED_STYLE_REF="default" ID="ID_1392226765" CREATED="1547044661032" MODIFIED="1603317544090"/>
<node TEXT="Учет интересов всех сторон" LOCALIZED_STYLE_REF="default" ID="ID_1952929664" CREATED="1547044667800" MODIFIED="1603317544090"/>
</node>
<node TEXT="Стратегия" LOCALIZED_STYLE_REF="default" ID="ID_151386068" CREATED="1547044540084" MODIFIED="1603317694680">
<edge COLOR="#00ffff"/>
<node TEXT="Что собиаемся делать, на чем будет основан успех, на чём фокусируемся" LOCALIZED_STYLE_REF="default" ID="ID_620792317" CREATED="1547044557340" MODIFIED="1603317544096"/>
</node>
<node TEXT="Финансовые показатели" LOCALIZED_STYLE_REF="default" ID="ID_722644571" CREATED="1547044423495" MODIFIED="1603317694690">
<edge COLOR="#7c0000"/>
<node TEXT="Прогноз продаж" LOCALIZED_STYLE_REF="default" ID="ID_1420158169" CREATED="1547044435029" MODIFIED="1603317544104"/>
<node TEXT="Сколько денег и на что?" LOCALIZED_STYLE_REF="default" ID="ID_1349984022" CREATED="1547044441484" MODIFIED="1603317544104"/>
<node TEXT="Прогноз прибыли" LOCALIZED_STYLE_REF="default" ID="ID_1420232442" CREATED="1547044448942" MODIFIED="1603317544105"/>
<node TEXT="Valuation" LOCALIZED_STYLE_REF="default" ID="ID_1156389887" CREATED="1547044455661" MODIFIED="1603317544105"/>
</node>
</node>
<node TEXT="20201031 1800 чекпоинт 2" POSITION="right" ID="ID_994842791" CREATED="1604154762619" MODIFIED="1604154791559">
<node TEXT="исходник" ID="ID_1438082523" CREATED="1604178981960" MODIFIED="1604178990639">
<node TEXT="Расписание 2ого чек поинта в Google Meets!" ID="ID_1822523213" CREATED="1604154822889" MODIFIED="1604178993962">
<node TEXT="Будьте готовы за 30 минут до вашего времени" ID="ID_1408806215" CREATED="1604154822889" MODIFIED="1604154822889"/>
<node TEXT="Формат: 2 мин на вашу презентацию идеи + 3 мин на вопросы от экспертов" ID="ID_1706170608" CREATED="1604154822891" MODIFIED="1604154822891"/>
<node TEXT="Если будете показывать презентацию - готовьтесь заранее" ID="ID_1746090375" CREATED="1604154822895" MODIFIED="1604154822895"/>
<node TEXT="Тайминг будет строгим, так как команд очень много, так что формулируйте мысли чётко =)" ID="ID_492321541" CREATED="1604154822897" MODIFIED="1604154822897"/>
<node TEXT="Ссылку на Google Meets вышлем вам в чат команды за 1-2 минуты до подключения." ID="ID_1961623694" CREATED="1604154822899" MODIFIED="1604154822899"/>
<node TEXT="Проверьте, что в Google Meets:" ID="ID_1866436292" CREATED="1604154822901" MODIFIED="1604154822901"/>
<node TEXT="- у вас работает звук, видео" ID="ID_1066891182" CREATED="1604154822902" MODIFIED="1604154822902"/>
<node TEXT="- вы умеете шерить экран" ID="ID_851061168" CREATED="1604154822903" MODIFIED="1604154822903"/>
<node TEXT="Расписание:" ID="ID_1888573471" CREATED="1604154822904" MODIFIED="1604154822904"/>
<node TEXT="18:00 42" ID="ID_675405142" CREATED="1604154822907" MODIFIED="1604154822907"/>
<node TEXT="18:06 bream of dream" ID="ID_1748565175" CREATED="1604154822913" MODIFIED="1604154822913"/>
<node TEXT="18:12 COSMOTEQ DELTA" ID="ID_425391111" CREATED="1604154822913" MODIFIED="1604154822913"/>
<node TEXT="18:18 DataMap" ID="ID_1913137459" CREATED="1604154822914" MODIFIED="1604154822914"/>
<node TEXT="18:24 ninsar" ID="ID_1176287027" CREATED="1604154822914" MODIFIED="1604154822914"/>
<node TEXT="18:30 ping_win" ID="ID_693063183" CREATED="1604154822915" MODIFIED="1604154822915"/>
<node TEXT="18:36 PYC" ID="ID_1062596538" CREATED="1604154822915" MODIFIED="1604178993951"/>
<node TEXT="18:42 YetiCrab" ID="ID_366928039" CREATED="1604154822917" MODIFIED="1604154822917"/>
<node TEXT="18:48 Совет трёх" ID="ID_1919538239" CREATED="1604154822917" MODIFIED="1604154822917"/>
<node TEXT="18:54 Стратиенко" ID="ID_1732922701" CREATED="1604154822918" MODIFIED="1604154822918"/>
<node TEXT="19:00 Тессеракт" ID="ID_1092367834" CREATED="1604154822918" MODIFIED="1604154822918"/>
<node TEXT="19:06 Nice" ID="ID_1165241714" CREATED="1604154822919" MODIFIED="1604154822919"/>
<node TEXT="19:12 Da Vinci" ID="ID_1850391204" CREATED="1604154822919" MODIFIED="1604154822919"/>
<node TEXT="19:18 Ветераны РэТэКа" ID="ID_834219204" CREATED="1604154822932" MODIFIED="1604154822932"/>
<node TEXT="19:24 Космический батут Тети Зины" ID="ID_990353133" CREATED="1604154822933" MODIFIED="1604154822933"/>
<node TEXT="19:30 Работяги и Настя" ID="ID_801808005" CREATED="1604154822933" MODIFIED="1604154822933"/>
<node TEXT="19:36 ONE_CODE_MEN" ID="ID_843394848" CREATED="1604154822935" MODIFIED="1604154822935"/>
<node TEXT="19:42 Lorem ipsum" ID="ID_958927594" CREATED="1604154822935" MODIFIED="1604154822935"/>
<node TEXT="19:48 FluffyDev" ID="ID_1019398599" CREATED="1604154822936" MODIFIED="1604154822936"/>
<node TEXT="19:54 Five Blocks Down" ID="ID_1128882520" CREATED="1604154822937" MODIFIED="1604154822937"/>
<node TEXT="20:00 PunkZ" ID="ID_643403258" CREATED="1604154822937" MODIFIED="1604154822937"/>
<node TEXT="20:06 scale-giant-six-south-элита-имфиита" ID="ID_1219045693" CREATED="1604154822938" MODIFIED="1604154822938"/>
<node TEXT="20:12 Ночной кружок макроме" ID="ID_13026424" CREATED="1604154822938" MODIFIED="1604154822938"/>
<node TEXT="20:18 Gucci flip flops" ID="ID_837954282" CREATED="1604154822940" MODIFIED="1604154822940"/>
<node TEXT="20:24 Оракул" ID="ID_1333824818" CREATED="1604154822941" MODIFIED="1604154822941"/>
<node TEXT="20:30 theTeam" ID="ID_1289179769" CREATED="1604154822942" MODIFIED="1604154822942"/>
<node TEXT="20:36 Гэнг" ID="ID_1439912863" CREATED="1604154822942" MODIFIED="1604154822942"/>
<node TEXT="20:42 Метро 2033" ID="ID_1565722710" CREATED="1604154822943" MODIFIED="1604154822943"/>
<node TEXT="Увидимся!" ID="ID_924882736" CREATED="1604154822943" MODIFIED="1604154822943"/>
<node TEXT="Ссылка на датасет (и всё остальное):" ID="ID_233487807" CREATED="1604154822944" MODIFIED="1604154822944"/>
<node TEXT="https://drive.google.com/drive/folders/1jWTYdKf1zc4e-4B2bjVNPun-LZbxSwXo" ID="ID_779509519" CREATED="1604154823342" MODIFIED="1604154823342" LINK="https://drive.google.com/drive/folders/1jWTYdKf1zc4e-4B2bjVNPun-LZbxSwXo"/>
</node>
</node>
<node TEXT="18:12 COSMOTEQ DELTA" ID="ID_316369131" CREATED="1604154822913" MODIFIED="1604154822913">
<node TEXT="Анна Рогожина" ID="ID_419699719" CREATED="1604142075806" MODIFIED="1604142075806">
<node TEXT="Вы говорите про перемещение по станциям, а построение маршрутов между этими станциями как это вообще будет происходить?" ID="ID_1374692408" CREATED="1604142075807" MODIFIED="1604142111476">
<node TEXT="нужно уточнить вопрос" ID="ID_1697894678" CREATED="1604155228521" MODIFIED="1604155237676"/>
<node TEXT="речь про алгоритм" ID="ID_1417069545" CREATED="1604155242812" MODIFIED="1604155443711"/>
</node>
<node TEXT="Основная идея в том чтобы строить маршруты от одной станции к другой" ID="ID_1557163599" CREATED="1604142075810" MODIFIED="1604142075810"/>
</node>
<node TEXT="Кирилл шатров" ID="ID_356067818" CREATED="1604142075811" MODIFIED="1604142075811">
<node TEXT="А как маршрутизация, точнее навигация?" ID="ID_50693794" CREATED="1604142075813" MODIFIED="1604142075813"/>
</node>
<node TEXT="Презентация" ID="ID_767077785" CREATED="1604155723451" MODIFIED="1604155729913">
<node TEXT="http://project3186906.tilda.ws" ID="ID_793922069" CREATED="1604155717901" MODIFIED="1604155719522"/>
</node>
<node TEXT="Фигма макет" ID="ID_409502002" CREATED="1604156493326" MODIFIED="1604156501223">
<node TEXT="https://www.figma.com/file/V762rg5BWHbO027fMzUPuj/%D0%A0%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%BA%D0%B0-Armetro?node-id=0%3A1" ID="ID_1984263439" CREATED="1604156502594" MODIFIED="1604156502594" LINK="https://www.figma.com/file/V762rg5BWHbO027fMzUPuj/%D0%A0%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%BA%D0%B0-Armetro?node-id=0%3A1"/>
</node>
</node>
</node>
<node TEXT="20201101 1130 сдача проекта" POSITION="right" ID="ID_1125422297" CREATED="1604172001246" MODIFIED="1604172018393">
<node TEXT="Ребята, напоминаю важную инфу на завтра:" ID="ID_813583024" CREATED="1604172447064" MODIFIED="1604172447064">
<node TEXT="1. Дедлайн по загрузке решений - Вс 1.11.2020 12:00 (Московское время)" ID="ID_585729174" CREATED="1604172447064" MODIFIED="1604172447064"/>
<node TEXT="2. Решение должно содержать:" ID="ID_1283585307" CREATED="1604172447069" MODIFIED="1604172447069">
<node TEXT="- ссылку на google презентацию или ссылку на PDF, выложенную на google диск" ID="ID_895043638" CREATED="1604172447073" MODIFIED="1604172447073"/>
<node TEXT="- ссылку на репозиторий с исходным кодом, например, на github" ID="ID_263964329" CREATED="1604172447075" MODIFIED="1604172447075"/>
<node TEXT="- (опционально) ссылка на видео-демо, выложенное на google диск не длиннее 90 сек" ID="ID_938672826" CREATED="1604172447078" MODIFIED="1604172447078"/>
</node>
<node TEXT="ПРОВЕРЬТЕ, ЧТО ДОСТУП ОТКРЫТ. Иначе жюри не сможет проверить решение и поставить вам больше 0 баллов." ID="ID_1871523783" CREATED="1604172447080" MODIFIED="1604172447080"/>
<node TEXT="3. Решение нужно будет загрузить на платформу в секцию &quot;Хакатон&quot; в форму &quot;Командное решение&quot;." ID="ID_1716850771" CREATED="1604172447082" MODIFIED="1604172447082">
<node TEXT="(https://lk.hack2020.innoagency.ru/solutions)" ID="ID_105356422" CREATED="1604172447086" MODIFIED="1604172447086" LINK="https://lk.hack2020.innoagency.ru/solutions)"/>
</node>
<node TEXT="4. Ссылка на шаблон презентации - он вам поможет не тратить лишнее время на дизайн и структуру, пользуйтесь 😉" ID="ID_395819563" CREATED="1604172447089" MODIFIED="1604172447089">
<node TEXT="https://drive.google.com/drive/folders/1jWTYdKf1zc4e-4B2bjVNPun-LZbxSwXo" ID="ID_1679540530" CREATED="1604172447091" MODIFIED="1604172447091" LINK="https://drive.google.com/drive/folders/1jWTYdKf1zc4e-4B2bjVNPun-LZbxSwXo"/>
</node>
<node TEXT="Загружайте решение вовремя - очень его ждём!" ID="ID_89454567" CREATED="1604172447133" MODIFIED="1604172447133"/>
</node>
<node TEXT="доп" ID="ID_142250748" CREATED="1604178887413" MODIFIED="1604178892481">
<node TEXT="это всё:" ID="ID_701963062" CREATED="1604178893277" MODIFIED="1604178904127"/>
<node TEXT="1. Кладётся доп. директорией на гитхабе." ID="ID_253903108" CREATED="1604178893277" MODIFIED="1604178893277"/>
<node TEXT="2. Архивом кидается в доп.материалы)" ID="ID_993304196" CREATED="1604178893278" MODIFIED="1604178893278"/>
</node>
<node TEXT="" ID="ID_867915886" CREATED="1604220187974" MODIFIED="1604220187974">
<node TEXT="http://cosmoteqdelta.tilda.ws/armetro" ID="ID_364145917" CREATED="1604220194087" MODIFIED="1604220194087" LINK="http://cosmoteqdelta.tilda.ws/armetro"/>
<node TEXT="https://github.com/hubfil/MetroGame" ID="ID_1396261010" CREATED="1604220200693" MODIFIED="1604220200693" LINK="https://github.com/hubfil/MetroGame"/>
</node>
</node>
</node>
</map>
